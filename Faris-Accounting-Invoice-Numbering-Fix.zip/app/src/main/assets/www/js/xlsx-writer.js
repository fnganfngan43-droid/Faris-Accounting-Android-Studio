/* =========================================================
   XlsxWriter — مولّد ملفات Excel (.xlsx) مستقل بلا أي مكتبة خارجية
   يعمل دون إنترنت داخل التطبيق (لا يعتمد على SheetJS من CDN).
   الاستخدام:
     const bytes = XlsxWriter.build([{ name, rows, merges, colWidths, rtl, freezeRows }]);
   - rows: مصفوفة صفوف، كل خلية: نص | رقم | { v, s } حيث s أحد: title, subtitle, label, header, text, num, totalText, totalNum
   - merges: [{ r1, c1, r2, c2 }] (أصفار البداية)
   ========================================================= */

const XlsxWriter = (function () {
  // فهارس التنسيقات في styles.xml (cellXfs)
  const STYLE = { default: 0, title: 1, subtitle: 2, label: 3, header: 4, text: 5, num: 6, totalText: 7, totalNum: 8 };

  /* ---------------- ZIP (بدون ضغط) ---------------- */
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(bytes) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  const enc = new TextEncoder();

  function zip(files) { // files: [{ name, data(Uint8Array) }]
    const parts = [];
    const central = [];
    let offset = 0;
    const u16 = (v) => [v & 0xFF, (v >>> 8) & 0xFF];
    const u32 = (v) => [v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF];

    files.forEach(f => {
      const nameBytes = enc.encode(f.name);
      const crc = crc32(f.data);
      const size = f.data.length;
      const local = new Uint8Array([
        0x50, 0x4B, 0x03, 0x04, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21),
        ...u32(crc), ...u32(size), ...u32(size), ...u16(nameBytes.length), ...u16(0)
      ]);
      parts.push(local, nameBytes, f.data);
      central.push({ nameBytes, crc, size, offset });
      offset += local.length + nameBytes.length + size;
    });

    let centralSize = 0;
    central.forEach(c => {
      const hdr = new Uint8Array([
        0x50, 0x4B, 0x01, 0x02, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21),
        ...u32(c.crc), ...u32(c.size), ...u32(c.size), ...u16(c.nameBytes.length), ...u16(0), ...u16(0),
        ...u16(0), ...u16(0), ...u32(0), ...u32(c.offset)
      ]);
      parts.push(hdr, c.nameBytes);
      centralSize += hdr.length + c.nameBytes.length;
    });
    parts.push(new Uint8Array([
      0x50, 0x4B, 0x05, 0x06, ...u16(0), ...u16(0), ...u16(central.length), ...u16(central.length),
      ...u32(centralSize), ...u32(offset), ...u16(0)
    ]));

    const total = parts.reduce((s, p) => s + p.length, 0);
    const out = new Uint8Array(total);
    let pos = 0;
    parts.forEach(p => { out.set(p, pos); pos += p.length; });
    return out;
  }

  /* ---------------- أدوات XML ---------------- */
  function xmlEscape(value) {
    return String(value)
      // محارف التحكم غير المسموحة في XML
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function colLetter(index) { // 0 → A
    let n = index + 1, s = '';
    while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
    return s;
  }

  // اسم ورقة صالح وفريد (حتى 31 حرفًا بلا \ / ? * [ ] :)
  function safeSheetName(name, used, fallbackIndex) {
    let base = String(name || '').replace(/[\\\/\?\*\[\]:]/g, ' ').replace(/\s+/g, ' ').trim().replace(/^'+|'+$/g, '');
    if (!base) base = `ورقة ${fallbackIndex}`;
    base = base.slice(0, 31);
    let candidate = base, n = 2;
    while (used.has(candidate.toLowerCase())) {
      const suffix = ` (${n++})`;
      candidate = base.slice(0, 31 - suffix.length) + suffix;
    }
    used.add(candidate.toLowerCase());
    return candidate;
  }

  /* ---------------- الورقة ---------------- */
  function sheetXml(sheet) {
    const rows = sheet.rows || [];
    const maxCols = rows.reduce((m, r) => Math.max(m, r.length), 0);
    const widths = sheet.colWidths || [];

    let xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';

    // عرض الورقة: من اليمين لليسار + تجميد صفوف الترويسة
    const freeze = Number(sheet.freezeRows) > 0 ? Number(sheet.freezeRows) : 0;
    xml += `<sheetViews><sheetView workbookViewId="0"${sheet.rtl ? ' rightToLeft="1"' : ''}>` +
      (freeze ? `<pane ySplit="${freeze}" topLeftCell="A${freeze + 1}" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft"/>` : '') +
      '</sheetView></sheetViews>';
    xml += '<sheetFormatPr defaultRowHeight="15"/>';

    if (maxCols) {
      xml += '<cols>';
      for (let c = 0; c < maxCols; c++) {
        const w = widths[c] || 14;
        xml += `<col min="${c + 1}" max="${c + 1}" width="${w}" customWidth="1"/>`;
      }
      xml += '</cols>';
    }

    xml += '<sheetData>';
    rows.forEach((row, r) => {
      xml += `<row r="${r + 1}">`;
      row.forEach((cell, c) => {
        if (cell === null || cell === undefined) return;
        const isObj = typeof cell === 'object';
        const value = isObj ? cell.v : cell;
        const style = isObj && cell.s ? STYLE[cell.s] ?? 0 : 0;
        const ref = `${colLetter(c)}${r + 1}`;
        if (value === '' || value === null || value === undefined) {
          if (style) xml += `<c r="${ref}" s="${style}"/>`; // خلية فارغة بتنسيق (للحدود/الدمج)
          return;
        }
        if (typeof value === 'number' && isFinite(value)) {
          xml += `<c r="${ref}"${style ? ` s="${style}"` : ''}><v>${value}</v></c>`;
        } else {
          xml += `<c r="${ref}"${style ? ` s="${style}"` : ''} t="inlineStr"><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`;
        }
      });
      xml += '</row>';
    });
    xml += '</sheetData>';

    const merges = sheet.merges || [];
    if (merges.length) {
      xml += `<mergeCells count="${merges.length}">` +
        merges.map(m => `<mergeCell ref="${colLetter(m.c1)}${m.r1 + 1}:${colLetter(m.c2)}${m.r2 + 1}"/>`).join('') +
        '</mergeCells>';
    }
    xml += '<pageMargins left="0.5" right="0.5" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>';
    xml += '</worksheet>';
    return xml;
  }

  /* ---------------- التنسيقات ---------------- */
  const STYLES_XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
    '<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>' +
    '<fonts count="4">' +
      '<font><sz val="11"/><name val="Arial"/></font>' +
      '<font><b/><sz val="11"/><name val="Arial"/></font>' +
      '<font><b/><sz val="15"/><name val="Arial"/></font>' +
      '<font><sz val="10"/><color rgb="FF555555"/><name val="Arial"/></font>' +
    '</fonts>' +
    '<fills count="4">' +
      '<fill><patternFill patternType="none"/></fill>' +
      '<fill><patternFill patternType="gray125"/></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFBFE6F5"/><bgColor indexed="64"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFE8ECEF"/><bgColor indexed="64"/></patternFill></fill>' +
    '</fills>' +
    '<borders count="2">' +
      '<border><left/><right/><top/><bottom/><diagonal/></border>' +
      '<border><left style="thin"><color rgb="FF777777"/></left><right style="thin"><color rgb="FF777777"/></right><top style="thin"><color rgb="FF777777"/></top><bottom style="thin"><color rgb="FF777777"/></bottom><diagonal/></border>' +
    '</borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
    '<cellXfs count="9">' +
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +                                                                                       // 0 default
      '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +  // 1 title
      '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +  // 2 subtitle
      '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>' +   // 3 label
      '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' + // 4 header
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>' +  // 5 text
      '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>' + // 6 num
      '<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>' + // 7 totalText
      '<xf numFmtId="164" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>' + // 8 totalNum
    '</cellXfs>' +
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
    '</styleSheet>';

  /* ---------------- بناء الملف ---------------- */
  function build(sheets) {
    if (!sheets || !sheets.length) sheets = [{ name: 'ورقة 1', rows: [] }];
    const used = new Set();
    const named = sheets.map((s, i) => ({ ...s, name: safeSheetName(s.name, used, i + 1) }));

    const files = [];
    const add = (name, text) => files.push({ name, data: enc.encode(text) });

    add('[Content_Types].xml',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
      named.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('') +
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
      '</Types>');

    add('_rels/.rels',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
      '</Relationships>');

    add('xl/workbook.xml',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
      '<bookViews><workbookView/></bookViews><sheets>' +
      named.map((s, i) => `<sheet name="${xmlEscape(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') +
      '</sheets></workbook>');

    add('xl/_rels/workbook.xml.rels',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      named.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('') +
      `<Relationship Id="rId${named.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
      '</Relationships>');

    add('xl/styles.xml', STYLES_XML);
    named.forEach((s, i) => add(`xl/worksheets/sheet${i + 1}.xml`, sheetXml(s)));

    return zip(files);
  }

  return { build, safeSheetName, colLetter };
})();
