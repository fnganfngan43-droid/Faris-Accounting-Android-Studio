/* =========================================================
   الأرصدة الافتتاحية
   ========================================================= */

const OpOpeningBalances = (function () {
  let selectedId = null;
  let currenciesCache = [];

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="ob-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="ob-edit" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" id="ob-del" disabled title="حذف">🗑️</button>
        <button class="btn btn-icon" id="ob-import" title="استيراد إكسل">📥</button>
        <button class="btn btn-icon" id="ob-convert" style="display:none;" title="توليد القيد المقابل (رأس المال) للأرصدة السابقة">🔁</button>
        <button class="btn btn-icon" id="ob-print" title="طباعة">🖨️</button>
      </div>
      <div class="toolbar search-row">
        <input type="text" id="ob-search" placeholder="🔍 بحث في كل الأعمدة...">
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>
            <th>رقم السند</th><th>التاريخ</th><th>رقم الحساب</th><th>اسم الحساب</th>
            <th>رقم تحليلي</th><th>اسم الحساب التحليلي</th><th>العملة</th><th>مدين</th><th>دائن</th><th>البيان</th>
          </tr></thead>
          <tbody id="ob-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet sheet-tall" id="ob-sheet">
        <div class="sheet-handle"></div>
        <h3 id="ob-title">إضافة رصيد افتتاحي</h3>
        <form id="ob-form">
          <div class="form-grid">
            <label class="optional">رقم السند<input type="text" id="ob-no"></label>
            <label class="required">التاريخ<input type="date" id="ob-date" required></label>
            <label class="optional" style="display:none;">العملة المحلية<input type="text" id="ob-local-currency" readonly></label>
            ${AccountAnalyticPicker.markup('ob', 'اسم الحساب', 'اسم الحساب التحليلي')}
            <label class="optional">المبلغ مدين<input type="number" step="0.01" id="ob-debit" value="0"></label>
            <label class="optional">المبلغ دائن<input type="number" step="0.01" id="ob-credit" value="0"></label>
            <label class="optional field-wide">البيان<input type="text" id="ob-statement" value="رصيد افتتاحي"></label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="ob-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      <div class="popup-sheet" id="ob-import-popup">
        <div class="popup-header"><span>استيراد الأرصدة الافتتاحية</span><button class="btn-close" id="ob-import-close">✖️</button></div>
        <p class="hint">يبدأ الاستيراد من الصف الثاني. اسم الحساب واسم الحساب التحليلي يُصحَّحان تلقائيًا من قاعدة البيانات (لا داعٍ لدقتهما في الملف). عمود "رقم تحليلي" اتركه فارغًا للحسابات العامة. عند ترك عمود البيان فارغًا يُملأ تلقائيًا بـ"رصيد افتتاحي". ترتيب الأعمدة:<br>
          <b>A) رقم السند &nbsp;B) التاريخ &nbsp;C) رقم الحساب &nbsp;D) اسم الحساب &nbsp;E) رقم تحليلي &nbsp;F) اسم الحساب التحليلي &nbsp;G) العملة (بالرمز) &nbsp;H) مدين &nbsp;I) دائن &nbsp;J) البيان</b></p>
        <input type="file" id="ob-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="ob-import-status"></p>
      </div>
    `;

    await AccountAnalyticPicker.init('ob');
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);

    container.querySelector('#ob-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#ob-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#ob-del').addEventListener('click', onDelete);
    container.querySelector('#ob-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('ob-sheet')));
    container.querySelector('#ob-form').addEventListener('submit', onSave);
    container.querySelector('#ob-search').addEventListener('input', (e) => loadRows(e.target.value));

    container.querySelector('#ob-import').addEventListener('click', () => {
      document.getElementById('ob-import-status').textContent = '';
      document.getElementById('ob-import-file').value = '';
      Utils.openSheet(document.getElementById('ob-import-popup'));
    });
    container.querySelector('#ob-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('ob-import-popup')));
    container.querySelector('#ob-import-file').addEventListener('change', onImportExcel);
    container.querySelector('#ob-print').addEventListener('click', onPrint);
    container.querySelector('#ob-convert').addEventListener('click', onConvertLegacy);

    await loadRows();
  }

  function currencySymbol(id) {
    const c = currenciesCache.find(c => c.id === id);
    return c ? c.symbol : '';
  }

  async function loadRows(filter) {
    let items = Utils.newestFirst(await FarisDB.getAll(STORES.OPENING_BALANCES));
    if (filter && filter.trim()) {
      const f = filter.trim();
      items = items.filter(it => Object.values(it).some(v => String(v ?? '').includes(f)));
    }
    const legacyCount = (await FarisDB.getAll(STORES.OPENING_BALANCES)).filter(needsCounter).length;
    document.getElementById('ob-convert').style.display = legacyCount ? '' : 'none';

    const rows = document.getElementById('ob-rows');
    rows.innerHTML = items.map(it => `
      <tr data-id="${it.id}">
        <td>${Utils.escapeHtml(it.voucherNo)}</td><td>${Utils.escapeHtml(it.date)}</td>
        <td>${Utils.escapeHtml(it.accountCode)}</td><td>${Utils.escapeHtml(it.accountName)}</td>
        <td>${Utils.escapeHtml(it.analyticCode)}</td><td>${Utils.escapeHtml(it.analyticName)}</td>
        <td>${Utils.escapeHtml(currencySymbol(it.currencyId))}</td>
        <td>${Utils.escapeHtml(it.debit)}</td><td>${Utils.escapeHtml(it.credit)}</td><td>${Utils.escapeHtml(it.statement)}</td>
      </tr>`).join('') || '<tr><td colspan="10" class="empty-row">لا توجد أرصدة افتتاحية بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#ob-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('ob-edit').disabled = false;
    document.getElementById('ob-del').disabled = false;
  }

  async function nextVoucherNo() {
    const items = await FarisDB.getAll(STORES.OPENING_BALANCES);
    const numeric = items.map(i => Number(i.voucherNo)).filter(n => !isNaN(n));
    return String(numeric.length ? Math.max(...numeric) + 1 : 1);
  }

  function localCurrencyLabel() {
    const c = currenciesCache.find(c => c.type === 'محلي');
    return c ? (c.symbol || c.name) : '';
  }

  async function openSheet(id) {
    const sheet = document.getElementById('ob-sheet');
    document.getElementById('ob-form').reset();
    document.getElementById('ob-local-currency').value = localCurrencyLabel();
    document.getElementById('ob-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('ob-statement').value = 'رصيد افتتاحي';

    if (id) {
      const item = await FarisDB.get(STORES.OPENING_BALANCES, id);
      document.getElementById('ob-title').textContent = 'تعديل رصيد افتتاحي';
      document.getElementById('ob-no').value = item.voucherNo;
      document.getElementById('ob-date').value = item.date;
      document.getElementById('ob-debit').value = item.debit;
      document.getElementById('ob-credit').value = item.credit;
      document.getElementById('ob-statement').value = item.statement;
      await AccountAnalyticPicker.setValue('ob', item);
      sheet.dataset.editId = id;
    } else {
      document.getElementById('ob-no').value = await nextVoucherNo();
      sheet.dataset.editId = '';
    }

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  const needsCounter = (r) => !r.journalId && !r.carriedFromYear && r.keepLocal !== true;

  // حساب رأس المال المحدد في شاشة الربط (طرف القيد التلقائي)
  async function getCapitalAccount() {
    const links = await Posting.getLinks();
    if (!links.capitalAccount) {
      return { error: 'حدد حساب رأس المال أولًا من شاشة "ربط المخزون بالأستاذ العام" (زر الحسابات العامة 🏦)' };
    }
    const acc = await FarisDB.get(STORES.ACCOUNTS, links.capitalAccount.code);
    if (!acc || acc.type !== 'فرعي') return { error: 'حساب رأس المال المحدد في شاشة الربط غير موجود أو ليس حسابًا فرعيًا' };
    if (acc.analyticType && acc.analyticType !== 'عام') return { error: 'حساب رأس المال يجب أن يكون حسابًا عامًا (غير مرتبط بعملاء/موردين/صناديق/بنوك)' };
    return { account: acc };
  }

  async function nextJournalNo() {
    const entries = await FarisDB.getAll(STORES.JOURNAL);
    const nums = entries.map(e => Number(e.entryNo)).filter(n => !isNaN(n));
    return nums.length ? Math.max(...nums) + 1 : 1;
  }

  // يحفظ الرصيد الافتتاحي مع قيده التلقائي: الطرف الذي أدخله المستخدم + الطرف المقابل (رأس المال) من النظام
  async function saveWithEntry(value, capital) {
    if (value.accountCode === capital.code) {
      throw Object.assign(new Error('حساب رأس المال يُنشأ تلقائيًا كطرف مقابل ولا يُدخل رصيده يدويًا'), { dup: false });
    }
    const st = value.statement || 'رصيد افتتاحي';
    const lines = [
      { accountCode: value.accountCode, accountName: value.accountName, analyticCode: value.analyticCode, analyticName: value.analyticName,
        currencyId: value.currencyId, statement: st, debit: value.debit, credit: value.credit, refNo: value.voucherNo },
      { accountCode: capital.code, accountName: capital.name, analyticCode: capital.code, analyticName: capital.name,
        currencyId: value.currencyId, statement: `${st} - مقابل رأس المال`, debit: value.credit, credit: value.debit, refNo: value.voucherNo }
    ];
    const payload = { date: value.date, entryType: 'openingBalance', lines };
    let existingJournalId = value.journalId || null;
    if (existingJournalId) {
      const ex = await FarisDB.get(STORES.JOURNAL, existingJournalId);
      payload.id = existingJournalId;
      payload.entryNo = ex ? ex.entryNo : String(existingJournalId);
    } else {
      payload.entryNo = String(await nextJournalNo());
    }
    const journalId = await FarisDB.put(STORES.JOURNAL, payload);
    value.journalId = journalId;
    try {
      return await FarisDB.put(STORES.OPENING_BALANCES, value);
    } catch (err) {
      if (!existingJournalId) { try { await FarisDB.remove(STORES.JOURNAL, journalId); } catch (_) { /* تجاهل */ } }
      throw err;
    }
  }

  async function onConvertLegacy() {
    const cap = await getCapitalAccount();
    if (cap.error) { Utils.toast(cap.error, 'error'); return; }
    const legacy = (await FarisDB.getAll(STORES.OPENING_BALANCES)).filter(needsCounter);
    if (!legacy.length) { Utils.toast('لا توجد أرصدة تحتاج قيدًا مقابلًا', 'info'); return; }
    const ok = await Utils.confirmDialog(`سيُنشأ قيد تلقائي لكل رصيد من الأرصدة السابقة (${legacy.length}) بحيث يكون الطرف المقابل حساب «${Utils.escapeHtml(cap.account.name)}». هل تريد المتابعة؟`);
    if (!ok) return;
    let done = 0, failed = 0;
    for (const rec of legacy) {
      if (rec.accountCode === cap.account.code) { failed++; continue; }
      try { await saveWithEntry({ ...rec }, cap.account); done++; } catch (_) { failed++; }
    }
    Utils.toast(`تم إنشاء ${done} قيد مقابل${failed ? `، وتعذّر ${failed}` : ''}`, failed ? 'info' : 'success');
    await loadRows();
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('ob-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    const picked = await AccountAnalyticPicker.getValue('ob');
    if (!picked) {
      Utils.toast('يجب اختيار الحساب والحساب التحليلي والعملة', 'error');
      return;
    }

    const debit = Number(document.getElementById('ob-debit').value) || 0;
    const credit = Number(document.getElementById('ob-credit').value) || 0;
    if (debit === 0 && credit === 0) {
      Utils.toast('أدخل مبلغًا مدينًا أو دائنًا', 'error');
      return;
    }

    const value = {
      voucherNo: document.getElementById('ob-no').value.trim(),
      date: document.getElementById('ob-date').value,
      ...picked,
      debit, credit,
      statement: document.getElementById('ob-statement').value.trim() || 'رصيد افتتاحي'
    };
    if (editId) {
      value.id = editId;
      const old = await FarisDB.get(STORES.OPENING_BALANCES, editId);
      if (old && old.journalId) value.journalId = old.journalId;
    }

    const cap = await getCapitalAccount();
    if (cap.error) { Utils.toast(cap.error, 'error'); return; }
    try {
      await saveWithEntry(value, cap.account);
    } catch (err) {
      if (!err.toasted) Utils.toast(err.message || 'تعذّر الحفظ', 'error');
      return;
    }
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف هذا الرصيد الافتتاحي؟');
    if (!ok) return;
    try {
      const rec = await FarisDB.get(STORES.OPENING_BALANCES, selectedId);
      if (rec && rec.journalId) await FarisDB.remove(STORES.JOURNAL, rec.journalId);
      await FarisDB.remove(STORES.OPENING_BALANCES, selectedId);
    } catch (err) {
      if (!err.toasted) Utils.toast(err.message || 'تعذّر الحذف', 'error');
      return;
    }
    selectedId = null;
    document.getElementById('ob-edit').disabled = true;
    document.getElementById('ob-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('ob-import-status');
    if (typeof XLSX === 'undefined') {
      statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل، تأكد من الاتصال بالإنترنت.';
      return;
    }
    statusEl.textContent = 'جاري القراءة...';
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }).slice(1);

      const currencies = await FarisDB.getAll(STORES.CURRENCIES);
      let added = 0, skipped = 0, duplicates = 0;
      const cap = await getCapitalAccount();
      if (cap.error) { statusEl.textContent = cap.error; e.target.value = ''; return; }
      const existing = await FarisDB.getAll(STORES.OPENING_BALANCES);
      const sigOf = (r) => [r.voucherNo, r.date, r.accountCode, r.analyticCode, r.currencyId, Number(r.debit) || 0, Number(r.credit) || 0].join('|');
      const seen = new Set(existing.map(sigOf));

      for (const row of rows) {
        const [voucherNo, date, accountCodeVal, accountNameVal, analyticVal, analyticNameVal, currencySymbolVal, debit, credit, statement] = row.map(v => String(v ?? '').trim());
        const resolved = await AccountAnalyticPicker.resolveByAccountAndAnalytic(accountCodeVal, analyticVal);
        const currency = currencies.find(c => c.symbol === currencySymbolVal || c.name === currencySymbolVal);
        if (!resolved || !currency) { skipped++; continue; }

        const rec = {
          voucherNo: voucherNo || String(await nextVoucherNo()),
          date: Utils.normalizeImportDate(date) || new Date().toISOString().slice(0, 10),
          accountCode: resolved.accountCode, accountName: resolved.accountName,
          analyticCode: resolved.analyticCode, analyticName: resolved.analyticName,
          currencyId: currency.id,
          debit: Number(debit) || 0, credit: Number(credit) || 0,
          statement: statement || 'رصيد افتتاحي'
        };
        if (!rec.debit && !rec.credit) { skipped++; continue; }
        if (seen.has(sigOf(rec))) { duplicates++; continue; } // نفس السطر مستورد سابقًا
        try {
          await saveWithEntry(rec, cap.account);
          seen.add(sigOf(rec));
          added++;
        } catch (err) { skipped++; }
      }
      statusEl.textContent = `تم استيراد ${added} سطر مع قيودها التلقائية، وتخطي ${skipped} (حساب/عملة غير موجودة أو حساب رأس المال أو حساب يتطلب اختيار حساب تحليلي محدد)${duplicates ? `، و${duplicates} سطر مكرر لم يُستورد` : ''}.`;
      await loadRows();
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف.';
    }
    e.target.value = '';
  }

  async function onPrint() {
    const items = Utils.newestFirst(await FarisDB.getAll(STORES.OPENING_BALANCES));
    const headers = ['رقم السند', 'التاريخ', 'رقم الحساب', 'اسم الحساب', 'اسم الحساب التحليلي', 'العملة', 'مدين', 'دائن', 'البيان'];
    const rows = items.map(it => [it.voucherNo, it.date, it.accountCode, it.accountName, it.analyticName, currencySymbol(it.currencyId), it.debit, it.credit, it.statement]);
    Utils.printTable('الأرصدة الافتتاحية', headers, rows);
  }

  return { render };
})();
