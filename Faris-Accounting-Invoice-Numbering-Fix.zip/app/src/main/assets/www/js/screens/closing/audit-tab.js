/* =========================================================
   تبويب مراجعة القيود: فحص الاتزان الحقيقي والتكرار في كل الشاشات
   ========================================================= */

const AuditTab = (function () {
  const $ = (id) => document.getElementById(id);

  async function render(container) {
    container.innerHTML = `
      <div class="form-grid">
        <label class="optional">من تاريخ<input type="date" id="au-from"></label>
        <label class="optional">إلى تاريخ<input type="date" id="au-to"></label>
      </div>
      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-primary full" id="au-run">🔎 فحص القيود الآن</button>
      </div>
      <p class="hint">يفحص: اتزان كل قيد وسند وصرف عملة بالعملة المحلية، تكرار أرقام القيود والمستندات، القيود المتطابقة، القيود المفقودة أو المشتركة بين مستندين، والأرصدة الافتتاحية التي لا قيد مقابل لها.</p>
      <div id="au-result"></div>
    `;
    $('au-run').addEventListener('click', onRun);
  }

  async function onRun() {
    const box = $('au-result');
    box.innerHTML = '<p class="hint">جاري الفحص...</p>';
    try {
      const issues = await Posting.audit({ from: $('au-from').value || '', to: $('au-to').value || '' });
      if (!issues.length) {
        box.innerHTML = '<div class="result-card ok">✅ لا توجد مشكلات: كل القيود متزنة ولا يوجد تكرار.</div>';
        return;
      }
      const errors = issues.filter(i => i.level === 'error').length;
      box.innerHTML = `
        <div class="result-card ${errors ? 'warn' : 'ok'}">${errors ? `⚠️ ${errors} مشكلة تحتاج معالجة` : 'ملاحظات فقط'} (إجمالي ${issues.length})</div>
        <div class="table-scroll"><table class="data-table">
          <thead><tr><th>الخطورة</th><th>النوع</th><th>التفاصيل</th></tr></thead>
          <tbody>${issues.map(i => `<tr><td>${i.level === 'error' ? '⛔ خطأ' : '⚠️ تنبيه'}</td><td>${Utils.escapeHtml(i.title)}</td><td>${Utils.escapeHtml(i.detail)}</td></tr>`).join('')}</tbody>
        </table></div>`;
    } catch (err) {
      box.innerHTML = '';
      Utils.toast(err.message || 'تعذّر الفحص', 'error');
    }
  }

  return { render };
})();
