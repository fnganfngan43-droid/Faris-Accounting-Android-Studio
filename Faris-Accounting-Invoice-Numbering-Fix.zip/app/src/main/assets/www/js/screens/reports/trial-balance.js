/* =========================================================
   تقرير ميزان المراجعة
   يدعم التصفية حسب العملة، وخيارين للعرض:
   - بالعملة المحلية: كل الحركات (بأي عملة) تُحوَّل وتُجمع بالعملة المحلية
   - بعملتها الأصلية مقابل المحلية: يعرض المبلغ بعملة الحركة نفسها + عمود مقابله بالمحلية
   عمود الرصيد ينقسم دومًا لعمودين: رصيد مدين / رصيد دائن
   ========================================================= */

const ReportTrialBalance = (function () {
  let lastResult = null;

  async function render(container) {
    lastResult = null;
    const startOfYear = YearEnd.defaultFrom();
    const today = YearEnd.defaultTo();
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);

    container.innerHTML = `
      <div class="form-grid">
        <label class="required">من تاريخ<input type="date" id="tb-from" value="${startOfYear}"></label>
        <label class="required">إلى تاريخ<input type="date" id="tb-to" value="${today}"></label>
        <label class="optional">إظهار
          <select id="tb-show">
            <option value="حركة" selected>كل الحسابات ذات الرصيد أو الحركة</option>
            <option value="غير صفرية">غير الصفرية فقط</option>
            <option value="الكل">كل الحسابات (حتى بدون حركة)</option>
            <option value="مدينة">الأرصدة المدينة فقط</option>
            <option value="دائنة">الأرصدة الدائنة فقط</option>
          </select>
        </label>
        <label class="optional">طريقة العرض
          <select id="tb-display">
            <option value="محلي">بالعملة المحلية</option>
            <option value="اصلي">بعملتها الأصلية مقابل المحلية</option>
          </select>
        </label>
        <label class="optional field-wide" id="tb-currency-wrap">العملة
          <select id="tb-currency"><option value="">كل العملات</option>${currencies.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('')}</select>
        </label>
      </div>
      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-primary" id="tb-view">🔍 عرض</button>
        <button class="btn btn-ghost" id="tb-reset">🔄 مسح الفلاتر</button>
        ${ReportPrint.toolbarHtml('tb')}
      </div>
      <div id="tb-result"></div>
    `;

    container.querySelector('#tb-view').addEventListener('click', onView);
    container.querySelector('#tb-reset').addEventListener('click', () => render(container));
    ReportPrint.bindToolbar('tb', async () => lastResult);
  }

  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const f2 = (n) => (n ? n.toFixed(2) : '');

  async function onView() {
    const fromDate = document.getElementById('tb-from').value;
    const toDate = document.getElementById('tb-to').value;
    const show = document.getElementById('tb-show').value;
    const displayMode = document.getElementById('tb-display').value; // محلي | اصلي
    const currencyId = document.getElementById('tb-currency').value ? Number(document.getElementById('tb-currency').value) : null;
    const original = displayMode !== 'محلي';
    // في العرض المحلي تُجمع كل الحركات بأي عملة؛ وفي العرض الأصلي يُطبَّق فلتر العملة
    const filterCurrency = original ? currencyId : null;

    // كل الحركات (أرصدة افتتاحية + قيود + سندات + صرف عملة) مجمّعة لكل حساب، بما فيها حسابات
    // العملاء والموردين والصناديق والبنوك (تُجمع تحليلاتها في سطر الحساب الفرعي) لضمان اتزان الميزان
    const balances = await YearEnd.collectBalances({ from: fromDate, to: toDate });
    const subs = await ReportData.getAllSubAccountsFlat();
    const currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);

    const agg = new Map();
    balances.forEach(b => {
      if (filterCurrency && b.currencyId !== filterCurrency) return;
      let a = agg.get(b.accountCode);
      if (!a) { a = { code: b.accountCode, name: b.accountName || '', debit: 0, credit: 0, localDebit: 0, localCredit: 0 }; agg.set(b.accountCode, a); }
      if (!a.name && b.accountName) a.name = b.accountName;
      a.debit += b.debit; a.credit += b.credit; a.localDebit += b.localDebit; a.localCredit += b.localCredit;
    });
    // الحسابات التي بلا حركة تُضاف فقط عند اختيار "كل الحسابات"
    if (show === 'الكل') {
      subs.forEach(acc => { if (!agg.has(acc.code)) agg.set(acc.code, { code: acc.code, name: acc.name, debit: 0, credit: 0, localDebit: 0, localCredit: 0 }); });
    }

    const list = [...agg.values()].sort((a, b) => String(a.code).localeCompare(String(b.code)));
    const rows = [];
    const t = { debit: 0, credit: 0, debitBal: 0, creditBal: 0, localDebit: 0, localCredit: 0, localDebitBal: 0, localCreditBal: 0 };

    list.forEach(a => {
      const debit = r2(a.debit), credit = r2(a.credit);
      const localDebit = r2(a.localDebit), localCredit = r2(a.localCredit);
      const bal = r2(debit - credit);
      const localBal = r2(localDebit - localCredit);
      // في العرض المحلي نعتمد الرصيد المحلي، وفي الأصلي رصيد العملة نفسها
      const shownBal = original ? bal : localBal;
      if (show === 'غير صفرية' && shownBal === 0) return;
      if (show === 'مدينة' && shownBal <= 0) return;
      if (show === 'دائنة' && shownBal >= 0) return;

      const dBal = bal > 0 ? bal : 0, cBal = bal < 0 ? -bal : 0;
      const ldBal = localBal > 0 ? localBal : 0, lcBal = localBal < 0 ? -localBal : 0;
      if (original) {
        rows.push([a.code, a.name, f2(debit), f2(credit), f2(dBal), f2(cBal), f2(ldBal), f2(lcBal)]);
      } else {
        rows.push([a.code, a.name, f2(localDebit), f2(localCredit), f2(ldBal), f2(lcBal)]);
      }
      t.debit += debit; t.credit += credit; t.debitBal += dBal; t.creditBal += cBal;
      t.localDebit += localDebit; t.localCredit += localCredit; t.localDebitBal += ldBal; t.localCreditBal += lcBal;
    });

    let headers, footerRow, title, balanced, diff;
    if (!original) {
      headers = ['رقم الحساب', 'اسم الحساب', 'مدين', 'دائن', 'رصيد مدين', 'رصيد دائن'];
      footerRow = ['', 'الإجمالي (بالعملة المحلية)', r2(t.localDebit).toFixed(2), r2(t.localCredit).toFixed(2), r2(t.localDebitBal).toFixed(2), r2(t.localCreditBal).toFixed(2)];
      title = 'ميزان المراجعة (بالعملة المحلية)';
      diff = r2(t.localDebitBal - t.localCreditBal);
    } else {
      const sym = currencyId ? ((currenciesCache.find(c => c.id === currencyId) || {}).symbol || '') : '';
      headers = ['رقم الحساب', 'اسم الحساب', `مدين${sym ? ' (' + sym + ')' : ''}`, `دائن${sym ? ' (' + sym + ')' : ''}`, 'رصيد مدين', 'رصيد دائن', 'رصيد مدين (محلي)', 'رصيد دائن (محلي)'];
      footerRow = ['', 'الإجمالي', r2(t.debit).toFixed(2), r2(t.credit).toFixed(2), r2(t.debitBal).toFixed(2), r2(t.creditBal).toFixed(2), r2(t.localDebitBal).toFixed(2), r2(t.localCreditBal).toFixed(2)];
      title = `ميزان المراجعة${sym ? ' - ' + sym : ' (كل العملات)'} مقابل العملة المحلية`;
      // عند اختيار عملة واحدة نفحص اتزانها بعملتها؛ وإلا نفحص المقابل المحلي
      diff = currencyId ? r2(t.debitBal - t.creditBal) : r2(t.localDebitBal - t.localCreditBal);
    }
    balanced = Math.abs(diff) <= 0.01;

    lastResult = { title, fromDate, toDate, headers, rows, footerRow };
    renderTable(headers, rows, footerRow, show === 'مدينة' || show === 'دائنة' ? null : { balanced, diff });
  }

  function renderTable(headers, rows, footerRow, status) {
    document.getElementById('tb-result').innerHTML = `
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${headers.length}" class="empty-row">لا توجد بيانات</td></tr>`}</tbody>
          <tfoot><tr>${footerRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>
        </table>
      </div>
      ${status ? (status.balanced
        ? '<div class="result-card ok">✅ الميزان متزن: إجمالي الأرصدة المدينة يساوي إجمالي الأرصدة الدائنة.</div>'
        : `<div class="result-card warn">⚠️ الميزان غير متزن: الفرق بين الأرصدة المدينة والدائنة ${Math.abs(status.diff).toFixed(2)}. راجع القيود غير المتزنة أو اختلاف أسعار الصرف.</div>`) : ''}
    `;
  }

  return { render };
})();
