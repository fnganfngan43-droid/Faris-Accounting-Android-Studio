/* =========================================================
   تقرير اليومية
   يعرض كل الحركات المحاسبية لكل الشاشات (العمليات، المبيعات، المشتريات، المخزون)
   بما فيها القيود التلقائية التي ينشئها النظام وقيود الإقفال.
   نوع السند = اسم الشاشة التي تمّت فيها العملية، ورقم القيد = رقم المستند الأصلي (مثل رقم الفاتورة).
   ========================================================= */

const ReportDaily = (function () {
  let lastResult = null;
  let allLines = [];
  let currenciesCache = [];

  const TYPE_NAMES = {
    opening: 'الأرصدة الافتتاحية',
    journal: 'القيود اليومية',
    receipt: 'سند قبض',
    payment: 'سند الصرف',
    exchange: 'صرف عملة',
    closing: 'قيد إقفال'
  };
  const ALL_TYPES = [
    TYPE_NAMES.opening, TYPE_NAMES.journal, TYPE_NAMES.receipt, TYPE_NAMES.payment, TYPE_NAMES.exchange,
    'فواتير مبيعات', 'مرتجع المبيعات', 'فاتورة مشتريات', 'مرجوع مشتريات', 'المخزون الافتتاحي', TYPE_NAMES.closing
  ];

  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

  async function render(container) {
    lastResult = null;
    allLines = [];
    viewed = false;
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);

    container.innerHTML = `
      <div class="form-grid">
        <label class="required">من تاريخ<input type="date" id="dr-from" value="${YearEnd.defaultFrom()}"></label>
        <label class="required">إلى تاريخ<input type="date" id="dr-to" value="${YearEnd.defaultTo()}"></label>
        <label class="optional">نوع السند
          <select id="dr-type">
            <option value="">كل الأنواع</option>
            ${ALL_TYPES.map(t => `<option value="${t}">${t}</option>`).join('')}
          </select>
        </label>
        <label class="optional">بحث<input type="text" id="dr-search" placeholder="رقم السند / الحساب / البيان"></label>
      </div>
      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-primary" id="dr-view">🔍 عرض</button>
        <button class="btn btn-ghost" id="dr-reset">🔄 مسح الفلاتر</button>
        ${ReportPrint.toolbarHtml('dr')}
      </div>
      <div id="dr-result"></div>
    `;

    container.querySelector('#dr-view').addEventListener('click', onView);
    container.querySelector('#dr-reset').addEventListener('click', () => render(container));
    container.querySelector('#dr-type').addEventListener('change', draw);
    container.querySelector('#dr-search').addEventListener('input', draw);
    ReportPrint.bindToolbar('dr', async () => lastResult);
  }

  function symbol(id) {
    const c = currenciesCache.find(x => x.id === id);
    return c ? c.symbol : '';
  }

  function toLocal(amount, currencyId) {
    if (!amount) return 0;
    const c = currenciesCache.find(x => x.id === currencyId);
    if (!c || c.type === 'محلي') return amount;
    return amount * (Number(c.rate) || 1);
  }
  const pickLocal = (stored, amount, cid) => (typeof stored === 'number' && !isNaN(stored)) ? stored : toLocal(amount, cid);

  // يجمع كل أسطر القيود من كل مصادر الحركة داخل الفترة
  async function collect(fromDate, toDate) {
    const lines = [];
    const inRange = (d) => !!d && (!fromDate || d >= fromDate) && (!toDate || d <= toDate);
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const accName = (code) => { const a = accounts.find(x => x.code === code); return a ? a.name : ''; };
    const auto = await ReportData.getAutoEntryMap();
    let seq = 0;

    const push = (o) => {
      const debit = Number(o.debit) || 0, credit = Number(o.credit) || 0;
      lines.push({
        seq: ++seq, date: o.date, docType: o.docType, docNo: String(o.docNo ?? ''),
        accountCode: o.accountCode || '', accountName: o.accountName || accName(o.accountCode),
        analytic: (o.analyticCode && o.analyticCode !== o.accountCode) ? (o.analyticName || '') : '',
        currencyId: o.currencyId, statement: o.statement || '', refNo: o.refNo || '',
        debit, credit,
        localDebit: pickLocal(o.localDebit, debit, o.currencyId),
        localCredit: pickLocal(o.localCredit, credit, o.currencyId)
      });
    };

    (await FarisDB.getAll(STORES.OPENING_BALANCES)).forEach(it => {
      if (it.journalId || !inRange(it.date)) return; // له قيد تلقائي يظهر من القيود
      push({ date: it.date, docType: TYPE_NAMES.opening, docNo: it.voucherNo, accountCode: it.accountCode, accountName: it.accountName, analyticCode: it.analyticCode, analyticName: it.analyticName, currencyId: it.currencyId, statement: it.statement, debit: it.debit, credit: it.credit, localDebit: it.localDebit, localCredit: it.localCredit });
    });

    (await FarisDB.getAll(STORES.JOURNAL)).forEach(entry => {
      if (!inRange(entry.date)) return;
      const a = auto.get(entry.id);
      const docType = a ? a.type : (ReportData.isClosingEntry(entry) ? TYPE_NAMES.closing : TYPE_NAMES.journal);
      const docNo = a ? a.docNo : entry.entryNo;
      (entry.lines || []).forEach(l => push({ date: entry.date, docType, docNo, accountCode: l.accountCode, accountName: l.accountName, analyticCode: l.analyticCode, analyticName: l.analyticName, currencyId: l.currencyId, statement: l.statement, refNo: l.refNo, debit: l.debit, credit: l.credit, localDebit: l.localDebit, localCredit: l.localCredit }));
    });

    (await FarisDB.getAll(STORES.VOUCHERS)).forEach(v => {
      if (!inRange(v.date)) return;
      const docType = TYPE_NAMES[v.type] || v.type;
      const d = v.debitSide, c = v.creditSide;
      if (d) push({ date: v.date, docType, docNo: v.voucherNo, accountCode: d.accountCode, accountName: d.accountName, analyticCode: d.analyticCode, analyticName: d.analyticName, currencyId: d.currencyId, statement: d.statement, refNo: d.refNo, debit: d.amount, credit: 0, localDebit: d.localDebit, localCredit: 0 });
      if (c) push({ date: v.date, docType, docNo: v.voucherNo, accountCode: c.accountCode, accountName: c.accountName, analyticCode: c.analyticCode, analyticName: c.analyticName, currencyId: c.currencyId, statement: c.statement, refNo: c.refNo, debit: 0, credit: c.amount, localDebit: 0, localCredit: c.localCredit });
    });

    (await FarisDB.getAll(STORES.CURRENCY_EXCHANGES)).forEach(ex => {
      if (!inRange(ex.date)) return;
      push({ date: ex.date, docType: TYPE_NAMES.exchange, docNo: ex.no, accountCode: ex.accountCode, analyticCode: ex.analyticCode, analyticName: ex.analyticName, currencyId: ex.fromCurrencyId, statement: ex.fromStatement, refNo: ex.refNo, debit: 0, credit: ex.fromAmount, localDebit: 0, localCredit: ex.localCredit });
      push({ date: ex.date, docType: TYPE_NAMES.exchange, docNo: ex.no, accountCode: ex.accountCode, analyticCode: ex.analyticCode, analyticName: ex.analyticName, currencyId: ex.toCurrencyId, statement: ex.toStatement, refNo: ex.refNo, debit: ex.toAmount, credit: 0, localDebit: ex.localDebit, localCredit: 0 });
    });

    // ترتيب: التاريخ ثم نوع السند ثم رقم المستند ثم ترتيب الإدخال
    const numOrStr = (a, b) => {
      const na = Number(a), nb = Number(b);
      return (!isNaN(na) && !isNaN(nb)) ? na - nb : String(a).localeCompare(String(b));
    };
    lines.sort((a, b) => a.date.localeCompare(b.date) || a.docType.localeCompare(b.docType) || numOrStr(a.docNo, b.docNo) || a.seq - b.seq);
    return lines;
  }

  async function onView() {
    const fromDate = document.getElementById('dr-from').value;
    const toDate = document.getElementById('dr-to').value;
    if (!fromDate || !toDate) { Utils.toast('حدد الفترة (من تاريخ / إلى تاريخ)', 'error'); return; }
    if (fromDate > toDate) { Utils.toast('"من تاريخ" يجب أن يسبق "إلى تاريخ"', 'error'); return; }
    allLines = await collect(fromDate, toDate);
    viewed = true;
    draw();
  }

  let viewed = false;

  function draw() {
    const box = document.getElementById('dr-result');
    if (!box || !viewed) return;
    const type = document.getElementById('dr-type').value;
    const q = document.getElementById('dr-search').value.trim();
    let lines = allLines;
    if (type) lines = lines.filter(l => l.docType === type);
    if (q) lines = lines.filter(l => [l.docNo, l.docType, l.accountCode, l.accountName, l.analytic, l.statement, l.refNo].some(v => String(v ?? '').includes(q)));

    const headers = ['التاريخ', 'رقم السند', 'نوع السند', 'رقم الحساب', 'اسم الحساب', 'الحساب التحليلي', 'العملة', 'البيان', 'مدين', 'دائن', 'مدين (محلي)', 'دائن (محلي)'];
    const rows = lines.map(l => [
      l.date, l.docNo, l.docType, l.accountCode, l.accountName, l.analytic, symbol(l.currencyId), l.statement,
      l.debit ? l.debit.toFixed(2) : '', l.credit ? l.credit.toFixed(2) : '',
      l.localDebit ? r2(l.localDebit).toFixed(2) : '', l.localCredit ? r2(l.localCredit).toFixed(2) : ''
    ]);
    const totalDebit = r2(lines.reduce((s, l) => s + l.localDebit, 0));
    const totalCredit = r2(lines.reduce((s, l) => s + l.localCredit, 0));
    const footerRow = ['', '', '', '', '', '', '', 'الإجمالي (بالعملة المحلية)', '', '', totalDebit.toFixed(2), totalCredit.toFixed(2)];
    const docCount = new Set(lines.map(l => `${l.docType}|${l.docNo}`)).size;

    lastResult = { title: 'تقرير اليومية', fromDate: document.getElementById('dr-from').value, toDate: document.getElementById('dr-to').value, headers, rows, footerRow };

    const diff = r2(totalDebit - totalCredit);
    box.innerHTML = `
      <p class="hint" style="margin:10px 0;">عدد المستندات: ${docCount} — عدد الأسطر: ${lines.length}</p>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${headers.length}" class="empty-row">لا توجد حركات في هذه الفترة</td></tr>`}</tbody>
          <tfoot><tr>${footerRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>
        </table>
      </div>
      ${lines.length && !type && !q && Math.abs(diff) > 0.01 ? `<div class="result-card warn">⚠️ إجمالي المدين لا يساوي إجمالي الدائن (فرق ${diff.toFixed(2)} بالعملة المحلية) — قد يكون سببه اختلاف أسعار الصرف أو قيد غير متزن.</div>` : ''}
    `;
  }

  return { render, TYPE_NAMES };
})();
