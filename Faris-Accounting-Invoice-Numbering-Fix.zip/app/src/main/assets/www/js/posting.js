/* =========================================================
   Posting — مراجعة القيود في كل الشاشات
   1) الاتزان الحقيقي: مجموع المدين = مجموع الدائن بالعملة المحلية (وليس بالمبالغ الخام)
   2) فروق الكسور: تُرحَّل تلقائيًا إلى الحساب الذي يحدده المستخدم في شاشة الربط
   3) عدم التكرار: أرقام المستندات الفريدة + منع الحفظ المزدوج (في db.js) + فحص شامل
   4) الحسابات العامة للنظام (حساب رأس المال وحساب فروق الكسور) من شاشة الربط
   ========================================================= */

const Posting = (function () {
  const LINKS_KEY = 'accountLinks';
  const ROUNDING_STATEMENT = 'فروق تقريب تلقائية';
  const EPS = 0.005;              // فرق لا يُعدّ شيئًا
  const NO_ACCOUNT_TOLERANCE = 0.05; // أقصى فرق مقبول عند عدم تحديد حساب فروق الكسور
  const DEFAULT_LIMIT = 1;        // أقصى فرق يُرحَّل تلقائيًا إلى حساب فروق الكسور

  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

  /* ---------------- الحسابات العامة ---------------- */
  async function getLinks() {
    let rec = null;
    try { rec = await FarisDB.get(STORES.SETTINGS, LINKS_KEY); } catch (_) { /* تجاهل */ }
    rec = rec || {};
    return {
      capitalAccount: rec.capitalAccount && rec.capitalAccount.code ? rec.capitalAccount : null,
      roundingAccount: rec.roundingAccount && rec.roundingAccount.code ? rec.roundingAccount : null,
      roundingLimit: Number(rec.roundingLimit) > 0 ? Number(rec.roundingLimit) : DEFAULT_LIMIT
    };
  }

  async function saveLinks(links) {
    await FarisDB.put(STORES.SETTINGS, {
      id: LINKS_KEY,
      capitalAccount: links.capitalAccount || null,
      roundingAccount: links.roundingAccount || null,
      roundingLimit: Number(links.roundingLimit) > 0 ? Number(links.roundingLimit) : DEFAULT_LIMIT
    });
  }

  /* ---------------- العملات والمبالغ المحلية ---------------- */
  function makeLocalizer(currencies) {
    const rateOf = (currencyId, own) => {
      const cur = currencies.find(c => c.id === currencyId);
      if (!cur || cur.type === 'محلي') return 1;
      return Number(own) || Number(cur.rate) || 1;
    };
    const localOf = (amount, currencyId, own) => r2((Number(amount) || 0) * rateOf(currencyId, own));
    const local = currencies.find(c => c.type === 'محلي') || currencies[0] || null;
    return { rateOf, localOf, localCurrency: local };
  }

  const isRoundingLine = (l, roundingCode) =>
    l && (l.autoRounding === true || (l.statement === ROUNDING_STATEMENT && (!roundingCode || l.accountCode === roundingCode)));

  // يحسب فرق الاتزان المحلي لأسطر قيد (مدين - دائن) بعد استبعاد سطر فروق الكسور التلقائي القديم
  function localDiff(lines, localizer, roundingCode) {
    let d = 0, c = 0;
    (lines || []).forEach(l => {
      if (isRoundingLine(l, roundingCode)) return;
      const own = l.exchangeRate || l.rate;
      d += localizer.localOf(l.debit, l.currencyId, own);
      c += localizer.localOf(l.credit, l.currencyId, own);
    });
    return r2(d - c);
  }

  /* ---------------- تجهيز أسطر القيد (للشاشات قبل حفظ المستند) ---------------- */
  // يرجع { lines } بعد إضافة سطر فروق الكسور عند اللزوم، أو { error } إذا كان القيد غير متزن فعلًا
  async function prepareLines(lines) {
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const localizer = makeLocalizer(currencies);
    const links = await getLinks();
    const roundingCode = links.roundingAccount ? links.roundingAccount.code : null;

    const clean = (lines || []).filter(l => !isRoundingLine(l, roundingCode)).map(l => ({ ...l }));
    const diff = localDiff(clean, localizer, roundingCode);
    if (Math.abs(diff) <= EPS) return { lines: clean, diff: 0 };

    if (roundingCode && Math.abs(diff) <= links.roundingLimit) {
      const acc = await FarisDB.get(STORES.ACCOUNTS, roundingCode);
      if (!acc || acc.type !== 'فرعي') return { error: 'حساب فروق الكسور المحدد في شاشة الربط غير موجود أو ليس حسابًا فرعيًا' };
      const cur = localizer.localCurrency;
      clean.push({
        accountCode: acc.code, accountName: acc.name, analyticCode: acc.code, analyticName: acc.name,
        currencyId: cur ? cur.id : undefined, statement: ROUNDING_STATEMENT,
        debit: diff < 0 ? Math.abs(diff) : 0, credit: diff > 0 ? diff : 0,
        refNo: (clean[0] && clean[0].refNo) || '', autoRounding: true
      });
      return { lines: clean, diff, rounded: true };
    }
    if (!roundingCode && Math.abs(diff) <= NO_ACCOUNT_TOLERANCE) return { lines: clean, diff };

    const limitNote = roundingCode ? ` (الحد المسموح لفروق الكسور ${links.roundingLimit})` : ' — حدد حساب فروق الكسور في شاشة ربط المخزون بالأستاذ العام لترحيل الفروق الصغيرة تلقائيًا';
    return { error: `القيد غير متزن بالعملة المحلية: الفرق ${Math.abs(diff).toFixed(2)}${limitNote}` };
  }

  /* ---------------- مراجعة كل كتابة (خطاف قاعدة البيانات) ---------------- */
  function fail(msg) {
    try { Utils.toast(msg, 'error'); } catch (_) { /* تجاهل */ }
    const err = new Error(msg);
    err.toasted = true;
    throw err;
  }

  // أرقام المستندات الفريدة لكل نوع مستند: [اسم الشاشة، الحقل، مفتاح تجميع إضافي]
  const UNIQUE_NUMBER = {
    [STORES.VOUCHERS]: { label: 'السند', field: 'voucherNo', scope: (v) => v.type },
    [STORES.SALES_INVOICES]: { label: 'فاتورة المبيعات', field: 'invoiceNo' },
    [STORES.SALES_RETURNS]: { label: 'مرتجع المبيعات', field: 'returnNo' },
    [STORES.PURCHASE_INVOICES]: { label: 'فاتورة المشتريات', field: 'invoiceNo' },
    [STORES.PURCHASE_RETURNS]: { label: 'مرجوع المشتريات', field: 'returnNo' }
  };

  async function checkUniqueNumber(storeName, value, key) {
    const rule = UNIQUE_NUMBER[storeName];
    if (!rule) return;
    const no = String(value[rule.field] ?? '').trim();
    if (!no) return;
    const all = await FarisDB.getAll(storeName);
    const dup = all.find(r => r.id !== key && String(r[rule.field] ?? '').trim() === no &&
      (!rule.scope || rule.scope(r) === rule.scope(value)));
    if (dup) fail(`رقم ${rule.label} (${no}) مستخدم مسبقًا، لا يمكن تكرار الرقم`);
  }

  async function recordHook(storeName, value, key) {
    if (!value || typeof value !== 'object') return;
    const bypass = FarisDB.isBypassed();

    if (storeName === STORES.JOURNAL) {
      if (!value.createdAt) value.createdAt = new Date().toISOString();
      if (!value.lines || !value.lines.length) return;
      const res = await prepareLines(value.lines);
      if (res.error) fail(res.error);
      value.lines = res.lines;
      // أسطر فروق الكسور الجديدة تحتاج مبالغ محلية
      if (res.rounded) {
        const currencies = await FarisDB.getAll(STORES.CURRENCIES);
        const localizer = makeLocalizer(currencies);
        value.lines.forEach(l => {
          if (l.autoRounding) { l.localDebit = localizer.localOf(l.debit, l.currencyId); l.localCredit = localizer.localOf(l.credit, l.currencyId); }
        });
      }
      return;
    }

    if (storeName === STORES.VOUCHERS) {
      const d = value.debitSide, c = value.creditSide;
      if (d && c) {
        const diff = r2((d.localDebit || 0) - (c.localCredit || 0));
        if (Math.abs(diff) > NO_ACCOUNT_TOLERANCE) fail(`السند غير متزن بالعملة المحلية: الفرق ${Math.abs(diff).toFixed(2)} — تأكد أن عملتي الطرفين متكافئتان`);
      }
      if (!bypass) await checkUniqueNumber(storeName, value, key);
      return;
    }

    if (storeName === STORES.CURRENCY_EXCHANGES) {
      const diff = r2((value.localDebit || 0) - (value.localCredit || 0));
      const links = await getLinks();
      const limit = links.roundingAccount ? links.roundingLimit : NO_ACCOUNT_TOLERANCE;
      if (Math.abs(diff) > limit) fail(`عملية الصرف غير متزنة بالعملة المحلية: الفرق ${Math.abs(diff).toFixed(2)} يتجاوز الحد المسموح (${limit}) — راجع المبالغ وأسعار الصرف`);
      return;
    }

    if (UNIQUE_NUMBER[storeName] && !bypass) {
      await checkUniqueNumber(storeName, value, key);
      return;
    }

    if (storeName === STORES.OPENING_BALANCES && !bypass && !value.journalId && value.keepLocal !== true) {
      const links = await getLinks();
      if (links.capitalAccount && value.accountCode === links.capitalAccount.code) {
        fail('حساب رأس المال يُنشأ تلقائيًا كطرف مقابل للأرصدة الافتتاحية، ولا يُدخل رصيده يدويًا');
      }
    }
  }
  FarisDB.setRecordHook(recordHook);

  /* ---------------- الفحص الشامل ---------------- */
  // يرجع قائمة المشكلات: { level: 'error'|'warn', title, detail }
  async function audit({ from, to } = {}) {
    const issues = [];
    const inRange = (d) => (!from || (d && d >= from)) && (!to || (d && d <= to));
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const localizer = makeLocalizer(currencies);
    const links = await getLinks();
    const roundingCode = links.roundingAccount ? links.roundingAccount.code : null;
    const autoMap = await ReportData.getAutoEntryMap();
    const entries = (await FarisDB.getAll(STORES.JOURNAL)).filter(e => inRange(e.date));

    const label = (e) => { const a = autoMap.get(e.id); return a ? `${a.type} رقم ${a.docNo}` : (ReportData.isClosingEntry(e) ? `قيد إقفال رقم ${e.entryNo}` : `قيد يومية رقم ${e.entryNo}`); };

    // 1) قيود غير متزنة بالعملة المحلية (سطر فروق الكسور التلقائي يُحسب كسطر عادي)
    entries.forEach(e => {
      if (!(e.lines || []).length) return;
      const total = r2((e.lines || []).reduce((sum, l) => {
        const own = l.exchangeRate || l.rate;
        return sum + localizer.localOf(l.debit, l.currencyId, own) - localizer.localOf(l.credit, l.currencyId, own);
      }, 0));
      if (Math.abs(total) > NO_ACCOUNT_TOLERANCE) {
        issues.push({ level: 'error', title: 'قيد غير متزن', detail: `${label(e)} — الفرق ${Math.abs(total).toFixed(2)} (بالعملة المحلية)` });
      }
    });

    // 2) قيود يومية يدوية بأرقام مكررة
    const manual = entries.filter(e => !autoMap.has(e.id) && !ReportData.isSystemEntry(e));
    const byNo = new Map();
    manual.forEach(e => { const k = String(e.entryNo); if (!byNo.has(k)) byNo.set(k, []); byNo.get(k).push(e); });
    byNo.forEach((list, no) => { if (list.length > 1) issues.push({ level: 'error', title: 'رقم قيد مكرر', detail: `رقم القيد اليومي ${no} مستخدم في ${list.length} قيود` }); });

    // 3) قيود متطابقة تمامًا (تاريخ + أسطر)
    const sigOf = (e) => JSON.stringify([e.date, (e.lines || []).map(l => [l.accountCode, l.analyticCode, l.currencyId, Number(l.debit) || 0, Number(l.credit) || 0, l.refNo || ''])]);
    const bySig = new Map();
    entries.forEach(e => { const k = sigOf(e); if (!bySig.has(k)) bySig.set(k, []); bySig.get(k).push(e); });
    bySig.forEach(list => { if (list.length > 1) issues.push({ level: 'error', title: 'قيود مكررة', detail: `${list.length} قيود متطابقة بتاريخ ${list[0].date}: ${list.map(label).join('، ')}` }); });

    // 4) المستندات: أرقام مكررة، وقيد مفقود، وقيد مشترك بين أكثر من مستند
    const journalIds = new Set((await FarisDB.getAll(STORES.JOURNAL)).map(e => e.id));
    const usedJournal = new Map();
    const docStores = [
      [STORES.SALES_INVOICES, 'فاتورة مبيعات', 'invoiceNo'], [STORES.SALES_RETURNS, 'مرتجع مبيعات', 'returnNo'],
      [STORES.PURCHASE_INVOICES, 'فاتورة مشتريات', 'invoiceNo'], [STORES.PURCHASE_RETURNS, 'مرجوع مشتريات', 'returnNo'],
      [STORES.INV_OPENING_STOCK_DOCS, 'مخزون افتتاحي', 'id']
    ];
    for (const [store, name, field] of docStores) {
      const docs = (await FarisDB.getAll(store)).filter(d => inRange(d.date));
      const seen = new Map();
      docs.forEach(d => {
        const no = String(d[field] ?? '');
        seen.set(no, (seen.get(no) || 0) + 1);
        if (d.journalId) {
          if (!journalIds.has(d.journalId)) issues.push({ level: 'error', title: 'قيد مفقود', detail: `${name} رقم ${no} مرتبط بقيد غير موجود` });
          const k = d.journalId;
          if (usedJournal.has(k)) issues.push({ level: 'error', title: 'قيد مشترك', detail: `${name} رقم ${no} والمستند ${usedJournal.get(k)} يشتركان في نفس القيد` });
          else usedJournal.set(k, `${name} رقم ${no}`);
        }
      });
      if (field !== 'id') seen.forEach((n, no) => { if (n > 1) issues.push({ level: 'error', title: 'رقم مستند مكرر', detail: `${name} رقم ${no} مكرر ${n} مرات` }); });
    }
    const vouchers = (await FarisDB.getAll(STORES.VOUCHERS)).filter(v => inRange(v.date));
    const vSeen = new Map();
    vouchers.forEach(v => {
      const k = `${v.type}|${v.voucherNo}`; vSeen.set(k, (vSeen.get(k) || 0) + 1);
      const diff = r2((v.debitSide ? v.debitSide.localDebit || 0 : 0) - (v.creditSide ? v.creditSide.localCredit || 0 : 0));
      if (Math.abs(diff) > NO_ACCOUNT_TOLERANCE) issues.push({ level: 'error', title: 'سند غير متزن', detail: `سند رقم ${v.voucherNo} — الفرق ${Math.abs(diff).toFixed(2)} (بالعملة المحلية)` });
    });
    vSeen.forEach((n, k) => { if (n > 1) issues.push({ level: 'error', title: 'رقم سند مكرر', detail: `السند ${k.split('|')[1]} (${k.split('|')[0] === 'receipt' ? 'قبض' : 'صرف'}) مكرر ${n} مرات` }); });

    // 5) صرف العملة
    (await FarisDB.getAll(STORES.CURRENCY_EXCHANGES)).filter(x => inRange(x.date)).forEach(x => {
      const diff = r2((x.localDebit || 0) - (x.localCredit || 0));
      const limit = roundingCode ? links.roundingLimit : NO_ACCOUNT_TOLERANCE;
      if (Math.abs(diff) > limit) issues.push({ level: 'error', title: 'صرف عملة غير متزن', detail: `عملية صرف رقم ${x.no} — الفرق ${Math.abs(diff).toFixed(2)} (بالعملة المحلية)` });
    });

    // 6) أرصدة افتتاحية بلا قيد مقابل
    const legacy = (await FarisDB.getAll(STORES.OPENING_BALANCES)).filter(o => inRange(o.date) && !o.journalId && !o.keepLocal && !o.carriedFromYear);
    if (legacy.length) issues.push({ level: 'warn', title: 'أرصدة افتتاحية بلا قيد مقابل', detail: `${legacy.length} رصيد افتتاحي بطرف واحد (أُدخل قبل ربط حساب رأس المال). حوّلها من شاشة الأرصدة الافتتاحية (زر 🔁).` });

    return issues;
  }

  return { getLinks, saveLinks, prepareLines, audit, makeLocalizer, localDiff, ROUNDING_STATEMENT, NO_ACCOUNT_TOLERANCE };
})();
