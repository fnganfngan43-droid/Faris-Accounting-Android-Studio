/* =========================================================
   شاشة إقفال المخزون — ترحيل أرصدة نهاية السنة إلى الأرصدة الافتتاحية للسنة الجديدة
   ========================================================= */

const InvClosing = (function () {
  const $ = (id) => document.getElementById(id);
  const esc = (v) => Utils.escapeHtml(String(v ?? ''));
  const fmtNum = (n) => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 4 });
  const fmtMoney = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  let lastRows = [];

  async function render(container) {
    await YearEnd.refresh(); // يحدّث حالة السنوات ونافذة المخزون
    const cfg = YearEnd.getCfg();
    if (!cfg || !cfg.periods || !cfg.periods.length) {
      container.innerHTML = '<p class="hint">يجب إعداد فترات النظام من شاشة التهيئة أولًا.</p>';
      return;
    }
    const ctx = InvClosingService.context();
    const readOnly = YearEnd.isReadOnlySession();
    const [warehouses, mains] = await Promise.all([FarisDB.getAllRaw(STORES.INV_WAREHOUSES), FarisDB.getAllRaw(STORES.INV_GROUPS_MAIN)]);

    container.innerHTML = `
      ${readOnly ? `<p class="hint year-lock-note">🔒 السنة المالية ${YearEnd.getSessionYear()} مقفلة — العرض فقط. ادخل إلى السنة المفتوحة لتنفيذ الإقفال.</p>` : ''}
      ${ctx.alreadyClosed ? `<p class="hint year-lock-note">تم إقفال مخزون السنة ${ctx.sourceYear} مسبقًا (لا يمكن تكرار الإقفال). يمكنك التراجع عنه من الزر أدناه.</p>` : ''}
      <div class="info-card">
        <div class="info-row"><span>السنة المالية الحالية</span><b>${ctx.sourceYear}</b></div>
        <div class="info-row"><span>السنة المالية الجديدة</span><b>${ctx.targetYear}</b></div>
        <div class="info-row"><span>تاريخ الإقفال</span><b>${YearEnd.fmtDate(ctx.closingDate)}</b></div>
        <div class="info-row"><span>تاريخ الأرصدة الافتتاحية</span><b>${YearEnd.fmtDate(ctx.openingDate)}</b></div>
      </div>

      <div class="form-grid">
        <label class="optional">المخزن
          <select id="icl-wh"><option value="">كل المخازن</option>${warehouses.map(w => `<option value="${w.id}">${esc(w.name)}</option>`).join('')}</select>
        </label>
        <label class="optional">مجموعة الأصناف
          <select id="icl-group"><option value="">الكل</option>${mains.map(g => `<option value="${g.id}">${esc(g.name)}</option>`).join('')}</select>
        </label>
        <label class="optional">حالة الرصيد
          <select id="icl-status">
            <option value="">الكل</option><option value="موجب">رصيد موجب</option><option value="صفري">رصيد صفري</option>
            <option value="سالب">كمية سالبة</option><option value="خطأ">أصناف بها مشكلة (تكلفة/بيانات)</option>
          </select>
        </label>
        <label class="optional">البحث برقم الصنف أو اسمه<input type="text" id="icl-search" placeholder="ابحث عن صنف..."></label>
      </div>

      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-ghost" id="icl-preview">🔍 بحث ومعاينة</button>
        <button class="btn btn-primary" id="icl-run" ${readOnly || ctx.alreadyClosed ? 'disabled' : ''}>🔒 تنفيذ الإقفال</button>
        <button class="btn btn-ghost" id="icl-revert" ${readOnly ? 'disabled' : ''}>↩️ التراجع عن الإقفال</button>
      </div>
      <p class="hint">الأرصدة الافتتاحية الناتجة ليست مشتريات ولا وارد مخزني، ولا تُنشئ قيودًا محاسبية. الإقفال يشمل كل المخازن (كل مخزن برصيده المستقل) حتى لا يُفقد رصيد أي مخزن، وخيار المخزن للبحث والمعاينة.</p>

      <div id="icl-summary"></div>
      <div id="icl-problems"></div>
      <div class="table-scroll tall"><table class="data-table">
        <thead><tr><th>رقم الصنف</th><th>الصنف</th><th>المخزن</th><th>الوحدة</th><th>الكمية</th><th>تكلفة الوحدة</th><th>الإجمالي</th><th>الحالة</th></tr></thead>
        <tbody id="icl-rows"><tr><td colspan="8" class="empty-row">اضغط "بحث ومعاينة" لعرض أرصدة نهاية السنة</td></tr></tbody>
        <tfoot id="icl-foot"></tfoot>
      </table></div>
      <div id="icl-result"></div>

      <h4 class="section-title">سجل عمليات الإقفال</h4>
      <div class="table-scroll"><table class="data-table">
        <thead><tr><th>رقم الإقفال</th><th>السنة المصدر</th><th>السنة المستهدفة</th><th>التاريخ</th><th>الحالة</th><th>المستخدم</th><th>الأصناف</th><th>الكميات</th><th>القيمة</th><th>التراجع</th></tr></thead>
        <tbody id="icl-log"></tbody>
      </table></div>

      <div class="popup-sheet tall" id="icl-revert-popup">
        <div class="popup-header"><span>التراجع عن إقفال المخزون</span><button class="btn-close" id="icl-revert-close" type="button">✖️</button></div>
        <div id="icl-revert-body"></div>
      </div>
    `;

    $('icl-preview').addEventListener('click', onPreview);
    $('icl-run').addEventListener('click', onRun);
    $('icl-revert').addEventListener('click', onRevert);
    $('icl-revert-close').addEventListener('click', () => Utils.closeSheet($('icl-revert-popup')));
    ['icl-wh', 'icl-group', 'icl-status'].forEach(id => $(id).addEventListener('change', drawRows));
    $('icl-search').addEventListener('input', drawRows);
    drawLog();
  }

  /* ---------------- المعاينة ---------------- */
  async function onPreview() {
    const box = $('icl-rows');
    box.innerHTML = '<tr><td colspan="8" class="empty-row">جاري الحساب...</td></tr>';
    try {
      const ctx = InvClosingService.context();
      lastRows = await InvClosingService.computeBalances(ctx);
      drawRows();
    } catch (err) {
      box.innerHTML = '';
      Utils.toast(err.message || 'تعذّر حساب الأرصدة', 'error');
    }
  }

  function filteredRows() {
    const wh = $('icl-wh').value, grp = $('icl-group').value, st = $('icl-status').value;
    const q = $('icl-search').value.trim().toLowerCase();
    return lastRows.filter(r => {
      if (wh && String(r.warehouseId) !== wh) return false;
      if (grp && String(r.mainGroupId) !== grp) return false;
      if (st === 'خطأ' ? !r.problems.length : (st && r.status !== st)) return false;
      if (q && !(String(r.itemCode).toLowerCase().includes(q) || String(r.itemName).toLowerCase().includes(q))) return false;
      return true;
    });
  }

  function drawRows() {
    if (!lastRows.length) return;
    const rows = filteredRows();
    $('icl-rows').innerHTML = rows.map(r => `
      <tr class="${r.problems.length ? 'row-error' : ''}">
        <td>${esc(r.itemCode)}</td><td>${esc(r.itemName)}</td><td>${esc(r.warehouseName)}</td><td>${esc(r.unitName)}</td>
        <td>${fmtNum(r.quantity)}</td><td>${fmtMoney(r.unitCost)}</td><td>${fmtMoney(r.totalValue)}</td>
        <td>${r.problems.length ? '⚠️ ' + esc(r.problems.join('، ')) : esc(r.status)}</td>
      </tr>`).join('') || '<tr><td colspan="8" class="empty-row">لا توجد نتائج</td></tr>';

    const positive = rows.filter(r => r.status === 'موجب');
    const totalQty = positive.reduce((s, r) => s + r.quantity, 0);
    const totalValue = positive.reduce((s, r) => s + r.totalValueExact, 0);
    $('icl-foot').innerHTML = `<tr><td colspan="4"><b>الإجمالي (الأرصدة الموجبة)</b></td><td><b>${fmtNum(totalQty)}</b></td><td></td><td><b>${fmtMoney(totalValue)}</b></td><td></td></tr>`;

    const sum = InvClosingService.summarize(lastRows);
    $('icl-summary').innerHTML = `
      <div class="result-card ok">إجمالي الأصناف: <b>${sum.items}</b> — عدد الأرصدة (صنف × مخزن): <b>${sum.balances}</b> — إجمالي الكميات: <b>${fmtNum(sum.totalQty)}</b> — قيمة المخزون: <b>${fmtMoney(sum.totalValue)}</b></div>`;
    $('icl-problems').innerHTML = sum.problems.length
      ? `<div class="result-card warn">⚠️ ${sum.problems.length} رصيد به مشكلة يمنع الإقفال (تكلفة غير صالحة أو كمية سالبة...). صحّحها من بطاقة حركة الصنف ثم أعد المعاينة.</div>` : '';
  }

  /* ---------------- التنفيذ ---------------- */
  async function onRun() {
    const btn = $('icl-run');
    btn.disabled = true;
    try {
      const ctx = InvClosingService.context();
      lastRows = await InvClosingService.computeBalances(ctx);
      drawRows();
      const sum = InvClosingService.summarize(lastRows);
      if (sum.problems.length) {
        Utils.toast('يوجد أصناف بها مشكلة، راجع الجدول قبل الإقفال', 'error');
        return;
      }
      if (!sum.balances) { Utils.toast('لا توجد أرصدة مخزون لترحيلها', 'info'); return; }

      const ok = await Utils.confirmDialog(
        `سيتم إقفال مخزون السنة ${ctx.sourceYear} وترحيل ${sum.balances} رصيدًا (${sum.items} صنفًا) بقيمة ${fmtMoney(sum.totalValue)} كأرصدة افتتاحية للسنة ${ctx.targetYear} بتاريخ ${YearEnd.fmtDate(ctx.openingDate)}. هل تريد المتابعة؟`);
      if (!ok) return;

      const res = await InvClosingService.execute();
      if (!res.ok) {
        Utils.toast(res.empty ? 'لا توجد أرصدة لترحيلها' : 'تعذّر الإقفال: توجد أصناف بها مشكلة', 'error');
        if (res.problems) { lastRows = await InvClosingService.computeBalances(ctx); drawRows(); }
        return;
      }
      const c = res.closing;
      $('icl-result').innerHTML = `
        <div class="result-card ok">✅ تم إقفال المخزون بنجاح<br>
          رقم الإقفال: <b>${esc(c.id)}</b> — من ${c.sourceYear} إلى ${c.targetYear}<br>
          عدد الأرصدة المرحّلة: ${c.balancesCount} (${c.itemsCount} صنفًا) — إجمالي الكميات: ${fmtNum(c.totalQty)} — قيمة المخزون: ${fmtMoney(c.totalValue)}<br>
          ✔ تم التحقق من تطابق الأرصدة الافتتاحية للسنة الجديدة مع أرصدة نهاية السنة السابقة<br>
          المستخدم: ${esc(c.userName)} — ${new Date(c.createdAt).toLocaleString('ar')}
        </div>`;
      Utils.toast('تم إقفال المخزون بنجاح', 'success');
      await render($('icl-result').closest('.sub-content') || document.getElementById('inventory-content'));
      const again = document.getElementById('icl-result');
      if (again) again.innerHTML = `<div class="result-card ok">✅ تم إقفال المخزون بنجاح — رقم الإقفال ${esc(c.id)}: ${c.balancesCount} رصيدًا (${c.itemsCount} صنفًا)، الكميات ${fmtNum(c.totalQty)}، القيمة ${fmtMoney(c.totalValue)}. تم التحقق من تطابق الأرصدة الافتتاحية مع نهاية السنة السابقة.</div>`;
    } catch (err) {
      if (!err.toasted) Utils.toast(err.message || 'تعذّر تنفيذ الإقفال', 'error');
    } finally {
      const b = $('icl-run'); if (b) b.disabled = !!(YearEnd.isReadOnlySession() || (InvClosingService.context() || {}).alreadyClosed);
    }
  }

  /* ---------------- سجل الإقفال ---------------- */
  function drawLog() {
    const list = InvClosingService.getList().slice().reverse();
    $('icl-log').innerHTML = list.map(c => `
      <tr>
        <td>${esc(c.id)}</td><td>${c.sourceYear}</td><td>${c.targetYear}</td>
        <td>${YearEnd.fmtDate(c.closingDate)}</td>
        <td>${c.status === 'منفذ' ? 'مقفل' : 'متراجع عنه'}</td>
        <td>${esc(c.userName)}</td><td>${c.itemsCount}</td><td>${fmtNum(c.totalQty)}</td><td>${fmtMoney(c.totalValue)}</td>
        <td>${c.status === 'متراجع' ? `${esc((c.revertedAt || '').slice(0, 10))} — ${esc(c.revertedBy || '')}${c.revertReason ? ' — ' + esc(c.revertReason) : ''}` : ''}</td>
      </tr>`).join('') || '<tr><td colspan="10" class="empty-row">لا توجد عمليات إقفال بعد</td></tr>';
  }

  /* ---------------- التراجع ---------------- */
  async function onRevert() {
    const act = InvClosingService.getActive();
    if (!act.length) { Utils.toast('لا توجد عملية إقفال نشطة للتراجع عنها', 'info'); return; }
    // التراجع يكون عن آخر إقفال نشط فقط
    const target = act.slice().sort((a, b) => b.seq - a.seq)[0];
    const body = $('icl-revert-body');
    body.innerHTML = '<p class="hint">جاري فحص عمليات السنة الجديدة...</p>';
    Utils.openSheet($('icl-revert-popup'));
    try {
      const info = await InvClosingService.inspectRevert(target.id);
      drawRevert(info);
    } catch (err) {
      body.innerHTML = `<div class="result-card warn">${esc(err.message)}</div>`;
    }
  }

  function drawRevert(info) {
    const c = info.closing;
    const body = $('icl-revert-body');
    const header = `
      <div class="info-card">
        <div class="info-row"><span>رقم الإقفال</span><b>${esc(c.id)}</b></div>
        <div class="info-row"><span>من سنة ← إلى سنة</span><b>${c.sourceYear} ← ${c.targetYear}</b></div>
        <div class="info-row"><span>تاريخ الإقفال</span><b>${YearEnd.fmtDate(c.closingDate)}</b></div>
        <div class="info-row"><span>الأرصدة الافتتاحية التي ستُحذف</span><b>${info.carry.length}</b></div>
        <div class="info-row"><span>القيمة</span><b>${fmtMoney(c.totalValue)}</b></div>
      </div>
      <label class="required">سبب التراجع<input type="text" id="icl-reason" placeholder="اكتب سبب التراجع"></label>`;

    if (!info.ops.length) {
      body.innerHTML = `${header}
        <p class="hint">لا توجد عمليات في السنة الجديدة. سيُحذف رصيد الإقفال المحدد فقط ولن تُحذف أي بيانات مرجعية.</p>
        <div class="sheet-actions">
          <button type="button" class="btn btn-ghost" id="icl-cancel">إلغاء</button>
          <button type="button" class="btn btn-primary" id="icl-confirm-direct">تأكيد التراجع</button>
        </div>`;
      $('icl-cancel').addEventListener('click', () => Utils.closeSheet($('icl-revert-popup')));
      $('icl-confirm-direct').addEventListener('click', () => doDirect(c));
      return;
    }

    body.innerHTML = `${header}
      <div class="result-card warn" style="white-space:pre-line;">تعذر التراجع عن إقفال المخزون
توجد عمليات مسجلة في السنة المالية الجديدة.
يجب حذف عمليات السنة الجديدة أولاً حتى يمكن التراجع عن الإقفال.</div>
      <p class="hint">لن يتم حذف أي بيانات دون عرض التفاصيل وطلب موافقتك. العمليات المسجلة في السنة الجديدة (${info.ops.length}):</p>
      <div class="table-scroll"><table class="data-table"><thead><tr><th>نوع العملية</th><th>العدد</th><th>القيمة</th></tr></thead>
        <tbody>${info.groups.map(g => `<tr><td>${esc(g.type)}</td><td>${g.count}</td><td>${fmtMoney(g.value)}</td></tr>`).join('')}</tbody></table></div>
      ${info.blockedByAccounting ? '<div class="result-card warn">يوجد إقفال محاسبي في السنة الجديدة، تراجع عنه أولًا من شاشة المطابقة والترحيلات.</div>' : `
      <div class="result-card warn">⚠️ حذف عمليات السنة الجديدة سيؤدي إلى فقدان بياناتها نهائيًا (مع قيودها المحاسبية وحركاتها المخزنية). تُؤخذ نسخة احتياطية كاملة قبل الحذف، وتُستعاد الحالة كاملة إن فشلت أي خطوة. لا يُحذف دليل الحسابات ولا الأصناف ولا المخازن ولا الإعدادات ولا المستخدمون.</div>
      <label class="required">للتأكيد اكتب كلمة: حذف<input type="text" id="icl-confirm-word" autocomplete="off"></label>
      <div class="sheet-actions">
        <button type="button" class="btn btn-ghost" id="icl-cancel">إلغاء</button>
        <button type="button" class="btn btn-primary" id="icl-confirm-delete">حذف عمليات السنة الجديدة ثم التراجع عن الإقفال</button>
      </div>`}`;
    $('icl-cancel') && $('icl-cancel').addEventListener('click', () => Utils.closeSheet($('icl-revert-popup')));
    $('icl-confirm-delete') && $('icl-confirm-delete').addEventListener('click', () => doDelete(c, info));
  }

  function reasonOf() { return ($('icl-reason').value || '').trim(); }

  async function doDirect(c) {
    const reason = reasonOf();
    if (!reason) { Utils.toast('اكتب سبب التراجع', 'error'); return; }
    const ok = await Utils.confirmDialog(`هل تريد التراجع عن إقفال المخزون ${esc(c.id)}؟ سيتم حذف أرصدته الافتتاحية في السنة ${c.targetYear}.`);
    if (!ok) return;
    try {
      const res = await InvClosingService.revertDirect(c.id, reason);
      Utils.closeSheet($('icl-revert-popup'));
      Utils.toast(`تم التراجع عن الإقفال وحذف ${res.removed} رصيدًا افتتاحيًا`, 'success');
      await render(document.getElementById('icl-rows').closest('.sub-content') || document.getElementById('inventory-content'));
    } catch (err) {
      if (err.blocked) { drawRevert(err.info); return; }
      Utils.toast(err.message || 'تعذّر التراجع', 'error');
    }
  }

  async function doDelete(c, info) {
    const reason = reasonOf();
    if (!reason) { Utils.toast('اكتب سبب التراجع', 'error'); return; }
    if (($('icl-confirm-word').value || '').trim() !== 'حذف') { Utils.toast('اكتب كلمة "حذف" للتأكيد', 'error'); return; }
    const ok = await Utils.confirmDialog(`تأكيد نهائي: حذف ${info.ops.length} عملية من السنة ${c.targetYear} ثم التراجع عن الإقفال ${esc(c.id)}. لا يمكن التراجع عن الحذف إلا باستعادة النسخة الاحتياطية.`);
    if (!ok) return;
    const btn = $('icl-confirm-delete');
    btn.disabled = true;
    try {
      const res = await InvClosingService.deleteNewYearOpsAndRevert(c.id, reason);
      Utils.closeSheet($('icl-revert-popup'));
      Utils.toast(`تم حذف عمليات السنة الجديدة والتراجع عن الإقفال (${res.removed} رصيدًا افتتاحيًا)`, 'success');
      await render(document.getElementById('icl-rows').closest('.sub-content') || document.getElementById('inventory-content'));
    } catch (err) {
      Utils.toast(err.message || 'فشلت العملية وتمت استعادة الحالة السابقة', 'error');
      btn.disabled = false;
    }
  }

  return { render };
})();
