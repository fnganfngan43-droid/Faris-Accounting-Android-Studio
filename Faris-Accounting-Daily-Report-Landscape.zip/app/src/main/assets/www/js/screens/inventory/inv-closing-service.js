/* =========================================================
   خدمة إقفال المخزون وترحيل الأرصدة الافتتاحية
   - تحسب رصيد كل صنف في كل مخزن (بأصغر وحدة) وتكلفته من محرك حركة الصنف الحالي
     (متوسط تكلفة الوارد المرجَّح كما في بطاقة الصنف) دون تغيير طريقة التقييم.
   - تنشئ في السنة الجديدة أرصدة افتتاحية (سجلات مسطّحة INV_OPENING_STOCK) مربوطة برقم الإقفال
     بلا أي قيد محاسبي ولا حركة شراء/وارد (الحسابات تُرحَّل من إقفال الحسابات).
   - نافذة المخزون: بعد الإقفال تُحسب كميات السنة الجديدة من أرصدتها الافتتاحية فقط،
     وتبقى حركات السنة السابقة كما هي (لا ازدواج ولا خلط بين السنتين).
   - التراجع المباشر، أو حذف عمليات السنة الجديدة ثم التراجع بنسخة احتياطية واستعادة كاملة عند الفشل.
   ========================================================= */

const InvClosingService = (function () {
  const KEY = 'invClosings';
  const AUDIT_KEY = 'auditLog';
  const EPS = 1e-6;

  const state = { loaded: false, list: [] };
  let overrideWindow = null;

  const r6 = (n) => Math.round((Number(n) || 0) * 1e6) / 1e6;
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const active = () => state.list.filter(c => c.status === 'منفذ');

  async function loadState() {
    let rec = null;
    try { rec = await FarisDB.get(STORES.SETTINGS, KEY); } catch (_) { /* تجاهل */ }
    state.list = rec && Array.isArray(rec.list) ? rec.list : [];
    state.loaded = true;
  }

  async function saveList() {
    await FarisDB.withBypass(() => FarisDB.put(STORES.SETTINGS, { id: KEY, list: state.list }));
  }

  /* ---------------- نافذة المخزون ---------------- */
  // من آخر ترحيل أرصدة افتتاحية (للسنة المستهدفة ≤ Y) إلى تاريخ الإقفال إن كانت السنة Y مقفلة مخزونيًا
  function windowForYear(Y) {
    const act = active();
    if (!act.length || !Y) return null;
    let from = '', to = '';
    const prior = act.filter(c => c.targetYear <= Y).sort((a, b) => b.targetYear - a.targetYear)[0];
    if (prior) from = prior.openingDate;
    const own = act.find(c => c.sourceYear === Y);
    if (own) to = own.closingDate;
    return (from || to) ? { from, to } : null;
  }

  FarisDB.setStockWindowProvider(() => {
    if (overrideWindow) return overrideWindow;
    if (!state.loaded || typeof YearEnd === 'undefined') return null;
    return windowForYear(YearEnd.getSessionYear());
  });

  async function withWindow(w, fn) {
    const prev = overrideWindow;
    overrideWindow = w;
    try { return await fn(); } finally { overrideWindow = prev; }
  }

  /* ---------------- سياق الإقفال (السنة المصدر والمستهدفة) ---------------- */
  function context() {
    const cfg = YearEnd.getCfg();
    if (!cfg || !cfg.periods || !cfg.periods.length) return null;
    const years = YearEnd.getYears();
    const hasActive = (y) => active().some(c => c.sourceYear === y);

    let source = Number(cfg.year);
    let closingDate = YearEnd.yearRange(cfg).to;
    // إن سبق إقفال سنة الحسابات ولم يُقفل مخزونها بعد، فالمصدر هو تلك السنة المقفلة
    const lastClosed = years.length ? years.slice().sort((a, b) => Number(b.year) - Number(a.year))[0] : null;
    if (lastClosed && !hasActive(Number(lastClosed.year)) && Number(lastClosed.year) + 1 === Number(cfg.year)) {
      source = Number(lastClosed.year);
      closingDate = lastClosed.to;
    }
    return {
      sourceYear: source, targetYear: source + 1,
      closingDate, openingDate: YearEnd.addDays(closingDate, 1),
      alreadyClosed: hasActive(source)
    };
  }

  /* ---------------- المستخدم والتدقيق ---------------- */
  async function currentUser() {
    try {
      const sess = await FarisDB.get(STORES.SESSION, 'current');
      if (sess && sess.userId) {
        const u = await FarisDB.get(STORES.USERS, sess.userId);
        if (u) return { id: u.id, name: u.userName || String(u.userNumber || '') };
      }
    } catch (_) { /* تجاهل */ }
    return { id: null, name: 'غير محدد' };
  }

  async function appendAudit(entry) {
    let rec = null;
    try { rec = await FarisDB.get(STORES.SETTINGS, AUDIT_KEY); } catch (_) { /* تجاهل */ }
    const list = rec && Array.isArray(rec.list) ? rec.list : [];
    list.push({ at: new Date().toISOString(), ...entry });
    await FarisDB.withBypass(() => FarisDB.put(STORES.SETTINGS, { id: AUDIT_KEY, list: list.slice(-500) }));
  }

  /* ---------------- حساب الأرصدة ---------------- */
  function sourceFrom(sourceYear) {
    const prior = active().filter(c => c.targetYear <= sourceYear).sort((a, b) => b.targetYear - a.targetYear)[0];
    return prior ? prior.openingDate : '';
  }

  // يحسب رصيد كل (صنف × مخزن) وتكلفته من حركات السنة المصدر
  async function computeBalances(ctx) {
    const w = { from: sourceFrom(ctx.sourceYear), to: ctx.closingDate };
    const [items, warehouses, units, mains] = await Promise.all([
      FarisDB.getAllRaw(STORES.INV_ITEMS), FarisDB.getAllRaw(STORES.INV_WAREHOUSES),
      FarisDB.getAllRaw(STORES.INV_UNITS), FarisDB.getAllRaw(STORES.INV_GROUPS_MAIN)
    ]);
    const itemMap = new Map(items.map(i => [i.code, i]));
    const whMap = new Map(warehouses.map(x => [x.id, x]));
    const unitMap = new Map(units.map(u => [u.id, u.name]));
    const mainMap = new Map(mains.map(g => [g.id, g.name]));

    const movements = await withWindow(w, () => ItemMovementEngine.gatherAllMovements());
    const groups = new Map();
    movements.forEach(m => {
      if (!m.itemCode || m.warehouseId === undefined || m.warehouseId === null) return;
      const key = `${m.itemCode}|${m.warehouseId}`;
      let g = groups.get(key);
      if (!g) { g = { itemCode: m.itemCode, warehouseId: m.warehouseId, inBase: 0, outBase: 0, inValue: 0, inBaseForCost: 0, badCost: false, count: 0 }; groups.set(key, g); }
      g.count++;
      g.inBase += Number(m.incomingBaseQty) || 0;
      g.outBase += Number(m.outgoingBaseQty) || 0;
      if ((Number(m.incomingQty) || 0) > 0) {
        const cost = Number(m.unitCost);
        if (!isFinite(cost) || cost < 0) g.badCost = true;
        g.inValue += (Number(m.incomingQty) || 0) * (isFinite(cost) ? cost : 0);
        g.inBaseForCost += Number(m.incomingBaseQty) || 0;
      }
    });

    const rows = [];
    groups.forEach(g => {
      const item = itemMap.get(g.itemCode);
      const wh = whMap.get(g.warehouseId);
      const balance = r6(g.inBase - g.outBase);                       // بأصغر وحدة قياس
      const unitCostSmallest = g.inBaseForCost > 0 ? g.inValue / g.inBaseForCost : 0; // تكلفة أصغر وحدة
      const baseUnit = item && item.units && item.units.length ? (item.units.find(u => u.isBase) || item.units[0]) : null;
      const factor = baseUnit ? (Number(baseUnit.linkFactor) || 1) : 1;
      const totalValue = r6(balance * unitCostSmallest);

      const problems = [];
      if (!item) problems.push('الصنف غير موجود في بيانات الأصناف');
      else if (!baseUnit) problems.push('الصنف بلا وحدة قياس أساسية');
      if (!wh) problems.push('المخزن غير موجود');
      if (g.badCost) problems.push('تكلفة غير صالحة في إحدى حركات الصنف');
      if (balance < -EPS) problems.push('كمية سالبة');
      if (balance > EPS && !(unitCostSmallest > 0)) problems.push('تكلفة الوحدة غير موجودة أو غير صالحة');
      if (!isFinite(totalValue)) problems.push('إجمالي القيمة غير صالح');

      const status = balance < -EPS ? 'سالب' : (Math.abs(balance) <= EPS ? 'صفري' : 'موجب');
      rows.push({
        itemCode: g.itemCode, itemName: item ? item.name : '',
        warehouseId: g.warehouseId, warehouseName: wh ? wh.name : '',
        mainGroupId: item ? item.mainGroupId : null, mainGroupName: item ? (mainMap.get(item.mainGroupId) || '') : '',
        unitId: baseUnit ? baseUnit.unitId : null, unitName: baseUnit ? (unitMap.get(baseUnit.unitId) || '') : '',
        unitFactor: factor,
        balanceSmallest: balance,
        quantity: r6(balance / factor),                                // بالوحدة الأساسية
        unitCost: r6(unitCostSmallest * factor),                       // تكلفة الوحدة الأساسية
        totalValue: r2(totalValue), totalValueExact: totalValue,
        currencyId: wh ? wh.currencyId : null,
        status, problems, moveCount: g.count, item
      });
    });
    rows.sort((a, b) => String(a.itemCode).localeCompare(String(b.itemCode), undefined, { numeric: true }) || (a.warehouseId - b.warehouseId));
    return rows;
  }

  function summarize(rows) {
    const carry = rows.filter(r => r.status === 'موجب');
    return {
      balances: carry.length,
      items: new Set(carry.map(r => r.itemCode)).size,
      totalQty: r6(carry.reduce((s, r) => s + r.quantity, 0)),
      totalValue: r2(carry.reduce((s, r) => s + r.totalValueExact, 0)),
      problems: rows.filter(r => r.problems.length)
    };
  }

  /* ---------------- تنفيذ الإقفال ---------------- */
  async function execute() {
    const ctx = context();
    if (!ctx) throw new Error('لم يتم إعداد فترات النظام');
    if (YearEnd.isReadOnlySession()) throw new Error(`السنة المالية ${YearEnd.getSessionYear()} مقفلة، ادخل إلى السنة المفتوحة لتنفيذ الإقفال`);
    if (ctx.alreadyClosed) throw new Error(`تم إقفال مخزون السنة ${ctx.sourceYear} مسبقًا، لا يمكن تكرار الإقفال`);
    if (active().some(c => c.targetYear === ctx.targetYear)) throw new Error(`توجد أرصدة افتتاحية مرحّلة للسنة ${ctx.targetYear} مسبقًا`);

    const rows = await computeBalances(ctx);
    const bad = rows.filter(r => r.problems.length);
    if (bad.length) return { ok: false, problems: bad };
    const carryRows = rows.filter(r => r.status === 'موجب');
    if (!carryRows.length) return { ok: false, empty: true };

    const user = await currentUser();
    const seq = (state.list.reduce((m, c) => Math.max(m, c.seq || 0), 0)) + 1;
    const closingRef = `CLS-${String(seq).padStart(3, '0')}`;
    const created = [];

    try {
      for (const r of carryRows) {
        const item = r.item;
        const known = new Set(['code', 'name', 'mainGroupId', 'subGroupId', 'detailGroupId', 'units']);
        const extra = {};
        Object.keys(item || {}).forEach(k => { if (!known.has(k) && item[k] !== undefined && item[k] !== null && item[k] !== '') extra[k] = item[k]; });
        const id = await FarisDB.put(STORES.INV_OPENING_STOCK, {
          itemCode: r.itemCode, itemName: r.itemName, warehouseId: r.warehouseId,
          unitId: r.unitId, quantity: r.quantity, unitCost: r.unitCost, totalCost: r.totalValue,
          unitFactor: r.unitFactor, currencyId: r.currencyId,
          mainGroupId: item.mainGroupId ?? null, subGroupId: item.subGroupId ?? null, detailGroupId: item.detailGroupId ?? null,
          itemUnits: (item.units || []).map(u => ({ unitId: u.unitId, package: u.package, linkFactor: u.linkFactor, isBase: !!u.isBase })),
          ...(item.weight !== undefined ? { weight: item.weight } : {}),
          ...(Object.keys(extra).length ? { itemExtra: extra } : {}),
          date: ctx.openingDate, closingId: closingRef, closingRef,
          sourceYear: ctx.sourceYear, targetYear: ctx.targetYear, carried: true
        });
        created.push(id);
      }

      // التحقق: مطابقة الأرصدة الافتتاحية للسنة الجديدة مع أرصدة نهاية السنة السابقة
      const check = await withWindow({ from: ctx.openingDate, to: ctx.openingDate }, () => ItemMovementEngine.gatherAllMovements());
      const opening = new Map();
      check.forEach(m => {
        const k = `${m.itemCode}|${m.warehouseId}`;
        opening.set(k, (opening.get(k) || 0) + (Number(m.incomingBaseQty) || 0) - (Number(m.outgoingBaseQty) || 0));
      });
      let mismatch = null;
      carryRows.forEach(r => {
        const got = opening.get(`${r.itemCode}|${r.warehouseId}`) || 0;
        if (Math.abs(got - r.balanceSmallest) > 1e-4) mismatch = mismatch || r;
      });
      if (mismatch) throw new Error(`عدم تطابق الأرصدة الافتتاحية للصنف ${mismatch.itemCode} (${mismatch.itemName})، أُلغيت العملية`);
      if (opening.size !== carryRows.length) throw new Error('عدد الأرصدة الافتتاحية الناتجة لا يطابق أرصدة نهاية السنة، أُلغيت العملية');
    } catch (err) {
      await FarisDB.withBypass(async () => { for (const id of created) { try { await FarisDB.remove(STORES.INV_OPENING_STOCK, id); } catch (_) { /* تجاهل */ } } });
      throw err;
    }

    const sum = summarize(rows);
    const closing = {
      id: closingRef, seq, sourceYear: ctx.sourceYear, targetYear: ctx.targetYear,
      closingDate: ctx.closingDate, openingDate: ctx.openingDate, status: 'منفذ',
      createdAt: new Date().toISOString(), userId: user.id, userName: user.name,
      itemsCount: sum.items, balancesCount: sum.balances, totalQty: sum.totalQty, totalValue: sum.totalValue,
      carryIds: created
    };
    state.list.push(closing);
    try {
      await saveList();
    } catch (err) {
      state.list.pop();
      await FarisDB.withBypass(async () => { for (const id of created) { try { await FarisDB.remove(STORES.INV_OPENING_STOCK, id); } catch (_) { /* تجاهل */ } } });
      throw err;
    }
    await appendAudit({ action: 'إقفال المخزون', closingId: closingRef, userId: user.id, userName: user.name,
      details: `ترحيل ${sum.balances} رصيدًا (${sum.items} صنفًا) من ${ctx.sourceYear} إلى ${ctx.targetYear}، القيمة ${sum.totalValue}` });
    return { ok: true, closing, rows: carryRows, summary: sum };
  }

  /* ---------------- عمليات السنة الجديدة ---------------- */
  const NUM_KEYS = ['netLocal', 'net', 'total', 'totalLocal', 'amountLocal', 'amount'];
  const numOf = (obj) => { for (const k of NUM_KEYS) if (typeof obj[k] === 'number' && isFinite(obj[k])) return obj[k]; return null; };

  // كل عمليات المستخدم المسجَّلة بعد تاريخ الأرصدة الافتتاحية (باستثناء أرصدة المخزون المرحَّلة وترحيل أرصدة الحسابات)
  async function findNewYearOps(openingDate) {
    return withoutScopeSafe(async () => {
      const autoMap = await ReportData.getAutoEntryMap();
      const after = (d) => !!d && d >= openingDate;
      const ops = [];
      const add = (type, store, rec, value, extra) => ops.push({ type, store, id: rec.id, value: value ?? 0, rec, ...(extra || {}) });

      for (const [store, label] of [[STORES.SALES_INVOICES, 'فواتير مبيعات'], [STORES.SALES_RETURNS, 'مرتجع المبيعات'],
        [STORES.PURCHASE_INVOICES, 'فواتير مشتريات'], [STORES.PURCHASE_RETURNS, 'مرجوع المشتريات']]) {
        (await FarisDB.getAllRaw(store)).filter(r => after(r.date)).forEach(r => add(label, store, r, numOf(r)));
      }
      (await FarisDB.getAllRaw(STORES.INV_OPENING_STOCK_DOCS)).filter(r => after(r.date)).forEach(r =>
        add('المخزون الافتتاحي', STORES.INV_OPENING_STOCK_DOCS, r, (r.lines || []).reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.cost) || 0), 0)));
      (await FarisDB.getAllRaw(STORES.VOUCHERS)).filter(r => after(r.date)).forEach(r =>
        add(r.type === 'receipt' ? 'سندات قبض' : 'سندات صرف', STORES.VOUCHERS, r, r.debitSide ? Number(r.debitSide.amount) || 0 : 0));
      (await FarisDB.getAllRaw(STORES.CURRENCY_EXCHANGES)).filter(r => after(r.date)).forEach(r => add('صرف عملة', STORES.CURRENCY_EXCHANGES, r, Number(r.fromAmount) || 0));
      (await FarisDB.getAllRaw(STORES.JOURNAL)).filter(r => after(r.date) && !autoMap.has(r.id) && !ReportData.isSystemEntry(r)).forEach(r =>
        add('قيود يومية', STORES.JOURNAL, r, (r.lines || []).reduce((s, l) => s + (Number(l.debit) || 0), 0)));
      (await FarisDB.getAllRaw(STORES.OPENING_BALANCES)).filter(r => after(r.date) && !r.carriedFromYear && r.keepLocal !== true).forEach(r =>
        add('أرصدة افتتاحية (حسابات)', STORES.OPENING_BALANCES, r, (Number(r.debit) || 0) + (Number(r.credit) || 0)));

      // إقفال محاسبي موجود في السنة الجديدة يمنع الحذف المباشر (يجب التراجع عنه أولًا من شاشته)
      const blockedByAccounting = (await FarisDB.getAllRaw(STORES.JOURNAL)).some(e => after(e.date) && ReportData.isClosingEntry(e));
      return { ops, blockedByAccounting };
    });
  }

  async function withoutScopeSafe(fn) { return FarisDB.withoutScope(fn); }

  function groupOps(ops) {
    const by = new Map();
    ops.forEach(o => {
      const g = by.get(o.type) || { type: o.type, count: 0, value: 0 };
      g.count++; g.value += Number(o.value) || 0;
      by.set(o.type, g);
    });
    return [...by.values()].map(g => ({ ...g, value: r2(g.value) }));
  }

  async function inspectRevert(closingId) {
    const c = state.list.find(x => x.id === closingId);
    if (!c || c.status !== 'منفذ') throw new Error('عملية الإقفال غير موجودة أو متراجع عنها');
    const later = active().find(x => x.id !== c.id && x.sourceYear >= c.targetYear);
    if (later) throw new Error(`لا يمكن التراجع قبل التراجع عن الإقفال اللاحق ${later.id}`);
    const { ops, blockedByAccounting } = await findNewYearOps(c.openingDate);
    const carry = (await FarisDB.getAllRaw(STORES.INV_OPENING_STOCK)).filter(r => r.closingId === c.id);
    return { closing: c, ops, groups: groupOps(ops), blockedByAccounting, carry };
  }

  /* ---------------- التراجع ---------------- */
  async function finishRevert(c, reason, user, extraDetails) {
    const carry = (await FarisDB.getAllRaw(STORES.INV_OPENING_STOCK)).filter(r => r.closingId === c.id);
    await FarisDB.withBypass(async () => { for (const r of carry) await FarisDB.remove(STORES.INV_OPENING_STOCK, r.id); });
    c.status = 'متراجع';
    c.revertedAt = new Date().toISOString();
    c.revertedBy = user.name; c.revertedById = user.id;
    c.revertReason = reason || '';
    await saveList();
    await appendAudit({ action: 'التراجع عن إقفال المخزون', closingId: c.id, userId: user.id, userName: user.name,
      details: `حذف ${carry.length} رصيدًا افتتاحيًا${reason ? ` — السبب: ${reason}` : ''}${extraDetails ? ` — ${extraDetails}` : ''}` });
    return carry.length;
  }

  // الحالة الأولى: لا عمليات في السنة الجديدة
  async function revertDirect(closingId, reason) {
    const info = await inspectRevert(closingId);
    if (info.ops.length) {
      const err = new Error('تعذر التراجع عن إقفال المخزون\nتوجد عمليات مسجلة في السنة المالية الجديدة.\nيجب حذف عمليات السنة الجديدة أولاً حتى يمكن التراجع عن الإقفال.');
      err.blocked = true; err.info = info;
      throw err;
    }
    const user = await currentUser();
    const removed = await finishRevert(info.closing, reason, user);
    return { removed };
  }

  // الحالة الثانية: حذف عمليات السنة الجديدة ثم التراجع (نسخة احتياطية + استعادة كاملة عند الفشل)
  async function deleteNewYearOpsAndRevert(closingId, reason) {
    const info = await inspectRevert(closingId);
    if (info.blockedByAccounting) throw new Error('يوجد إقفال محاسبي في السنة الجديدة، تراجع عنه أولًا من شاشة المطابقة والترحيلات');
    const user = await currentUser();

    // 1) نسخة احتياطية كاملة (يُوقف العملية إن تعذّر حفظها)
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const dump = await FarisDB.exportAll();
    const saved = await Utils.saveFile(JSON.stringify(dump), `faris-backup-قبل-التراجع-${info.closing.id}-${stamp}.json`, 'application/json');
    if (!saved) throw new Error('تعذّر حفظ النسخة الاحتياطية، لم يُنفَّذ أي حذف');

    // 2) لقطة للمخازن المتأثرة للاستعادة الكاملة عند أي فشل
    const affected = [STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES, STORES.SALES_INVOICES, STORES.SALES_RETURNS,
      STORES.PURCHASE_INVOICES, STORES.PURCHASE_RETURNS, STORES.INV_OPENING_STOCK_DOCS, STORES.INV_OPENING_STOCK,
      STORES.OPENING_BALANCES, STORES.SETTINGS];
    const snapshot = {};
    for (const s of affected) snapshot[s] = await FarisDB.getAllRaw(s);

    try {
      const deleted = await FarisDB.withBypass(() => FarisDB.withoutScope(async () => {
        const counts = {};
        for (const o of info.ops) {
          const rec = o.rec;
          if (o.store === STORES.INV_OPENING_STOCK_DOCS) {
            const flat = (await FarisDB.getAllRaw(STORES.INV_OPENING_STOCK)).filter(f => f.docId === rec.id);
            for (const f of flat) await FarisDB.remove(STORES.INV_OPENING_STOCK, f.id);
          }
          if (rec.journalId) { try { await FarisDB.remove(STORES.JOURNAL, rec.journalId); } catch (_) { /* قد يكون محذوفًا */ } }
          await FarisDB.remove(o.store, rec.id);
          counts[o.type] = (counts[o.type] || 0) + 1;
        }
        return counts;
      }));

      // 3) التأكد من عدم بقاء عمليات في السنة الجديدة
      const again = await findNewYearOps(info.closing.openingDate);
      if (again.ops.length) throw new Error(`بقيت ${again.ops.length} عملية في السنة الجديدة بعد الحذف`);

      // 4) التراجع عن الإقفال
      const details = Object.entries(deleted).map(([t, n]) => `${t}: ${n}`).join('، ');
      const c = state.list.find(x => x.id === closingId);
      const removed = await finishRevert(c, reason, user, `حُذفت عمليات السنة الجديدة (${details || 'لا شيء'}) بعد نسخة احتياطية`);
      return { removed, deleted, backupSaved: true };
    } catch (err) {
      // فشل: استعادة كل المخازن المتأثرة كما كانت
      try { await FarisDB.importAll(snapshot); } catch (restoreErr) { err.message += ' — وتعذّرت الاستعادة التلقائية، استعد النسخة الاحتياطية يدويًا'; }
      await loadState();
      throw err;
    }
  }

  return {
    loadState, context, computeBalances, summarize, execute, inspectRevert, revertDirect, deleteNewYearOpsAndRevert,
    windowForYear, getList: () => state.list.slice(), getActive: active
  };
})();
