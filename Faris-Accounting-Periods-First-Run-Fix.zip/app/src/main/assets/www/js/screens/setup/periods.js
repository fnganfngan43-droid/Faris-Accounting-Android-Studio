/* تهيئة فترات النظام */
const SetupPeriods = (function () {
  const KEY = 'systemPeriods';
  const TRANSACTION_STORES = [STORES.OPENING_BALANCES, STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES, STORES.SALES, STORES.SALES_RETURNS, STORES.PURCHASE_INVOICES, STORES.PURCHASE_RETURNS, STORES.PURCHASE_DISCOUNTS, STORES.DISCOUNTS, STORES.INV_OPENING_STOCK, STORES.INV_OPENING_STOCK_DOCS, STORES.SALES_INVOICES];
  let container;
  let saved = null;
  let editMode = false;

  function init() {}

  async function hasTransactions() {
    for (const store of TRANSACTION_STORES) {
      try { if ((await FarisDB.getAll(store)).length) return true; } catch (_) {}
    }
    return false;
  }

  async function render(root) {
    container = root;
    saved = await getConfig();
    const locked = await hasTransactions();
    editMode = !saved;
    container.innerHTML = `
      <section class="setup-periods">
        <div class="screen-actions">
          <button class="btn btn-primary" id="periods-save" title="حفظ" ${locked && saved ? 'disabled' : ''}>💾 حفظ</button>
          <button class="btn btn-ghost" id="periods-edit" title="تعديل" ${!saved || locked ? 'disabled' : ''}>✏️ تعديل</button>
        </div>
        ${locked && saved ? '<p class="hint period-lock-note">تم قفل تهيئة الفترات لوجود عمليات مسجلة في النظام.</p>' : ''}
        <div class="form-grid">
          <label class="required">نوع الفترات<select id="period-type" required><option value="monthly">شهري</option></select></label>
          <label class="required">السنة المالية<input id="period-year" type="number" min="2000" max="2100" placeholder="2026" required></label>
          <label class="required">عداد الفترات<input id="period-count" type="number" min="1" max="12" step="1" placeholder="12" required></label>
          <label class="required">بداية الفترة (رقم الشهر)<input id="period-start" type="number" min="1" max="12" placeholder="1" required></label>
          <label class="required">إلى نهاية الفترة (رقم الشهر)<input id="period-end" type="number" min="1" max="12" placeholder="12" required></label>
        </div>
        <div class="sheet-actions"><button class="btn btn-primary" id="periods-generate" ${locked && saved ? 'disabled' : ''}>⬇️ إنزال الأشهر</button></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>رقم الفترة</th><th>الشهر</th><th>من تاريخ</th><th>إلى تاريخ</th></tr></thead><tbody id="periods-rows"><tr><td colspan="4" class="hint">أدخل بيانات الفترات ثم اضغط إنزال الأشهر</td></tr></tbody></table></div>
        <p class="hint">يجب إعداد الفترات قبل تسجيل أي عملية. لا يمكن تعديل الفترات بعد تسجيل العمليات.</p>
      </section>`;
    const set = (id, value) => { const el = container.querySelector('#' + id); if (el) el.value = value ?? ''; };
    if (saved) {
      set('period-type', saved.periodType || 'monthly'); set('period-year', saved.year); set('period-count', saved.count); set('period-start', saved.startMonth); set('period-end', saved.endMonth);
      drawRows(saved.periods || []);
      if (locked) setFormDisabled(true);
    }
    container.querySelector('#periods-generate').addEventListener('click', generate);
    container.querySelector('#periods-save').addEventListener('click', save);
    container.querySelector('#periods-edit').addEventListener('click', async () => {
      if (await hasTransactions()) { Utils.toast('لا يمكن تعديل الفترات بعد إضافة أي عملية', 'error'); return; }
      editMode = true; setFormDisabled(false); container.querySelector('#periods-generate').disabled = false; container.querySelector('#periods-save').disabled = false;
    });
    if (!saved) generate();
  }

  function setFormDisabled(disabled) {
    ['period-type','period-year','period-count','period-start','period-end','periods-generate'].forEach(id => { const el = container.querySelector('#'+id); if (el) el.disabled = disabled; });
  }

  function generate() {
    const year = Number(container.querySelector('#period-year').value);
    const count = Number(container.querySelector('#period-count').value);
    const start = Number(container.querySelector('#period-start').value);
    const end = Number(container.querySelector('#period-end').value);
    if (!year || year < 2000 || year > 2100 || !Number.isInteger(count) || count < 1 || count > 12 || !Number.isInteger(start) || !Number.isInteger(end) || start < 1 || end > 12 || start > end) {
      Utils.toast('أدخل السنة المالية وعدد الفترات وشهر البداية والنهاية بشكل صحيح', 'error'); return;
    }
    if (count !== end - start + 1) { Utils.toast('عداد الفترات يجب أن يساوي عدد الأشهر بين البداية والنهاية', 'error'); return; }
    const names = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
    const periods = [];
    for (let m = start; m <= end; m++) {
      const lastDay = new Date(year, m, 0).getDate();
      periods.push({ number: periods.length + 1, month: m, name: names[m-1], from: `${year}-${String(m).padStart(2,'0')}-01`, to: `${year}-${String(m).padStart(2,'0')}-${String(lastDay).padStart(2,'0')}` });
    }
    drawRows(periods);
    container.dataset.periods = JSON.stringify(periods);
  }

  function drawRows(periods) {
    const tbody = container.querySelector('#periods-rows');
    if (!tbody) return;
    tbody.innerHTML = periods.length ? periods.map(p => `<tr><td>${p.number}</td><td>${p.name}</td><td>${p.from}</td><td>${p.to}</td></tr>`).join('') : '<tr><td colspan="4">لا توجد فترات</td></tr>';
    container.dataset.periods = JSON.stringify(periods);
  }

  async function save() {
    if (await hasTransactions()) { Utils.toast('لا يمكن حفظ أو تعديل الفترات بعد إضافة أي عملية', 'error'); return; }
    if (saved && !editMode) { Utils.toast('اضغط تعديل أولاً لتعديل الفترات', 'info'); return; }
    const periods = JSON.parse(container.dataset.periods || '[]');
    if (!periods.length) { Utils.toast('اضغط إنزال الأشهر أولاً', 'error'); return; }
    const year = Number(container.querySelector('#period-year').value);
    if (periods.some(p => Number(p.from.slice(0,4)) !== year)) { Utils.toast('أنزل الأشهر بعد التأكد من السنة المالية', 'error'); return; }
    const record = { id: KEY, periodType: 'monthly', year, count: Number(container.querySelector('#period-count').value), startMonth: Number(container.querySelector('#period-start').value), endMonth: Number(container.querySelector('#period-end').value), periods, configuredAt: new Date().toISOString() };
    await FarisDB.put(STORES.SETTINGS, record);
    try { localStorage.setItem('faris_systemPeriods_config', JSON.stringify(record)); } catch (error) { console.warn('تعذر حفظ النسخة الاحتياطية لفترات النظام', error); }
    saved = record; editMode = false; window.__periodsConfigured = true;
    Utils.toast('تم حفظ تهيئة فترات النظام بنجاح', 'success');
    await render(container);
  }

  // مصدر الحفظ الأساسي IndexedDB، مع نسخة احتياطية في localStorage لضمان
  // بقاء التهيئة بين جلسات WebView وإعادة تشغيل التطبيق.
  async function getConfig() {
    let record = null;
    try { record = await FarisDB.get(STORES.SETTINGS, KEY); } catch (error) { console.warn('تعذر قراءة فترات النظام من قاعدة البيانات', error); }
    if (isValidConfig(record)) return record;
    try {
      const backup = JSON.parse(localStorage.getItem('faris_systemPeriods_config') || 'null');
      if (isValidConfig(backup)) {
        try { await FarisDB.put(STORES.SETTINGS, backup); } catch (_) {}
        return backup;
      }
    } catch (error) { console.warn('تعذر قراءة النسخة الاحتياطية لفترات النظام', error); }
    return record;
  }

  function isValidConfig(record) {
    return !!(record && Number(record.year) >= 2000 && Number(record.year) <= 2100 &&
      Number.isInteger(Number(record.count)) && Number(record.count) >= 1 && Number(record.count) <= 12 &&
      Number.isInteger(Number(record.startMonth)) && Number(record.startMonth) >= 1 &&
      Number.isInteger(Number(record.endMonth)) && Number(record.endMonth) <= 12 &&
      Array.isArray(record.periods) && record.periods.length === Number(record.count));
  }
  return { init, render, getConfig, hasTransactions };
})();
