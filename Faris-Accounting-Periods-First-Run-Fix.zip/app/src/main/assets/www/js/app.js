/* =========================================================
   FARIS ACCOUNTING - app.js
   المسيّر الرئيسي للشاشات (Router) وبدء تشغيل التطبيق
   ========================================================= */

const App = (function () {
  const stack = []; // مكدس التنقل بين الشاشات الرئيسية (لزر الرجوع للخلف بالجهاز)

  const screens = {}; // screenName -> { onShow, onHide }

  function register(name, handlers) {
    screens[name] = handlers || {};
  }

  function show(name, opts = {}) {
    const protectedScreens = ['chart', 'operations', 'inventory', 'reports', 'sales', 'purchases'];
    if (protectedScreens.includes(name) && window.__periodsConfigured !== true) {
      if (window.Utils && Utils.toast) Utils.toast('يجب إعداد فترات النظام من شاشة التهيئة قبل إدخال أي عملية', 'error');
      name = 'setup'; opts = { replace: true, params: { tab: 'periods' } };
    }
    document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
    const target = document.getElementById(`screen-${name}`);
    if (!target) {
      console.error('Screen not found:', name);
      return;
    }
    target.classList.add('active');

    if (!opts.replace) {
      stack.push(name);
    } else if (stack.length) {
      stack[stack.length - 1] = name;
    } else {
      stack.push(name);
    }

    if (screens[name] && typeof screens[name].onShow === 'function') {
      screens[name].onShow(opts.params || {});
    }
  }

  function back() {
    if (stack.length > 1) {
      stack.pop();
      const prev = stack[stack.length - 1];
      show(prev, { replace: true });
      return true;
    }
    return false;
  }

  // نقطة دخول زر الرجوع الفعلي في Android. لا نسمح بإغلاق التطبيق
  // إلا من الشاشة الرئيسية وبعد تأكيد المستخدم.
  function systemBack() {
    if (back()) return;

    const current = stack.length ? stack[stack.length - 1] : '';
    if (current === 'home') {
      if (window.AndroidNavigation && typeof AndroidNavigation.confirmExit === 'function') {
        AndroidNavigation.confirmExit();
      } else {
        window.confirm('هل تريد الخروج من التطبيق؟');
      }
    }
  }

  // دعم الرجوع عند استخدام سجل المتصفح، مع إبقاء زر Android على مكدس التطبيق.
  window.addEventListener('popstate', () => {
    systemBack();
  });

  async function bootstrap() {
    await FarisDB.open();
    await FarisDB.seedIfNeeded();
    // تهيئة السنة المالية مطلوبة عند التشغيل الأول فقط.
    // نعتمد على الإعداد المحفوظ في IndexedDB ولا نعيد ضبط الحالة عند كل دخول.
    let periodConfig = null;
    try {
      periodConfig = await SetupPeriods.getConfig();
    } catch (error) {
      console.error('تعذر قراءة تهيئة فترات النظام:', error);
    }
    window.__periodsConfigured = !!(
      periodConfig &&
      Number(periodConfig.year) >= 2000 &&
      Number(periodConfig.year) <= 2100 &&
      Number.isInteger(Number(periodConfig.count)) &&
      Number(periodConfig.count) >= 1 && Number(periodConfig.count) <= 12 &&
      Number.isInteger(Number(periodConfig.startMonth)) && Number(periodConfig.startMonth) >= 1 &&
      Number.isInteger(Number(periodConfig.endMonth)) && Number(periodConfig.endMonth) <= 12 &&
      Array.isArray(periodConfig.periods) &&
      periodConfig.periods.length === Number(periodConfig.count)
    );

    ScreenWelcome.init();
    ScreenHome.init();
    ScreenSetup.init();
    ScreenChart.init();
    ScreenOperations.init();
    ScreenReports.init();
    ScreenInventory.init();
    ScreenSales.init();
    ScreenPurchases.init();

    show('welcome');

    // التحقق من النسخ الاحتياطي التلقائي (كل 12 ساعة) عند فتح التطبيق
    SetupBackup.checkAutoBackup();
  }

  document.addEventListener('DOMContentLoaded', bootstrap);

  return { register, show, back, systemBack };
})();
