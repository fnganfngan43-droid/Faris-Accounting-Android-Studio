/* =========================================================
   FARIS ACCOUNTING - db.js
   طبقة قاعدة البيانات (IndexedDB) - المرحلة الأولى
   ========================================================= */

const DB_NAME = 'FarisAccountingDB';
const DB_VERSION = 9;

const STORES = {
  USERS: 'users',
  COUNTRIES: 'countries',
  GOVERNORATES: 'governorates',
  LOCATIONS: 'locations',
  CURRENCIES: 'currencies',
  SETTINGS: 'settings',
  BACKUP_SETTINGS: 'backupSettings',
  ACCOUNTS: 'accounts',
  CUSTOMERS: 'customers',
  CASHBOXES: 'cashboxes',
  BANKS: 'banks',
  SUPPLIERS: 'suppliers',
  SESSION: 'session',
  OPENING_BALANCES: 'openingBalances',
  JOURNAL: 'journalEntries',
  VOUCHERS: 'vouchers',
  CURRENCY_EXCHANGES: 'currencyExchanges',
  SALES: 'sales',
  SALES_RETURNS: 'salesReturns',
  PURCHASE_INVOICES: 'purchaseInvoices',
  PURCHASE_RETURNS: 'purchaseReturns',
  PURCHASE_DISCOUNTS: 'purchaseDiscounts',
  PURCHASE_SETTINGS: 'purchaseSettings',
  DISCOUNTS: 'discounts',
  INV_UNITS: 'invUnits',
  INV_GROUPS_MAIN: 'invGroupsMain',
  INV_GROUPS_SUB: 'invGroupsSub',
  INV_GROUPS_DETAIL: 'invGroupsDetail',
  INV_WAREHOUSES: 'invWarehouses',
  INV_WAREHOUSE_GROUPS: 'invWarehouseGroups',
  INV_GL_MAPPING: 'invGlMapping',
  INV_ITEMS: 'invItems',
  INV_OPENING_STOCK: 'invOpeningStock',
  INV_OPENING_STOCK_DOCS: 'invOpeningStockDocs',
  INV_SETTINGS: 'invSettings',
  SALES_SETTINGS: 'salesSettings',
  SALES_INVOICES: 'salesInvoices'
};

const FarisDB = (function () {
  let dbInstance = null;

  function open() {
    return new Promise((resolve, reject) => {
      if (dbInstance) return resolve(dbInstance);

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains(STORES.USERS)) {
          const s = db.createObjectStore(STORES.USERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('userNumber', 'userNumber', { unique: true });
        }

        if (!db.objectStoreNames.contains(STORES.COUNTRIES)) {
          db.createObjectStore(STORES.COUNTRIES, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.GOVERNORATES)) {
          const s = db.createObjectStore(STORES.GOVERNORATES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('countryId', 'countryId', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.LOCATIONS)) {
          const s = db.createObjectStore(STORES.LOCATIONS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('countryId', 'countryId', { unique: false });
          s.createIndex('governorateId', 'governorateId', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.CURRENCIES)) {
          db.createObjectStore(STORES.CURRENCIES, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
          db.createObjectStore(STORES.SETTINGS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORES.BACKUP_SETTINGS)) {
          db.createObjectStore(STORES.BACKUP_SETTINGS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORES.ACCOUNTS)) {
          const s = db.createObjectStore(STORES.ACCOUNTS, { keyPath: 'code' });
          s.createIndex('parentCode', 'parentCode', { unique: false });
          s.createIndex('rank', 'rank', { unique: false });
          s.createIndex('analyticType', 'analyticType', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.CUSTOMERS)) {
          const s = db.createObjectStore(STORES.CUSTOMERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.CASHBOXES)) {
          const s = db.createObjectStore(STORES.CASHBOXES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.BANKS)) {
          const s = db.createObjectStore(STORES.BANKS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.SUPPLIERS)) {
          const s = db.createObjectStore(STORES.SUPPLIERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.SESSION)) {
          db.createObjectStore(STORES.SESSION, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORES.OPENING_BALANCES)) {
          const s = db.createObjectStore(STORES.OPENING_BALANCES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('accountCode', 'accountCode', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.JOURNAL)) {
          db.createObjectStore(STORES.JOURNAL, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.VOUCHERS)) {
          const s = db.createObjectStore(STORES.VOUCHERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('type', 'type', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.CURRENCY_EXCHANGES)) {
          db.createObjectStore(STORES.CURRENCY_EXCHANGES, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.SALES)) {
          db.createObjectStore(STORES.SALES, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.SALES_RETURNS)) {
          db.createObjectStore(STORES.SALES_RETURNS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_INVOICES)) {
          db.createObjectStore(STORES.PURCHASE_INVOICES, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_RETURNS)) {
          db.createObjectStore(STORES.PURCHASE_RETURNS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_DISCOUNTS)) {
          db.createObjectStore(STORES.PURCHASE_DISCOUNTS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_SETTINGS)) {
          db.createObjectStore(STORES.PURCHASE_SETTINGS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.DISCOUNTS)) {
          db.createObjectStore(STORES.DISCOUNTS, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.INV_UNITS)) {
          db.createObjectStore(STORES.INV_UNITS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GROUPS_MAIN)) {
          db.createObjectStore(STORES.INV_GROUPS_MAIN, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GROUPS_SUB)) {
          const s = db.createObjectStore(STORES.INV_GROUPS_SUB, { keyPath: 'id', autoIncrement: true });
          s.createIndex('mainGroupId', 'mainGroupId', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GROUPS_DETAIL)) {
          const s = db.createObjectStore(STORES.INV_GROUPS_DETAIL, { keyPath: 'id', autoIncrement: true });
          s.createIndex('subGroupId', 'subGroupId', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_WAREHOUSES)) {
          db.createObjectStore(STORES.INV_WAREHOUSES, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_ITEMS)) {
          const s = db.createObjectStore(STORES.INV_ITEMS, { keyPath: 'code' });
          s.createIndex('mainGroupId', 'mainGroupId', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_OPENING_STOCK)) {
          const s = db.createObjectStore(STORES.INV_OPENING_STOCK, { keyPath: 'id', autoIncrement: true });
          s.createIndex('itemCode', 'itemCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_OPENING_STOCK_DOCS)) {
          db.createObjectStore(STORES.INV_OPENING_STOCK_DOCS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_SETTINGS)) {
          db.createObjectStore(STORES.INV_SETTINGS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.INV_WAREHOUSE_GROUPS)) {
          db.createObjectStore(STORES.INV_WAREHOUSE_GROUPS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GL_MAPPING)) {
          db.createObjectStore(STORES.INV_GL_MAPPING, { keyPath: 'warehouseGroupId' });
        }
        if (!db.objectStoreNames.contains(STORES.SALES_SETTINGS)) {
          db.createObjectStore(STORES.SALES_SETTINGS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.SALES_INVOICES)) {
          const s = db.createObjectStore(STORES.SALES_INVOICES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('customerId', 'customerId', { unique: false });
        }
      };

      request.onsuccess = (event) => {
        dbInstance = event.target.result;
        // إذا فُتح إصدار أحدث من قاعدة البيانات في تبويب آخر، نغلق هذا الاتصال القديم
        // فورًا حتى لا تُقرأ بيانات من نسخة قديمة أو تُحجب الترقية بصمت
        dbInstance.onversionchange = () => {
          dbInstance.close();
          dbInstance = null;
        };
        resolve(dbInstance);
      };

      request.onerror = (event) => {
        reject(event.target.error);
      };

      request.onblocked = () => {
        Utils.toast && Utils.toast('يوجد إصدار قديم من التطبيق مفتوح في تبويب آخر، يرجى إغلاقه ثم إعادة تحميل الصفحة', 'error');
      };
    });
  }

  function tx(storeName, mode = 'readonly') {
    return dbInstance.transaction(storeName, mode).objectStore(storeName);
  }

  // يضيف أعمدة المبالغ بالعملة المحلية (المبلغ × سعر صرف العملة) تلقائيًا للحركات المحاسبية
  async function enrichLocalAmounts(storeName, value) {
    const targets = [STORES.OPENING_BALANCES, STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES];
    if (!value || typeof value !== 'object' || !targets.includes(storeName)) return value;
    const currencies = await getAll(STORES.CURRENCIES);
    const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
    const rateOf = (currencyId, own) => {
      const cur = currencies.find(c => c.id === currencyId);
      if (!cur || cur.type === 'محلي') return 1;
      const r = Number(own) || Number(cur.rate) || 1;
      return r;
    };
    const conv = (amount, currencyId, own) => r2((Number(amount) || 0) * rateOf(currencyId, own));
    if (storeName === STORES.OPENING_BALANCES) {
      value.localDebit = conv(value.debit, value.currencyId);
      value.localCredit = conv(value.credit, value.currencyId);
    } else if (storeName === STORES.JOURNAL) {
      (value.lines || []).forEach(l => {
        const own = l.exchangeRate || l.rate;
        l.localDebit = conv(l.debit, l.currencyId, own);
        l.localCredit = conv(l.credit, l.currencyId, own);
      });
    } else if (storeName === STORES.VOUCHERS) {
      if (value.debitSide) { value.debitSide.localDebit = conv(value.debitSide.amount, value.debitSide.currencyId); value.debitSide.localCredit = 0; }
      if (value.creditSide) { value.creditSide.localCredit = conv(value.creditSide.amount, value.creditSide.currencyId); value.creditSide.localDebit = 0; }
      value.localDebit = value.debitSide ? value.debitSide.localDebit : 0;
      value.localCredit = value.creditSide ? value.creditSide.localCredit : 0;
    } else if (storeName === STORES.CURRENCY_EXCHANGES) {
      value.localCredit = conv(value.fromAmount, value.fromCurrencyId);
      value.localDebit = conv(value.toAmount, value.toCurrencyId);
    }
    return value;
  }

  async function add(storeName, value) {
    await open();
    try { await enrichLocalAmounts(storeName, value); } catch (e) { /* تجاهل */ }
    return new Promise((resolve, reject) => {
      const req = tx(storeName, 'readwrite').add(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function put(storeName, value) {
    await open();
    try { await enrichLocalAmounts(storeName, value); } catch (e) { /* تجاهل */ }
    return new Promise((resolve, reject) => {
      const req = tx(storeName, 'readwrite').put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function get(storeName, key) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAll(storeName) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAllByIndex(storeName, indexName, value) {
    await open();
    return new Promise((resolve, reject) => {
      const idx = tx(storeName).index(indexName);
      const req = idx.getAll(value);
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function remove(storeName, key) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName, 'readwrite').delete(key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  async function clearStore(storeName) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName, 'readwrite').clear();
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  /* -------- Seed data: الجذور الأربعة الثابتة للدليل المحاسبي -------- */
  async function seedIfNeeded() {
    const existing = await getAll(STORES.ACCOUNTS);
    if (existing.length > 0) return;

    const roots = [
      { code: '1', name: 'الأصول', rank: 1, type: 'رئيسي', nature: 'مدين', parentCode: null, fixed: true, currencies: [] },
      { code: '2', name: 'الخصوم', rank: 1, type: 'رئيسي', nature: 'دائن', parentCode: null, fixed: true, currencies: [] },
      { code: '3', name: 'المصروفات', rank: 1, type: 'رئيسي', nature: 'مدين', parentCode: null, fixed: true, currencies: [] },
      { code: '4', name: 'الإيرادات', rank: 1, type: 'رئيسي', nature: 'دائن', parentCode: null, fixed: true, currencies: [] }
    ];
    for (const r of roots) {
      await put(STORES.ACCOUNTS, r);
    }
  }

  /* -------- استيراد / تصدير النسخة الاحتياطية الكاملة -------- */
  async function exportAll() {
    await open();
    const dump = {};
    for (const key of Object.keys(STORES)) {
      dump[STORES[key]] = await getAll(STORES[key]);
    }
    dump._meta = { app: 'faris-accounting', version: DB_VERSION, date: new Date().toISOString() };
    return dump;
  }

  async function importAll(dump) {
    await open();
    for (const key of Object.keys(STORES)) {
      const storeName = STORES[key];
      if (!dump[storeName]) continue;
      await clearStore(storeName);
      for (const item of dump[storeName]) {
        await put(storeName, item);
      }
    }
  }

  return { open, add, put, get, getAll, getAllByIndex, remove, clearStore, seedIfNeeded, exportAll, importAll };
})();
