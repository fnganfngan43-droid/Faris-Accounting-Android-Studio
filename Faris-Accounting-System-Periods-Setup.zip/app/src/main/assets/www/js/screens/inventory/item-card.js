/* =========================================================
   بطاقة حركة الصنف
   المرجع الموحّد لحركة أي صنف: يجمع كل الحركات الفعلية
   (رصيد افتتاحي + فواتير مبيعات + مرتجع مبيعات) عبر
   ItemMovementEngine، بثلاثة أوضاع عرض: تفصيلية/إجمالية/تحليلية.
   ========================================================= */

const InvItemCard = (function () {
  let itemsCache = [];
  let mainGroupsCache = [];
  let subGroupsCache = [];
  let detailGroupsCache = [];
  let warehousesCache = [];
  let unitsFlat = [];
  let lastResult = null;
  let selectedItem = null;

  async function render(container, params) {
    params = params || {};
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    subGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_SUB);
    detailGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_DETAIL);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    lastResult = null;
    selectedItem = null;

    container.innerHTML = `
      <div class="form-grid">
        <label class="optional">من تاريخ<input type="date" id="ic-from"></label>
        <label class="optional">إلى تاريخ<input type="date" id="ic-to"></label>

        <label class="required">من رقم الصنف
          <div class="combo-wrap">
            <input type="text" id="ic-item-from-input" autocomplete="off" placeholder="ابحث برقم أو اسم الصنف">
            <div class="autocomplete-list" id="ic-item-from-list"></div>
          </div>
        </label>
        <input type="hidden" id="ic-item-from-code">

        <label class="optional">إلى رقم الصنف
          <div class="combo-wrap">
            <input type="text" id="ic-item-to-input" autocomplete="off" placeholder="ابحث برقم أو اسم الصنف">
            <div class="autocomplete-list" id="ic-item-to-list"></div>
          </div>
        </label>
        <input type="hidden" id="ic-item-to-code">

        <label class="optional">من مجموعة فرعية
          <select id="ic-sub-from"><option value="">الكل</option></select>
        </label>
        <label class="optional">إلى مجموعة فرعية
          <select id="ic-sub-to"><option value="">الكل</option></select>
        </label>

        <label class="optional">المخزن<select id="ic-warehouse"><option value="">كل المخازن</option></select></label>
        <label class="optional">الوحدة<select id="ic-unit"><option value="">كل الوحدات</option></select></label>

        <label class="required">نوع العرض
          <select id="ic-view-type">
            <option value="تفصيلية">بطاقة صنف تفصيلية</option>
            <option value="إجمالية">حركة إجمالية</option>
            <option value="تحليلية">حركة تحليلية</option>
          </select>
        </label>
      </div>

      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="ic-view" title="عرض">👁️</button>
        ${ReportPrint.toolbarHtml('ic')}
        <button class="btn btn-icon" id="ic-back" title="رجوع">↩️</button>
      </div>

      <div id="ic-gl-info" class="hint"></div>
      <div id="ic-result"></div>
    `;

    document.getElementById('ic-warehouse').innerHTML += warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');

    const sortedItems = [...itemsCache].sort((a, b) => String(a.code).localeCompare(String(b.code), undefined, { numeric: true }));
    const makeItemPicker = (inputId, listId, hiddenId, displayMode) => {
      const input = document.getElementById(inputId);
      const list = document.getElementById(listId);
      Utils.attachAutocomplete(input, list, (query) => {
        const q = String(query || '').trim().toLowerCase();
        return sortedItems
          .filter(it => !q || String(it.code).toLowerCase().includes(q) || String(it.name || '').toLowerCase().includes(q))
          .map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: displayMode === 'code' ? String(it.code) : String(it.name || '') }));
      }, (choice) => {
        input.value = choice.displayValue;
        document.getElementById(hiddenId).value = choice.value;
        if (displayMode === 'code') onItemChosen(choice.value);
      });
    };
    makeItemPicker('ic-item-from-input', 'ic-item-from-list', 'ic-item-from-code', 'code');
    makeItemPicker('ic-item-to-input', 'ic-item-to-list', 'ic-item-to-code', 'name');

    const subOptions = '<option value="">الكل</option>' + subGroupsCache
      .slice().sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'ar'))
      .map(g => `<option value="${g.id}">${Utils.escapeHtml(g.name || '')}</option>`).join('');
    document.getElementById('ic-sub-from').innerHTML = subOptions;
    document.getElementById('ic-sub-to').innerHTML = subOptions;

    document.getElementById('ic-view').addEventListener('click', onView);
    document.getElementById('ic-back').addEventListener('click', () => ScreenInventory.backFromItemCard());
    ReportPrint.bindToolbar('ic', async () => lastResult);

    if (params.itemCode) {
      const item = itemsCache.find(i => i.code === params.itemCode);
      if (item) {
        document.getElementById('ic-item-from-input').value = String(item.code);
        document.getElementById('ic-item-from-code').value = item.code;
        onItemChosen(item.code);
        if (params.warehouseId) document.getElementById('ic-warehouse').value = params.warehouseId;
        await onView();
      }
    }
  }

  function onItemChosen(code) {
    const item = itemsCache.find(i => i.code === code);
    selectedItem = item || null;
    document.getElementById('ic-item-code').value = code;

    const unitSelect = document.getElementById('ic-unit');
    unitSelect.innerHTML = '<option value="">كل الوحدات</option>' + (item ? item.units : []).map(u => {
      const unit = unitsFlat.find(x => x.id === u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
  }

  function unitName(id) { const u = unitsFlat.find(x => x.id === id); return u ? u.name : ''; }
  function warehouseName(id) { const w = warehousesCache.find(x => x.id === id); return w ? w.name : ''; }

  async function showGlInfo(warehouseId) {
    const box = document.getElementById('ic-gl-info');
    if (!warehouseId) { box.innerHTML = ''; return; }
    const mapping = await ItemMovementEngine.getGlLinks(Number(warehouseId));
    if (!mapping) { box.innerHTML = 'لا توجد حسابات مربوطة لمجموعة مخازن هذا المخزن في "ربط المخزون بالأستاذ العام".'; return; }
    const fields = [
      ['حساب المخزون', mapping.inventoryAccount], ['حساب الرصيد الافتتاحي', mapping.openingStockAccount],
      ['حساب المبيعات', mapping.salesAccount], ['حساب تكلفة المبيعات', mapping.costOfSalesAccount],
      ['حساب مردود المبيعات', mapping.salesReturnAccount], ['حساب تكلفة مردود المبيعات', mapping.costOfSalesReturnAccount]
    ];
    box.innerHTML = `<b>الأثر المحاسبي (للعرض فقط):</b> ` + fields.map(([label, acc]) => `${label}: ${acc ? Utils.escapeHtml(acc.code + ' - ' + acc.name) : '—'}`).join(' | ');
  }

  async function onView() {
    const fromCode = document.getElementById('ic-item-from-code').value;
    const toCode = document.getElementById('ic-item-to-code').value;
    if (!fromCode) { Utils.toast('اختر رقم الصنف من الحقل الأول', 'error'); return; }

    const fromDate = document.getElementById('ic-from').value || null;
    const toDate = document.getElementById('ic-to').value || null;
    const warehouseId = document.getElementById('ic-warehouse').value ? Number(document.getElementById('ic-warehouse').value) : null;
    const unitId = document.getElementById('ic-unit').value ? Number(document.getElementById('ic-unit').value) : null;
    const viewType = document.getElementById('ic-view-type').value;
    const subFrom = document.getElementById('ic-sub-from').value;
    const subTo = document.getElementById('ic-sub-to').value;

    const sortedItems = [...itemsCache].sort((a, b) => String(a.code).localeCompare(String(b.code), undefined, { numeric: true }));
    let startIndex = sortedItems.findIndex(i => String(i.code) === String(fromCode));
    let endIndex = toCode ? sortedItems.findIndex(i => String(i.code) === String(toCode)) : startIndex;
    if (startIndex < 0) { Utils.toast('رقم الصنف المحدد غير موجود', 'error'); return; }
    if (endIndex < 0) { Utils.toast('رقم الصنف إلى غير موجود', 'error'); return; }
    if (endIndex < startIndex) { Utils.toast('يجب أن يكون الصنف إلى بعد الصنف من أو مساويًا له', 'error'); return; }

    let selectedItems = sortedItems.slice(startIndex, endIndex + 1);
    const subgroupOrder = subGroupsCache.slice().sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'ar'));
    if (subFrom) {
      const ix = subgroupOrder.findIndex(g => String(g.id) === String(subFrom));
      if (ix >= 0) selectedItems = selectedItems.filter(it => subgroupOrder.findIndex(g => String(g.id) === String(it.subGroupId)) >= ix);
    }
    if (subTo) {
      const ix = subgroupOrder.findIndex(g => String(g.id) === String(subTo));
      if (ix >= 0) selectedItems = selectedItems.filter(it => {
        const gi = subgroupOrder.findIndex(g => String(g.id) === String(it.subGroupId));
        return gi >= 0 && gi <= ix;
      });
    }
    if (!selectedItems.length) { Utils.toast('لا توجد أصناف ضمن نطاق الفلترة المحدد', 'info'); return; }

    await showGlInfo(warehouseId);
    const movementSets = [];
    for (const item of selectedItems) {
      const result = await ItemMovementEngine.getItemCard({ itemCode: item.code, warehouseId, unitId, fromDate, toDate });
      movementSets.push({ item, rows: result.rows || [], carriedForward: result.carriedForward || 0 });
    }
    const allRows = movementSets.flatMap(set => set.rows.map(r => ({ ...r, itemCode: r.itemCode || set.item.code, itemName: r.itemName || set.item.name })));
    const subtitle = `الأصناف: ${selectedItems[0].code} - ${selectedItems[0].name}${selectedItems.length > 1 ? ` إلى ${selectedItems[selectedItems.length - 1].code} - ${selectedItems[selectedItems.length - 1].name}` : ''}${warehouseId ? ' — المخزن: ' + warehouseName(warehouseId) : ''}`;
    const resultEl = document.getElementById('ic-result');

    if (viewType === 'تفصيلية') {
      const headers = ['التاريخ', 'نوع الحركة', 'رقم المستند', 'رقم الصنف', 'اسم الصنف', 'المخزن', 'الوحدة', 'الكمية الواردة', 'الكمية المنصرفة', 'الرصيد', 'تكلفة الوحدة', 'إجمالي التكلفة', 'سعر البيع', 'إجمالي البيع', 'رقم المرجع', 'البيان'];
      const dataRows = [];
      movementSets.forEach(set => {
        if (fromDate && set.carriedForward) dataRows.push(['—', 'رصيد مرحّل', '—', set.item.code, set.item.name, warehouseId ? warehouseName(warehouseId) : '', '', '', '', set.carriedForward, '', '', '', '', '', 'رصيد ما قبل الفترة']);
        set.rows.forEach(r => dataRows.push([
          r.date || '—', r.type, r.docNo, r.itemCode || set.item.code, r.itemName || set.item.name, warehouseName(r.warehouseId), unitName(r.unitId),
          r.incomingQty || '', r.outgoingQty || '', r.balance,
          r.unitCost ? r.unitCost.toFixed(2) : '', r.unitCost ? ((r.incomingQty || r.outgoingQty) * r.unitCost).toFixed(2) : '',
          r.salePrice ? r.salePrice.toFixed(2) : '', r.salePrice ? (r.outgoingQty * r.salePrice).toFixed(2) : '', r.reference || '', r.statement || ''
        ]));
      });
      const totals = ItemMovementEngine.aggregateTotal(allRows);
      const footerRow = ['', '', '', '', '', '', 'الإجماليات', totals.incomingQty, totals.outgoingQty, totals.balance, totals.avgCost.toFixed(2), totals.totalValue.toFixed(2), '', totals.totalSale.toFixed(2), '', ''];
      lastResult = { title: 'بطاقة حركة الصنف', fromDate, toDate, subtitle, headers, rows: dataRows, footerRow };
      resultEl.innerHTML = renderTable(headers, dataRows, footerRow);
    } else if (viewType === 'إجمالية') {
      const headers = ['رقم الصنف', 'اسم الصنف', 'إجمالي الوارد', 'إجمالي المنصرف', 'الرصيد', 'متوسط التكلفة', 'إجمالي القيمة', 'إجمالي المبيعات'];
      const dataRows = movementSets.map(set => {
        const totals = ItemMovementEngine.aggregateTotal(set.rows);
        return [set.item.code, set.item.name, totals.incomingQty, totals.outgoingQty, totals.balance, totals.avgCost.toFixed(2), totals.totalValue.toFixed(2), totals.totalSale.toFixed(2)];
      });
      lastResult = { title: 'حركة إجمالية للأصناف', fromDate, toDate, subtitle, headers, rows: dataRows };
      resultEl.innerHTML = renderTable(headers, dataRows, null);
    } else {
      const groups = ItemMovementEngine.aggregateByAnalytic(allRows);
      const headers = ['الجهة التحليلية', 'إجمالي الوارد', 'إجمالي المنصرف', 'الرصيد', 'متوسط التكلفة', 'إجمالي القيمة'];
      const dataRows = groups.map(g => [g.label, g.totals.incomingQty, g.totals.outgoingQty, g.totals.balance, g.totals.avgCost.toFixed(2), g.totals.totalValue.toFixed(2)]);
      lastResult = { title: 'حركة تحليلية للأصناف', fromDate, toDate, subtitle, headers, rows: dataRows };
      resultEl.innerHTML = renderTable(headers, dataRows, null);
    }
  }

  function renderTable(headers, rows, footerRow) {
    const head = `<tr>${headers.map(h => `<th>${Utils.escapeHtml(h)}</th>`).join('')}</tr>`;
    const body = rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${headers.length}" class="empty-row">لا توجد حركة ضمن هذه الفلاتر</td></tr>`;
    const foot = footerRow ? `<tfoot><tr>${footerRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>` : '';
    return `<div class="table-scroll" style="overflow-x:auto;"><table class="data-table" style="table-layout:auto; width:auto; min-width:100%;"><thead>${head}</thead><tbody>${body}</tbody>${foot}</table></div>`;
  }

  return { render };
})();
