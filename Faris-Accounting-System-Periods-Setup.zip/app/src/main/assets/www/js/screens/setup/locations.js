/* =========================================================
   شاشة المحافظة (الدول / المحافظات / المدن) - فرعية من التهيئة
   ========================================================= */

const SetupLocations = (function () {
  let selectedId = null;

  function init() {}

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="loc-add">➕ إضافة</button>
        <button class="btn btn-icon" id="loc-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="loc-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>الدولة</th><th>المحافظة</th><th>المدينة</th></tr></thead>
          <tbody id="loc-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="loc-sheet">
        <div class="sheet-handle"></div>
        <h3>إضافة موقع</h3>
        <form id="loc-form">
          <div class="form-grid">
            <label class="required with-add-btn">
              اسم الدولة
              <span class="row-inline">
                <select id="loc-country" required></select>
                <button type="button" class="btn-plus" id="loc-open-country">➕</button>
              </span>
            </label>
            <label class="required with-add-btn">
              اسم المحافظة
              <span class="row-inline">
                <select id="loc-gov" required></select>
                <button type="button" class="btn-plus" id="loc-open-gov">➕</button>
              </span>
            </label>
            <label class="required field-wide">اسم المدينة<input type="text" id="loc-city" required></label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="loc-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      <div class="popup-sheet" id="country-popup">
        <div class="popup-header">
          <span>إضافة دولة</span>
          <button class="btn-close" id="country-popup-close">✖️</button>
        </div>
        <form id="country-form">
          <label class="required">اسم الدولة<input type="text" id="country-name" required></label>
          <button type="submit" class="btn btn-primary full">حفظ</button>
        </form>
      </div>

      <div class="popup-sheet" id="gov-popup">
        <div class="popup-header">
          <span>إضافة محافظة</span>
          <button class="btn-close" id="gov-popup-close">✖️</button>
        </div>
        <form id="gov-form">
          <label class="required">الدولة<select id="gov-country-select" required></select></label>
          <label class="required">اسم المحافظة<input type="text" id="gov-name" required></label>
          <button type="submit" class="btn btn-primary full">حفظ</button>
        </form>
      </div>
    `;

    container.querySelector('#loc-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#loc-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#loc-del').addEventListener('click', onDelete);
    container.querySelector('#loc-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('loc-sheet')));
    container.querySelector('#loc-form').addEventListener('submit', onSave);

    container.querySelector('#loc-open-country').addEventListener('click', () => {
      document.getElementById('country-form').reset();
      Utils.openSheet(document.getElementById('country-popup'));
    });
    container.querySelector('#country-popup-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('country-popup')));
    container.querySelector('#country-form').addEventListener('submit', onSaveCountry);

    container.querySelector('#loc-open-gov').addEventListener('click', async () => {
      document.getElementById('gov-form').reset();
      await fillCountrySelect(document.getElementById('gov-country-select'));
      Utils.openSheet(document.getElementById('gov-popup'));
    });
    container.querySelector('#gov-popup-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('gov-popup')));
    container.querySelector('#gov-form').addEventListener('submit', onSaveGov);

    container.querySelector('#loc-country').addEventListener('change', onCountryChangeInForm);

    await loadRows();
  }

  async function fillCountrySelect(select, selectedValue) {
    const countries = await FarisDB.getAll(STORES.COUNTRIES);
    select.innerHTML = countries.map(c => `<option value="${c.id}">${Utils.escapeHtml(c.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }

  async function fillGovSelect(select, countryId, selectedValue) {
    const govs = countryId ? await FarisDB.getAllByIndex(STORES.GOVERNORATES, 'countryId', Number(countryId)) : [];
    select.innerHTML = govs.map(g => `<option value="${g.id}">${Utils.escapeHtml(g.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }

  async function onCountryChangeInForm(e) {
    await fillGovSelect(document.getElementById('loc-gov'), e.target.value);
  }

  async function onSaveCountry(e) {
    e.preventDefault();
    const name = document.getElementById('country-name').value.trim();
    if (!name) return;
    const existing = await FarisDB.getAll(STORES.COUNTRIES);
    if (existing.some(c => c.name === name)) {
      Utils.toast('اسم الدولة موجود مسبقًا', 'error');
      return;
    }
    const id = await FarisDB.add(STORES.COUNTRIES, { name });
    Utils.closeSheet(document.getElementById('country-popup'));
    await fillCountrySelect(document.getElementById('loc-country'), id);
    await fillGovSelect(document.getElementById('loc-gov'), id);
    Utils.toast('تمت إضافة الدولة', 'success');
  }

  async function onSaveGov(e) {
    e.preventDefault();
    const countryId = Number(document.getElementById('gov-country-select').value);
    const name = document.getElementById('gov-name').value.trim();
    if (!name || !countryId) return;
    const existingGovs = await FarisDB.getAllByIndex(STORES.GOVERNORATES, 'countryId', countryId);
    if (existingGovs.some(g => g.name === name)) {
      Utils.toast('اسم المحافظة موجود مسبقًا لهذه الدولة', 'error');
      return;
    }
    const id = await FarisDB.add(STORES.GOVERNORATES, { name, countryId });
    Utils.closeSheet(document.getElementById('gov-popup'));
    if (Number(document.getElementById('loc-country').value) === countryId) {
      await fillGovSelect(document.getElementById('loc-gov'), countryId, id);
    }
    Utils.toast('تمت إضافة المحافظة', 'success');
  }

  async function loadRows() {
    const locations = await FarisDB.getAll(STORES.LOCATIONS);
    const countries = await FarisDB.getAll(STORES.COUNTRIES);
    const govs = await FarisDB.getAll(STORES.GOVERNORATES);
    const cMap = Object.fromEntries(countries.map(c => [c.id, c.name]));
    const gMap = Object.fromEntries(govs.map(g => [g.id, g.name]));

    const rows = document.getElementById('loc-rows');
    rows.innerHTML = locations.map(l => `
      <tr data-id="${l.id}">
        <td>${Utils.escapeHtml(cMap[l.countryId] || '')}</td>
        <td>${Utils.escapeHtml(gMap[l.governorateId] || '')}</td>
        <td>${Utils.escapeHtml(l.city)}</td>
      </tr>`).join('') || '<tr><td colspan="3" class="empty-row">لا توجد مواقع بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#loc-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('loc-edit').disabled = false;
    document.getElementById('loc-del').disabled = false;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('loc-sheet');
    document.getElementById('loc-form').reset();
    await fillCountrySelect(document.getElementById('loc-country'));

    if (id) {
      const loc = await FarisDB.get(STORES.LOCATIONS, id);
      await fillCountrySelect(document.getElementById('loc-country'), loc.countryId);
      await fillGovSelect(document.getElementById('loc-gov'), loc.countryId, loc.governorateId);
      document.getElementById('loc-city').value = loc.city;
      sheet.dataset.editId = id;
    } else {
      const firstCountry = document.getElementById('loc-country').value;
      await fillGovSelect(document.getElementById('loc-gov'), firstCountry);
      sheet.dataset.editId = '';
    }
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('loc-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    const value = {
      countryId: Number(document.getElementById('loc-country').value),
      governorateId: Number(document.getElementById('loc-gov').value),
      city: document.getElementById('loc-city').value.trim()
    };
    if (editId) value.id = editId;

    const existing = await FarisDB.getAll(STORES.LOCATIONS);
    const dup = existing.some(l => l.countryId === value.countryId && l.governorateId === value.governorateId
      && l.city === value.city && l.id !== editId);
    if (dup) {
      Utils.toast('هذه المدينة مضافة مسبقًا لنفس الدولة والمحافظة', 'error');
      document.getElementById('loc-city').classList.add('field-invalid');
      return;
    }
    document.getElementById('loc-city').classList.remove('field-invalid');

    await FarisDB.put(STORES.LOCATIONS, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function isLocationInUse(loc) {
    const stores = [STORES.CUSTOMERS, STORES.CASHBOXES, STORES.BANKS, STORES.SUPPLIERS];
    for (const s of stores) {
      const all = await FarisDB.getAll(s);
      if (all.some(x => x.city === loc.city && x.governorateId === loc.governorateId && x.countryId === loc.countryId)) {
        return true;
      }
    }
    return false;
  }

  async function onDelete() {
    if (!selectedId) return;
    const loc = await FarisDB.get(STORES.LOCATIONS, selectedId);
    if (await isLocationInUse(loc)) {
      Utils.toast('لا يمكنك الحذف، هذا الموقع مرتبط بسجلات موجودة', 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذا الموقع؟');
    if (!ok) return;
    await FarisDB.remove(STORES.LOCATIONS, selectedId);
    selectedId = null;
    document.getElementById('loc-edit').disabled = true;
    document.getElementById('loc-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { init, render };
})();
