/* =========================================================
   مرجوع المشتريات / خصم مكتسب
   (الهيكل والشريط فقط، حسب المواصفات الحالية؛ الحقول التفصيلية ستُضاف لاحقًا
   على نفس نمط مرتجع المبيعات فور تأكيد التفاصيل)
   ========================================================= */

const PurchaseStub = (function () {
  const TITLES = { purchaseReturn: 'مرجوع المشتريات', earnedDiscount: 'خصم مكتسب' };

  function render(container, key) {
    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" title="إضافة">➕</button>
        <button class="btn btn-icon" title="بحث">🔍</button>
        <button class="btn btn-icon" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" disabled title="حذف">🗑️</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>لا توجد بيانات بعد</th></tr></thead>
          <tbody><tr><td class="empty-row">شاشة "${TITLES[key]}" جاهزة هيكليًا ضمن قائمة المشتريات، وستُستكمل حقولها في مرحلة قادمة.</td></tr></tbody>
        </table>
      </div>
    `;
  }

  return { render };
})();
