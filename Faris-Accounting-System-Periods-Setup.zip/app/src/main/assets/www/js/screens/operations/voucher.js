/* =========================================================
   سند قبض / سند الصرف (منطق مشترك، يتغير حسب النوع)
   ========================================================= */

const OpVoucher = (function () {
  const CONFIG = {
    receipt: { title: 'سند قبض', firstSide: 'debit', firstLabel: 'الطرف المدين', secondLabel: 'الطرف الدائن' },
    payment: { title: 'سند الصرف', firstSide: 'credit', firstLabel: 'الطرف الدائن', secondLabel: 'الطرف المدين' }
  };
  const KIND_TYPE_MAP = { 'نقدي': 'صناديق', 'بنكي': 'بنوك' };

  let selectedId = null;
  let currenciesCache = [];
  let currentType = null;
  let firstPrefix = null;

  async function render(container, type) {
    currentType = type;
    selectedId = null;
    const cfg = CONFIG[type];

    firstPrefix = cfg.firstSide === 'debit' ? 'vd' : 'vc';

    const debitBlock = (withKind) => `
      <div class="voucher-block voucher-debit">
        <div class="block-header-row">
          <h4>الطرف المدين</h4>
          ${withKind ? `<label class="required kind-inline">نوع السند
            <select id="${firstPrefix}-kind"><option value="نقدي">نقدي</option><option value="بنكي">بنكي</option></select>
          </label>` : ''}
        </div>
        <div class="form-grid">
          ${AccountAnalyticPicker.markup('vd', 'اسم الحساب', 'اسم الحساب التحليلي', true)}
          <label class="required">مبلغ مدين<input type="number" step="0.01" id="vd-amount" required></label>
          <div class="two-col-uneven">
            <label class="optional">البيان<input type="text" id="vd-statement"></label>
            <label class="optional">رقم المرجع<input type="text" id="vd-ref"></label>
          </div>
        </div>
      </div>
    `;
    const creditBlock = (withKind) => `
      <div class="voucher-block voucher-credit">
        <div class="block-header-row">
          <h4>الطرف الدائن</h4>
          ${withKind ? `<label class="required kind-inline">نوع السند
            <select id="${firstPrefix}-kind"><option value="نقدي">نقدي</option><option value="بنكي">بنكي</option></select>
          </label>` : ''}
        </div>
        <div class="form-grid">
          ${AccountAnalyticPicker.markup('vc', 'اسم الحساب', 'اسم الحساب التحليلي', true)}
          <label class="required">مبلغ دائن<input type="number" step="0.01" id="vc-amount" required></label>
          <div class="two-col-uneven">
            <label class="optional">البيان<input type="text" id="vc-statement"></label>
            <label class="optional">رقم المرجع<input type="text" id="vc-ref"></label>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="v-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="v-dup" title="إضافة من المحدد">📑</button>
        <button class="btn btn-icon" id="v-import" title="استيراد إكسل">📥</button>
        <button class="btn btn-icon" id="v-print" title="طباعة">🖨️</button>
        <button class="btn btn-icon" id="v-edit" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" id="v-del" disabled title="حذف">🗑️</button>
      </div>
      <div class="toolbar search-row">
        <input type="text" id="v-search" placeholder="🔍 بحث...">
        <select id="v-search-col"><option value="">كل الأعمدة</option></select>
      </div>

      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>
            <th>رقم السند</th><th>التاريخ</th>
            <th>رقم حساب مدين</th><th>اسم حساب مدين</th><th>رقم تحليلي مدين</th><th>اسم تحليلي مدين</th><th>عملة مدين</th><th>مبلغ مدين</th><th>بيان مدين</th><th>مرجع مدين</th>
            <th>رقم حساب دائن</th><th>اسم حساب دائن</th><th>رقم تحليلي دائن</th><th>اسم تحليلي دائن</th><th>عملة دائن</th><th>مبلغ دائن</th><th>بيان دائن</th><th>مرجع دائن</th>
          </tr></thead>
          <tbody id="v-rows"></tbody>
        </table>
      </div>
      <p class="hint">مرّر الجدول أفقيًا لرؤية كل الأعمدة ⇠</p>

      <div class="bottom-sheet sheet-tall" id="v-sheet">
        <div class="sheet-handle"></div>
        <h3 id="v-title">${cfg.title} - إضافة</h3>
        <form id="v-form">
          <div class="form-grid">
            <label class="optional">رقم السند<input type="text" id="v-no"></label>
            <label class="required">التاريخ<input type="date" id="v-date" required></label>
            <label class="optional">العملة المحلية<input type="text" id="v-local-currency" readonly></label>
          </div>
          <div id="v-side-1">${cfg.firstSide === 'debit' ? debitBlock(true) : creditBlock(true)}</div>
          <hr>
          <div id="v-side-2">${cfg.firstSide === 'debit' ? creditBlock(false) : debitBlock(false)}</div>

          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="v-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      <div class="popup-sheet" id="v-import-popup">
        <div class="popup-header"><span>استيراد ${cfg.title} من إكسل</span><button class="btn-close" id="v-import-close">✖️</button></div>
        <div id="v-import-instructions">
          <p class="hint">يبدأ الاستيراد من الصف الثاني. ترتيب الأعمدة:<br>
            <b>${importColumnsHint(type)}</b></p>
          <p class="hint">رقم الحساب الفرعي واسم الحساب يُستنتجان تلقائيًا ويُصحَّحان من قاعدة البيانات حسب رقم التحليلي.</p>
          <input type="file" id="v-import-file" accept=".xlsx,.xls,.csv">
        </div>
        <div id="v-import-result" class="hidden">
          <p class="hint" id="v-import-status"></p>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="v-import-cancel-save">إلغاء</button>
            <button type="button" class="btn btn-primary" id="v-import-confirm-save">موافق</button>
          </div>
        </div>
      </div>

      <div class="popup-sheet" id="v-import-error-popup">
        <div class="popup-header"><span>خطأ في سند مستورد</span></div>
        <p class="hint" id="v-import-error-text"></p>
        <div class="sheet-actions">
          <button type="button" class="btn btn-secondary" id="v-import-error-skip">تخطي</button>
          <button type="button" class="btn btn-primary" id="v-import-error-continue">استمرار</button>
        </div>
      </div>
    `;

    const firstOpts = { restrictAnalyticType: KIND_TYPE_MAP['نقدي'] };
    await AccountAnalyticPicker.init('vd', null, firstPrefix === 'vd' ? firstOpts : {});
    await AccountAnalyticPicker.init('vc', null, firstPrefix === 'vc' ? firstOpts : {});
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);

    const kindSelect = document.getElementById(`${firstPrefix}-kind`);
    if (kindSelect) {
      kindSelect.value = 'نقدي';
      kindSelect.addEventListener('change', () => {
        AccountAnalyticPicker.setAccountFilter(firstPrefix, KIND_TYPE_MAP[kindSelect.value]);
      });
    }

    document.getElementById('v-search-col').innerHTML += ['رقم السند', 'التاريخ', 'حساب مدين', 'حساب دائن', 'البيان']
      .map(c => `<option value="${c}">${c}</option>`).join('');

    container.querySelector('#v-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#v-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#v-del').addEventListener('click', onDelete);
    container.querySelector('#v-dup').addEventListener('click', () => duplicateSelected());
    container.querySelector('#v-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('v-sheet')));
    container.querySelector('#v-form').addEventListener('submit', onSave);
    container.querySelector('#v-search').addEventListener('input', () => loadRows());
    container.querySelector('#v-search-col').addEventListener('change', () => loadRows());

    container.querySelector('#v-import').addEventListener('click', () => {
      document.getElementById('v-import-instructions').classList.remove('hidden');
      document.getElementById('v-import-result').classList.add('hidden');
      document.getElementById('v-import-status').textContent = '';
      document.getElementById('v-import-file').value = '';
      Utils.openSheet(document.getElementById('v-import-popup'));
    });
    container.querySelector('#v-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('v-import-popup')));
    container.querySelector('#v-import-file').addEventListener('change', onImportExcel);
    container.querySelector('#vd-ref').addEventListener('blur', () => onRefBlurCheck('vd-ref'));
    container.querySelector('#vc-ref').addEventListener('blur', () => onRefBlurCheck('vc-ref'));
    container.querySelector('#v-print').addEventListener('click', onPrint);

    await loadRows();
  }

  function currencySymbol(id) {
    const c = currenciesCache.find(c => c.id === id);
    return c ? c.symbol : '';
  }

  async function nextVoucherNo() {
    const items = await FarisDB.getAllByIndex(STORES.VOUCHERS, 'type', currentType);
    const numeric = items.map(i => Number(i.voucherNo)).filter(n => !isNaN(n));
    return String(numeric.length ? Math.max(...numeric) + 1 : 1);
  }

  async function loadRows() {
    let items = await FarisDB.getAllByIndex(STORES.VOUCHERS, 'type', currentType);
    const search = document.getElementById('v-search').value.trim();
    const col = document.getElementById('v-search-col').value;

    if (search) {
      items = items.filter(it => {
        const map = { 'رقم السند': it.voucherNo, 'التاريخ': it.date, 'حساب مدين': it.debitSide.accountName, 'حساب دائن': it.creditSide.accountName, 'البيان': it.debitSide.statement + ' ' + it.creditSide.statement };
        const haystack = col ? map[col] : JSON.stringify(it);
        return String(haystack).includes(search);
      });
    }

    const rows = document.getElementById('v-rows');
    rows.innerHTML = items.map(it => `
      <tr data-id="${it.id}">
        <td>${Utils.escapeHtml(it.voucherNo)}</td><td>${Utils.escapeHtml(it.date)}</td>
        <td>${Utils.escapeHtml(it.debitSide.accountCode)}</td><td>${Utils.escapeHtml(it.debitSide.accountName)}</td>
        <td>${Utils.escapeHtml(AccountAnalyticPicker.formatAnalyticDisplay(it.debitSide.accountCode, it.debitSide.analyticCode))}</td><td>${Utils.escapeHtml(it.debitSide.analyticName)}</td>
        <td>${Utils.escapeHtml(currencySymbol(it.debitSide.currencyId))}</td><td>${Utils.escapeHtml(it.debitSide.amount)}</td>
        <td>${Utils.escapeHtml(it.debitSide.statement)}</td><td>${Utils.escapeHtml(it.debitSide.refNo)}</td>
        <td>${Utils.escapeHtml(it.creditSide.accountCode)}</td><td>${Utils.escapeHtml(it.creditSide.accountName)}</td>
        <td>${Utils.escapeHtml(AccountAnalyticPicker.formatAnalyticDisplay(it.creditSide.accountCode, it.creditSide.analyticCode))}</td><td>${Utils.escapeHtml(it.creditSide.analyticName)}</td>
        <td>${Utils.escapeHtml(currencySymbol(it.creditSide.currencyId))}</td><td>${Utils.escapeHtml(it.creditSide.amount)}</td>
        <td>${Utils.escapeHtml(it.creditSide.statement)}</td><td>${Utils.escapeHtml(it.creditSide.refNo)}</td>
      </tr>`).join('') || '<tr><td colspan="18" class="empty-row">لا توجد سندات محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#v-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('v-edit').disabled = false;
    document.getElementById('v-del').disabled = false;
  }

  function localCurrencyLabel() {
    const c = currenciesCache.find(c => c.type === 'محلي');
    return c ? (c.symbol || c.name) : '';
  }

  async function openSheet(id) {
    const cfg = CONFIG[currentType];
    const sheet = document.getElementById('v-sheet');
    document.getElementById('v-form').reset();
    document.getElementById('v-local-currency').value = localCurrencyLabel();
    document.getElementById('v-date').value = new Date().toISOString().slice(0, 10);

    const kindSelect = document.getElementById(`${firstPrefix}-kind`);
    if (kindSelect && !id) {
      kindSelect.value = 'نقدي';
      AccountAnalyticPicker.setAccountFilter(firstPrefix, KIND_TYPE_MAP['نقدي']);
    }

    if (id) {
      const item = await FarisDB.get(STORES.VOUCHERS, id);
      document.getElementById('v-title').textContent = `${cfg.title} - تعديل`;
      document.getElementById('v-no').value = item.voucherNo;
      document.getElementById('v-date').value = item.date;

      await AccountAnalyticPicker.setValue('vd', item.debitSide);
      document.getElementById('vd-amount').value = item.debitSide.amount;
      document.getElementById('vd-statement').value = item.debitSide.statement || '';
      document.getElementById('vd-ref').value = item.debitSide.refNo || '';

      await AccountAnalyticPicker.setValue('vc', item.creditSide);
      document.getElementById('vc-amount').value = item.creditSide.amount;
      document.getElementById('vc-statement').value = item.creditSide.statement || '';
      document.getElementById('vc-ref').value = item.creditSide.refNo || '';

      sheet.dataset.editId = id;
    } else {
      document.getElementById('v-title').textContent = `${cfg.title} - إضافة`;
      document.getElementById('v-no').value = await nextVoucherNo();
      sheet.dataset.editId = '';
    }

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function duplicateSelected() {
    if (!selectedId) return;
    await openSheet(selectedId);
    document.getElementById('v-sheet').dataset.editId = '';
    document.getElementById('v-title').textContent = `${CONFIG[currentType].title} - إضافة`;
    document.getElementById('v-no').value = await nextVoucherNo();
    document.getElementById('v-date').value = new Date().toISOString().slice(0, 10);
  }

  async function onRefBlurCheck(fieldId) {
    const field = document.getElementById(fieldId);
    const value = field.value.trim();
    if (!value) { field.classList.remove('field-invalid'); return; }

    const sheet = document.getElementById('v-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;
    const items = await FarisDB.getAllByIndex(STORES.VOUCHERS, 'type', currentType);
    const dup = items.some(it => it.id !== editId && (it.debitSide.refNo === value || it.creditSide.refNo === value));

    if (dup) {
      Utils.toast('رقم المرجع مكرر في هذه الشاشة، تأكد من الرقم', 'error');
      field.classList.add('field-invalid');
    } else {
      field.classList.remove('field-invalid');
    }
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('v-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    const debitPicked = await AccountAnalyticPicker.getValue('vd');
    const creditPicked = await AccountAnalyticPicker.getValue('vc');
    if (!debitPicked || !creditPicked) {
      Utils.toast('أكمل بيانات الطرف المدين والطرف الدائن (الحساب/التحليلي/العملة)', 'error');
      return;
    }

    const debitAmount = Number(document.getElementById('vd-amount').value) || 0;
    const creditAmount = Number(document.getElementById('vc-amount').value) || 0;

    if (debitAmount <= 0 || creditAmount <= 0) {
      Utils.toast('أدخل المبالغ لكلا الطرفين', 'error');
      return;
    }
    if (Math.abs(debitAmount - creditAmount) > 0.009) {
      Utils.toast('يجب أن يتساوى مبلغ الطرف المدين مع مبلغ الطرف الدائن', 'error');
      return;
    }

    const value = {
      type: currentType,
      voucherNo: document.getElementById('v-no').value.trim(),
      date: document.getElementById('v-date').value,
      debitSide: { ...debitPicked, amount: debitAmount, statement: document.getElementById('vd-statement').value.trim(), refNo: document.getElementById('vd-ref').value.trim() },
      creditSide: { ...creditPicked, amount: creditAmount, statement: document.getElementById('vc-statement').value.trim(), refNo: document.getElementById('vc-ref').value.trim() }
    };
    if (editId) value.id = editId;

    await FarisDB.put(STORES.VOUCHERS, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف هذا السند؟');
    if (!ok) return;
    await FarisDB.remove(STORES.VOUCHERS, selectedId);
    selectedId = null;
    document.getElementById('v-edit').disabled = true;
    document.getElementById('v-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  function importColumnsHint(type) {
    const firstLabel = type === 'receipt' ? 'مدين' : 'دائن';
    const secondLabel = type === 'receipt' ? 'دائن' : 'مدين';
    return `A) رقم &nbsp;B) التاريخ &nbsp;C) نوع السند (نقدي/بنكي) &nbsp;
      D) اسم الحساب ${firstLabel} &nbsp;E) رقم التحليلي ${firstLabel} &nbsp;F) اسم الحساب التحليلي ${firstLabel} &nbsp;G) رمز العملة ${firstLabel} &nbsp;H) المبلغ ${firstLabel} &nbsp;I) البيان ${firstLabel} &nbsp;J) رقم المرجع ${firstLabel} &nbsp;
      K) اسم الحساب ${secondLabel} &nbsp;L) رقم التحليلي ${secondLabel} &nbsp;M) اسم الحساب التحليلي ${secondLabel} &nbsp;N) رمز العملة ${secondLabel} &nbsp;O) المبلغ ${secondLabel} &nbsp;P) البيان ${secondLabel} &nbsp;Q) رقم المرجع ${secondLabel}`;
  }

  function waitForErrorChoice() {
    return new Promise((resolve) => {
      const popup = document.getElementById('v-import-error-popup');
      const continueBtn = document.getElementById('v-import-error-continue');
      const skipBtn = document.getElementById('v-import-error-skip');
      function cleanup(choice) {
        continueBtn.removeEventListener('click', onContinue);
        skipBtn.removeEventListener('click', onSkip);
        Utils.closeSheet(popup);
        resolve(choice);
      }
      function onContinue() { cleanup('continue'); }
      function onSkip() { cleanup('skip'); }
      continueBtn.addEventListener('click', onContinue);
      skipBtn.addEventListener('click', onSkip);
      Utils.openSheet(popup);
    });
  }

  async function resolveSide(analyticCode, currencySymbolVal, amountVal, statement, refNo, currencies) {
    const errors = [];
    const resolved = await AccountAnalyticPicker.resolveByAnalyticCode(analyticCode);
    if (!resolved) errors.push(`رقم الحساب التحليلي "${analyticCode}" غير موجود`);
    const currency = currencies.find(c => c.symbol === currencySymbolVal || c.name === currencySymbolVal);
    if (!currency) errors.push(`رمز العملة "${currencySymbolVal}" غير موجود`);
    const amount = Number(amountVal) || 0;
    if (amount <= 0) errors.push('المبلغ غير صالح');

    const side = {
      accountCode: resolved ? resolved.accountCode : '',
      accountName: resolved ? resolved.accountName : '',
      analyticCode: resolved ? resolved.analyticCode : analyticCode,
      analyticName: resolved ? resolved.analyticName : '',
      currencyId: currency ? currency.id : null,
      amount, statement: statement || '', refNo: refNo || ''
    };
    return { side, errors };
  }

  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('v-import-status');
    if (typeof XLSX === 'undefined') {
      Utils.toast('تعذّر تحميل مكتبة قراءة إكسل، تأكد من الاتصال بالإنترنت.', 'error');
      return;
    }

    let rows;
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }).slice(1);
    } catch (err) {
      Utils.toast('تعذّرت قراءة الملف، تأكد من صيغة الإكسل.', 'error');
      return;
    }

    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const staged = [];
    let imported = 0, skipped = 0;

    for (const row of rows) {
      const cells = row.map(v => String(v ?? '').trim());
      const [voucherNo, date, , d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14] = cells;
      // الأعمدة D..J تخص الطرف الأول (مدين لسند القبض / دائن لسند الصرف)، K..Q تخص الطرف الثاني
      const firstResult = await resolveSide(d2, d4, d5, d6, d7, currencies);
      const secondResult = await resolveSide(d9, d11, d12, d13, d14, currencies);

      const errors = [...firstResult.errors, ...secondResult.errors];
      if (firstResult.side.amount && secondResult.side.amount && Math.abs(firstResult.side.amount - secondResult.side.amount) > 0.009) {
        errors.push('المبلغان غير متوازنين (مدين ≠ دائن)');
      }

      let include = true;
      if (errors.length) {
        document.getElementById('v-import-error-text').innerHTML = `<b>السند رقم: ${Utils.escapeHtml(voucherNo || '—')}</b><br>${errors.map(er => `• ${Utils.escapeHtml(er)}`).join('<br>')}`;
        const choice = await waitForErrorChoice();
        if (choice === 'skip') include = false;
      }

      if (include) {
        const debitSide = currentType === 'receipt' ? firstResult.side : secondResult.side;
        const creditSide = currentType === 'receipt' ? secondResult.side : firstResult.side;
        staged.push({
          type: currentType,
          voucherNo: voucherNo || String(imported + 1),
          date: Utils.normalizeImportDate(date) || new Date().toISOString().slice(0, 10),
          debitSide, creditSide
        });
        imported++;
      } else {
        skipped++;
      }
    }

    document.getElementById('v-import-instructions').classList.add('hidden');
    document.getElementById('v-import-result').classList.remove('hidden');
    statusEl.textContent = `اكتمل فحص الملف: ${imported} سند جاهز للحفظ، ${skipped} سند تم تخطيه. اضغط "موافق" لحفظ السندات، أو "إلغاء" لتجاهل الاستيراد بالكامل.`;

    const confirmBtn = document.getElementById('v-import-confirm-save');
    const cancelBtn = document.getElementById('v-import-cancel-save');
    const onConfirm = async () => {
      for (const v of staged) await FarisDB.put(STORES.VOUCHERS, v);
      cleanup();
      Utils.closeSheet(document.getElementById('v-import-popup'));
      Utils.toast(`تم حفظ ${staged.length} سند بنجاح`, 'success');
      await loadRows();
    };
    const onCancel = () => {
      cleanup();
      Utils.closeSheet(document.getElementById('v-import-popup'));
      Utils.toast('تم إلغاء الاستيراد، لم تُحفظ أي بيانات', 'info');
    };
    function cleanup() {
      confirmBtn.removeEventListener('click', onConfirm);
      cancelBtn.removeEventListener('click', onCancel);
    }
    confirmBtn.addEventListener('click', onConfirm);
    cancelBtn.addEventListener('click', onCancel);

    e.target.value = '';
  }

  async function onPrint() {
    const cfg = CONFIG[currentType];
    if (selectedId) {
      const item = await FarisDB.get(STORES.VOUCHERS, selectedId);
      if (item) { await printVoucher(item); return; }
    }
    const items = await FarisDB.getAllByIndex(STORES.VOUCHERS, 'type', currentType);
    const headers = ['رقم السند', 'التاريخ', 'حساب مدين', 'حساب دائن', 'المبلغ', 'البيان'];
    const rows = items.map(it => [it.voucherNo, it.date, it.debitSide.accountName, it.creditSide.accountName, it.debitSide.amount, it.debitSide.statement || it.creditSide.statement || '']);
    Utils.printTable(cfg.title, headers, rows);
  }

  // ---- تفقيط المبلغ بالعربية ----
  function numberToArabicWords(num) {
    const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
    const tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
    function below1000(n) {
      const parts = [];
      const h = Math.floor(n / 100), r = n % 100;
      if (h) parts.push(hundreds[h]);
      if (r) {
        if (r < 20) parts.push(ones[r]);
        else { const o = r % 10, t = Math.floor(r / 10); parts.push(o ? `${ones[o]} و${tens[t]}` : tens[t]); }
      }
      return parts.join(' و');
    }
    const scales = [
      { v: 1e9, one: 'مليار', two: 'ملياران', few: 'مليارات' },
      { v: 1e6, one: 'مليون', two: 'مليونان', few: 'ملايين' },
      { v: 1e3, one: 'ألف', two: 'ألفان', few: 'آلاف' }
    ];
    let n = Math.floor(Math.abs(Number(num) || 0));
    if (n === 0) return 'صفر';
    const parts = [];
    for (const s of scales) {
      const q = Math.floor(n / s.v);
      if (q) {
        if (q === 1) parts.push(s.one);
        else if (q === 2) parts.push(s.two);
        else if (q <= 10) parts.push(`${below1000(q)} ${s.few}`);
        else parts.push(`${below1000(q)} ${s.one}`);
        n %= s.v;
      }
    }
    if (n) parts.push(below1000(n));
    return parts.join(' و');
  }

  function amountInWords(amount, currencyName) {
    const v = Math.abs(Number(amount) || 0);
    const whole = Math.floor(v);
    const frac = Math.round((v - whole) * 100);
    let s = `فقط ${numberToArabicWords(whole)} ${currencyName || ''}`.trim();
    if (frac) s += ` و${numberToArabicWords(frac)} من مائة`;
    return s + ' لا غير';
  }

  // طباعة السند المحدد بتنسيق سندات أونكس برو
  async function printVoucher(item) {
    const isReceipt = (item.type || currentType) === 'receipt';
    const title = isReceipt ? 'سند قبض' : 'سند صرف';
    const cashSide = isReceipt ? item.debitSide : item.creditSide;
    const partySide = isReceipt ? item.creditSide : item.debitSide;
    const cur = currenciesCache.find(c => c.id === (cashSide.currencyId ?? partySide.currencyId)) || {};
    const amount = Number(cashSide.amount || partySide.amount || 0);
    const settings = await FarisDB.get(STORES.SETTINGS, 'main').catch(() => null) || {};
    const e = Utils.escapeHtml;
    const arLines = [settings.arLine1, settings.arLine2, settings.arLine3].filter(Boolean);
    const enLines = [settings.enLine1, settings.enLine2, settings.enLine3].filter(Boolean);
    const logo = settings.logo ? `<img class="logo" src="${settings.logo}" alt="">` : '';
    const partyName = partySide.analyticName || partySide.accountName || '';
    const cashName = cashSide.analyticName || cashSide.accountName || '';
    const statement = partySide.statement || cashSide.statement || '';
    const ref = cashSide.refNo || partySide.refNo || '';
    const kind = item.kind || cashSide.kind || 'نقدي';
    const fmt = amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const style = `
      @page{size:A5 landscape;margin:8mm}
      *{box-sizing:border-box}
      body{font-family:Tajawal,Arial,sans-serif;direction:rtl;color:#111;margin:0}
      .vframe{border:2px solid #222;border-radius:6px;padding:10px 14px}
      .head{display:grid;grid-template-columns:1fr 70px 1fr;align-items:center;gap:8px;font-size:12px;font-weight:bold;border-bottom:2px solid #222;padding-bottom:6px}
      .head>div:last-child{text-align:left}
      .logo{width:64px;height:64px;border-radius:50%;object-fit:cover;display:block;margin:auto}
      .titlebar{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;margin:10px 0;gap:10px}
      .title{font-family:Cairo,Arial,sans-serif;font-size:22px;font-weight:800;border:2px solid #222;border-radius:20px;padding:2px 26px;background:#eee;text-align:center}
      .box{border:1.5px solid #222;border-radius:4px;padding:4px 8px;font-size:13px;display:inline-flex;gap:6px;align-items:center}
      .box b{white-space:nowrap}
      .left{text-align:left}
      .amt{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:10px}
      .amtbox{border:2px solid #222;font-size:16px;font-weight:800;padding:4px 14px;direction:ltr}
      .line{display:flex;gap:8px;align-items:baseline;margin:9px 0;font-size:14px}
      .line b{white-space:nowrap}
      .line span{flex:1;border-bottom:1px dotted #333;padding:0 6px 2px;min-height:20px}
      .sign{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:26px;text-align:center;font-size:13px;font-weight:bold}
      .sign div{border-top:1px solid #333;padding-top:4px;margin:0 8px}
    `;
    const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>${e(title)} ${e(item.voucherNo)}</title><style>${style}</style></head><body>
      <div class="vframe">
        <div class="head"><div>${arLines.map(x => `<div>${e(x)}</div>`).join('')}</div><div>${logo}</div><div dir="ltr">${enLines.map(x => `<div>${e(x)}</div>`).join('')}</div></div>
        <div class="titlebar">
          <div><span class="box"><b>رقم السند:</b> ${e(item.voucherNo)}</span></div>
          <div class="title">${e(title)}</div>
          <div class="left"><span class="box"><b>التاريخ:</b> ${e(item.date)}</span></div>
        </div>
        <div class="amt">
          <span class="box"><b>العملة:</b> ${e(cur.name || cur.symbol || '')}</span>
          <span class="box"><b>نوع السند:</b> ${e(kind)}</span>
          <span class="amtbox">${e(fmt)} ${e(cur.symbol || '')}</span>
        </div>
        <div class="line"><b>${isReceipt ? 'استلمنا من السيد/ـة:' : 'صرفنا إلى السيد/ـة:'}</b><span>${e(partyName)}</span></div>
        <div class="line"><b>مبلغ وقدره:</b><span>${e(amountInWords(amount, cur.name))}</span></div>
        <div class="line"><b>وذلك مقابل:</b><span>${e(statement)}</span></div>
        <div class="line"><b>${isReceipt ? 'إلى حساب:' : 'من حساب:'}</b><span>${e(cashName)}</span><b>رقم المرجع:</b><span>${e(ref)}</span></div>
        <div class="sign"><div>${isReceipt ? 'المسلِّم' : 'المستلم'}</div><div>المحاسب</div><div>المراجع</div><div>المدير العام</div></div>
      </div></body></html>`;
    await Utils.printHtml(title, html);
  }

  return { render, _amountInWords: amountInWords };
})();
