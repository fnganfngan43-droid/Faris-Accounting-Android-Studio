/* =========================================================
   شاشة العملات - فرعية من التهيئة
   ========================================================= */

const SetupCurrencies = (function () {
  let selectedId = null;

  function init() {}

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="cur-add">➕ إضافة</button>
        <button class="btn btn-icon" id="cur-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="cur-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>اسم العملة</th><th>الرمز</th><th>النوع</th><th>الفكة</th><th>سعر الصرف</th><th>الحد الأدنى</th><th>الحد الأقصى</th></tr></thead>
          <tbody id="cur-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="cur-sheet">
        <div class="sheet-handle"></div>
        <h3>بيانات العملة</h3>
        <form id="cur-form">
          <div class="form-grid">
            <label class="required">اسم العملة<input type="text" id="cur-name" required></label>
            <label class="required">رمز العملة<input type="text" id="cur-symbol" required></label>
            <label class="required field-wide">نوع العملة
              <select id="cur-type" required>
                <option value="محلي">محلي (عملة النظام)</option>
                <option value="اجنبي">أجنبي</option>
              </select>
            </label>
            <label class="optional">الفكة<input type="text" id="cur-fraction"></label>
            <label class="optional" id="cur-max-wrap">الحد الأقصى لسعر الصرف<input type="number" step="0.0001" id="cur-max"></label>
            <label class="required">سعر الصرف<input type="number" step="0.0001" id="cur-rate" required></label>
            <label class="optional" id="cur-min-wrap">الحد الأدنى لسعر الصرف<input type="number" step="0.0001" id="cur-min"></label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="cur-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#cur-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#cur-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#cur-del').addEventListener('click', onDelete);
    container.querySelector('#cur-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('cur-sheet')));
    container.querySelector('#cur-form').addEventListener('submit', onSave);
    container.querySelector('#cur-type').addEventListener('change', onTypeChange);

    await loadRows();
  }

  function onTypeChange() {
    const type = document.getElementById('cur-type').value;
    const rateField = document.getElementById('cur-rate');
    const isLocal = type === 'محلي';

    document.getElementById('cur-max-wrap').classList.toggle('hidden', !type || isLocal);
    document.getElementById('cur-min-wrap').classList.toggle('hidden', !type || isLocal);

    if (isLocal) {
      rateField.value = 1;
      rateField.readOnly = true;
    } else {
      rateField.readOnly = false;
      if (Number(rateField.value) === 1) rateField.value = '';
    }
  }

  async function loadRows() {
    const items = await FarisDB.getAll(STORES.CURRENCIES);
    const rows = document.getElementById('cur-rows');
    rows.innerHTML = items.map(c => `
      <tr data-id="${c.id}">
        <td>${Utils.escapeHtml(c.name)}</td>
        <td>${Utils.escapeHtml(c.symbol)}</td>
        <td>${Utils.escapeHtml(c.type || 'اجنبي')}</td>
        <td>${Utils.escapeHtml(c.fraction || '')}</td>
        <td>${Utils.escapeHtml(c.rate)}</td>
        <td>${Utils.escapeHtml(c.type === 'اجنبي' ? (c.minRate ?? '') : '—')}</td>
        <td>${Utils.escapeHtml(c.type === 'اجنبي' ? (c.maxRate ?? '') : '—')}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="empty-row">لا توجد عملات بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#cur-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('cur-edit').disabled = false;
    document.getElementById('cur-del').disabled = false;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('cur-sheet');
    document.getElementById('cur-form').reset();
    document.getElementById('cur-rate').readOnly = false;

    if (id) {
      const c = await FarisDB.get(STORES.CURRENCIES, id);
      document.getElementById('cur-name').value = c.name;
      document.getElementById('cur-symbol').value = c.symbol;
      document.getElementById('cur-type').value = c.type || 'اجنبي';
      document.getElementById('cur-fraction').value = c.fraction || '';
      document.getElementById('cur-rate').value = c.rate;
      document.getElementById('cur-max').value = c.maxRate ?? '';
      document.getElementById('cur-min').value = c.minRate ?? '';
      sheet.dataset.editId = id;
    } else {
      document.getElementById('cur-type').value = 'اجنبي';
      sheet.dataset.editId = '';
    }
    onTypeChange();
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('cur-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;
    const type = document.getElementById('cur-type').value;

    const existing = await FarisDB.getAll(STORES.CURRENCIES);

    if (type === 'محلي') {
      const otherLocal = existing.find(c => c.type === 'محلي' && c.id !== editId);
      if (otherLocal) {
        Utils.toast(`يوجد بالفعل عملة نظام محلية (${otherLocal.name})، لا يمكن إضافة أكثر من عملة محلية واحدة`, 'error');
        return;
      }
    }

    const value = {
      name: document.getElementById('cur-name').value.trim(),
      symbol: document.getElementById('cur-symbol').value.trim(),
      type,
      fraction: document.getElementById('cur-fraction').value.trim(),
      rate: type === 'محلي' ? 1 : Number(document.getElementById('cur-rate').value),
      maxRate: type === 'اجنبي' ? (Number(document.getElementById('cur-max').value) || null) : null,
      minRate: type === 'اجنبي' ? (Number(document.getElementById('cur-min').value) || null) : null
    };
    if (editId) value.id = editId;

    if (existing.some(c => c.name === value.name && c.id !== editId)) {
      Utils.toast('اسم العملة موجود مسبقًا', 'error');
      document.getElementById('cur-name').classList.add('field-invalid');
      return;
    }
    document.getElementById('cur-name').classList.remove('field-invalid');

    if (type === 'اجنبي' && value.maxRate && value.minRate && value.minRate > value.maxRate) {
      Utils.toast('الحد الأدنى لا يمكن أن يكون أكبر من الحد الأقصى', 'error');
      return;
    }

    await FarisDB.put(STORES.CURRENCIES, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف هذه العملة؟');
    if (!ok) return;
    await FarisDB.remove(STORES.CURRENCIES, selectedId);
    selectedId = null;
    document.getElementById('cur-edit').disabled = true;
    document.getElementById('cur-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { init, render };
})();
