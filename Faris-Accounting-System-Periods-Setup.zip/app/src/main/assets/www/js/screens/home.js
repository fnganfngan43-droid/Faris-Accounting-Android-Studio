/* =========================================================
   الشاشة الرئيسية
   ========================================================= */

const ScreenHome = (function () {

  function init() {
    App.register('home', {});

    document.getElementById('home-back-welcome').addEventListener('click', () => {
      App.show('welcome', { replace: true });
    });

    document.querySelectorAll('#home-grid .grid-icon').forEach((btn) => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.target;
        if (!target) {
          Utils.toast('هذه الشاشة ستُضاف في مرحلة قادمة', 'info');
          return;
        }
        App.show(target);
      });
    });
  }

  return { init };
})();
