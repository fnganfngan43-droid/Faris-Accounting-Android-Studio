/* =========================================================
   تقرير كشف حساب
   ========================================================= */

const ReportAccountStatement = (function () {
  let currenciesCache = [];
  let countriesCache = [];
  let govCache = [];
  let locationsCache = [];
  let lastResult = null;

  const PARTY_STORE = { 'عميل': STORES.CUSTOMERS, 'صناديق': STORES.CASHBOXES, 'بنوك': STORES.BANKS, 'موردين': STORES.SUPPLIERS };

  async function render(container) {
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    countriesCache = await FarisDB.getAll(STORES.COUNTRIES);
    govCache = await FarisDB.getAll(STORES.GOVERNORATES);
    locationsCache = await FarisDB.getAll(STORES.LOCATIONS);
    lastResult = null;

    const startOfYear = `${new Date().getFullYear()}-01-01`;
    const today = new Date().toISOString().slice(0, 10);

    container.innerHTML = `
      <div class="form-grid">
        <label class="required">من تاريخ<input type="date" id="as-from" value="${startOfYear}"></label>
        <label class="required">إلى تاريخ<input type="date" id="as-to" value="${today}"></label>

        <label class="required">نوع التقرير
          <select id="as-report-type">
            <option value="تحليلي">كشف تحليلي</option>
            <option value="اجمالي">كشف إجمالي</option>
            <option value="مطابقة">كشف مطابقة</option>
            <option value="مصادقة">مصادقة حساب</option>
          </select>
        </label>
        <label class="required">نوع العملية
          <select id="as-op-type">
            <option value="كلي">الكل</option>
            <option value="opening">الأرصدة الافتتاحية</option>
            <option value="journal">القيود اليومية</option>
            <option value="receipt">سند قبض</option>
            <option value="payment">سند الصرف</option>
            <option value="exchange">صرف عملة</option>
          </select>
        </label>

        <label class="optional">العملة
          <select id="as-currency"><option value="">الكل</option></select>
        </label>
        <label class="required">النوع
          <select id="as-account-type">
            <option value="حسابات">حسابات (الكل)</option>
            <option value="عام">عام</option>
            <option value="عميل">عملاء</option>
            <option value="صناديق">صناديق</option>
            <option value="بنوك">بنوك</option>
            <option value="موردين">موردون</option>
          </select>
        </label>

        <label class="required">من اسم حساب
          <div class="combo-wrap">
            <input type="text" id="as-from-account-input" autocomplete="off">
            <div class="autocomplete-list" id="as-from-account-list"></div>
          </div>
        </label>
        <label class="optional">إلى اسم حساب
          <div class="combo-wrap">
            <input type="text" id="as-to-account-input" autocomplete="off">
            <div class="autocomplete-list" id="as-to-account-list"></div>
          </div>
        </label>
        <input type="hidden" id="as-from-analytic-code">
        <input type="hidden" id="as-to-analytic-code">
      </div>

      <button type="button" class="btn btn-ghost full" id="as-toggle-more">أكثر ▾</button>

      <div class="form-grid hidden" id="as-more-fields">
        <label class="optional">فلترة حسب
          <select id="as-filter-by">
            <option value="كلي">الكل</option>
            <option value="رقم الحساب">رقم الحساب</option>
            <option value="اسم الحساب">اسم الحساب</option>
            <option value="المبلغ">المبلغ</option>
          </select>
        </label>
        <label class="optional">الترتيب
          <select id="as-sort">
            <option value="تصاعدي">تصاعدي</option>
            <option value="تنازلي">تنازلي</option>
          </select>
        </label>

        <div class="form-grid hidden" id="as-amount-filter-wrap" style="grid-column:1/-1;">
          <label class="optional">شرط المبلغ
            <select id="as-amount-op"><option value="كلي">الكل</option><option value="<">أقل من</option><option value=">">أكبر من</option><option value="=">يساوي</option></select>
          </label>
          <label class="optional">المبلغ<input type="number" step="0.01" id="as-amount-value"></label>
        </div>

        <label class="optional">من دولة<select id="as-country-from"><option value="">—</option></select></label>
        <label class="optional">إلى دولة<select id="as-country-to"><option value="">—</option></select></label>
        <label class="optional">من محافظة<select id="as-gov-from"><option value="">—</option></select></label>
        <label class="optional">إلى محافظة<select id="as-gov-to"><option value="">—</option></select></label>
        <label class="optional">من مدينة<select id="as-city-from"><option value="">—</option></select></label>
        <label class="optional">إلى مدينة<select id="as-city-to"><option value="">—</option></select></label>
      </div>

      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-icon" id="as-view" title="عرض">👁️</button>
        <button class="btn btn-icon" id="as-reset" title="مسح الفلاتر">🔄</button>
        ${ReportPrint.toolbarHtml('as')}
      </div>

      <div id="as-result"></div>
    `;

    document.getElementById('as-currency').innerHTML += currenciesCache.map(c => `<option value="${c.id}">(${c.symbol}) ${c.name}</option>`).join('');
    document.getElementById('as-country-from').innerHTML += countriesCache.map(c => `<option value="${c.id}">${Utils.escapeHtml(c.name)}</option>`).join('');
    document.getElementById('as-country-to').innerHTML += countriesCache.map(c => `<option value="${c.id}">${Utils.escapeHtml(c.name)}</option>`).join('');

    await fillAccountAutocomplete('from');
    await fillAccountAutocomplete('to');

    container.querySelector('#as-account-type').addEventListener('change', async () => { await fillAccountAutocomplete('from'); await fillAccountAutocomplete('to'); });
    container.querySelector('#as-report-type').addEventListener('change', async () => { await fillAccountAutocomplete('from'); await fillAccountAutocomplete('to'); });
    container.querySelector('#as-toggle-more').addEventListener('click', toggleMore);
    container.querySelector('#as-filter-by').addEventListener('change', onFilterByChange);
    container.querySelector('#as-country-from').addEventListener('change', () => fillGovOptions('from'));
    container.querySelector('#as-country-to').addEventListener('change', () => fillGovOptions('to'));
    container.querySelector('#as-gov-from').addEventListener('change', () => fillCityOptions('from'));
    container.querySelector('#as-gov-to').addEventListener('change', () => fillCityOptions('to'));
    container.querySelector('#as-view').addEventListener('click', onView);
    container.querySelector('#as-reset').addEventListener('click', () => render(container));
    ReportPrint.bindToolbar('as', async () => lastResult);
  }

  async function fillGovOptions(side) {
    const countryId = document.getElementById(`as-country-${side}`).value;
    const govs = countryId ? govCache.filter(g => Number(g.countryId) === Number(countryId)) : [];
    document.getElementById(`as-gov-${side}`).innerHTML = '<option value="">—</option>' + govs.map(g => `<option value="${g.id}">${Utils.escapeHtml(g.name)}</option>`).join('');
    await fillCityOptions(side);
  }
  async function fillCityOptions(side) {
    const govId = document.getElementById(`as-gov-${side}`).value;
    const locs = govId ? locationsCache.filter(l => Number(l.governorateId) === Number(govId)) : [];
    document.getElementById(`as-city-${side}`).innerHTML = '<option value="">—</option>' + locs.map(l => `<option value="${Utils.escapeHtml(l.city)}">${Utils.escapeHtml(l.city)}</option>`).join('');
  }

  function toggleMore() {
    const wrap = document.getElementById('as-more-fields');
    const btn = document.getElementById('as-toggle-more');
    const opening = wrap.classList.contains('hidden');
    wrap.classList.toggle('hidden', !opening);
    btn.textContent = opening ? 'تقصير ▴' : 'أكثر ▾';
  }

  function onFilterByChange() {
    document.getElementById('as-amount-filter-wrap').classList.toggle('hidden', document.getElementById('as-filter-by').value !== 'المبلغ');
  }

  // يبني قائمة الحسابات/الأطراف الخاصة بالنوع المختار، مُرتّبة، لاستخدامها في البحث والنطاقات
  async function buildEntityList() {
    const type = document.getElementById('as-account-type').value;
    const reportType = document.getElementById('as-report-type').value;
    let list = [];
    if (type === 'حسابات') {
      if (reportType === 'اجمالي') {
        const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
        list = accounts.filter(a => a.type === 'فرعي')
          .map(a => ({ accountCode: a.code, analyticCode: a.code, name: a.name, label: `${a.code} - ${a.name}`, displayValue: a.name, currencies: a.currencies || [] }));
      } else {
        const types = ['عام', 'عميل', 'صناديق', 'بنوك', 'موردين'];
        for (const t of types) list = list.concat(await buildEntityListForType(t, reportType));
      }
    } else {
      list = await buildEntityListForType(type, reportType);
    }
    list.sort((a, b) => a.analyticCode.localeCompare(b.analyticCode, undefined, { numeric: true }));
    return list;
  }

  // حسابات فرعية "أب" فقط (بدون تفصيل الأطراف تحتها) — تُستخدم في كشف إجمالي لأنواع العملاء/الصناديق/البنوك/الموردين
  async function buildParentAccountsForType(type) {
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    return accounts.filter(a => a.type === 'فرعي' && a.analyticType === type)
      .map(a => ({ accountCode: a.code, analyticCode: a.code, name: a.name, label: `${a.code} - ${a.name}`, displayValue: a.name, currencies: a.currencies || [] }));
  }

  async function buildEntityListForType(type, reportType) {
    if (type === 'عام') {
      const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
      return accounts.filter(a => a.type === 'فرعي' && (!a.analyticType || a.analyticType === 'عام'))
        .map(a => ({ accountCode: a.code, analyticCode: a.code, name: a.name, label: `${a.code} - ${a.name}`, displayValue: a.name, currencies: a.currencies || [] }));
    }
    if (reportType === 'اجمالي') {
      return buildParentAccountsForType(type);
    }
    const store = PARTY_STORE[type];
    const items = await FarisDB.getAll(store);
    return items.map(p => ({
      accountCode: p.parentAccountCode, analyticCode: `${p.parentAccountCode}-${p.partyNumber}`, name: p.name,
      label: `${p.parentAccountCode}-${p.partyNumber} - ${p.name}`, displayValue: p.name, currencies: p.currencies || [],
      countryId: p.countryId, governorateId: p.governorateId, city: p.city
    }));
  }

  function inNumRange(id, fromVal, toVal) {
    if (!fromVal && !toVal) return true;
    if (id === undefined || id === null || id === '') return false;
    const f = fromVal ? Number(fromVal) : -Infinity;
    const t = toVal ? Number(toVal) : Infinity;
    return id >= f && id <= t;
  }
  function inStrRange(val, fromVal, toVal) {
    if (!fromVal && !toVal) return true;
    if (val === undefined || val === null || val === '') return false;
    if (fromVal && val < fromVal) return false;
    if (toVal && val > toVal) return false;
    return true;
  }

  // يطبّق الحقول الإضافية (فلترة حسب/الترتيب/شرط المبلغ/نطاق الموقع) على قائمة الحسابات المطابقة للفلاتر الأساسية
  async function applyAdvancedFilters(entities, fromDate, toDate, currencyId, opType) {
    let list = entities;

    const countryFrom = document.getElementById('as-country-from').value;
    const countryTo = document.getElementById('as-country-to').value;
    const govFrom = document.getElementById('as-gov-from').value;
    const govTo = document.getElementById('as-gov-to').value;
    const cityFrom = document.getElementById('as-city-from').value;
    const cityTo = document.getElementById('as-city-to').value;

    if (countryFrom || countryTo) list = list.filter(e => inNumRange(e.countryId, countryFrom, countryTo));
    if (govFrom || govTo) list = list.filter(e => inNumRange(e.governorateId, govFrom, govTo));
    if (cityFrom || cityTo) list = list.filter(e => inStrRange(e.city, cityFrom, cityTo));

    const filterBy = document.getElementById('as-filter-by').value;
    const sort = document.getElementById('as-sort').value;

    if (filterBy === 'المبلغ') {
      const op = document.getElementById('as-amount-op').value;
      const val = Number(document.getElementById('as-amount-value').value) || 0;
      const withTotals = [];
      for (const e of list) {
        const t = await filteredTotals(e, currencyId, fromDate, toDate, opType);
        withTotals.push({ ent: e, amount: t.balance });
      }
      let filtered = withTotals;
      if (op !== 'كلي') {
        filtered = filtered.filter(x => op === '<' ? x.amount < val : op === '>' ? x.amount > val : Math.round(x.amount * 100) === Math.round(val * 100));
      }
      filtered.sort((a, b) => sort === 'تنازلي' ? b.amount - a.amount : a.amount - b.amount);
      list = filtered.map(x => x.ent);
    } else if (filterBy === 'رقم الحساب' || filterBy === 'كلي') {
      const code = e => String(e.displayCode || e.analyticCode || e.accountCode);
      list = [...list].sort((a, b) => sort === 'تنازلي' ? code(b).localeCompare(code(a), undefined, { numeric: true }) : code(a).localeCompare(code(b), undefined, { numeric: true }));
    } else if (filterBy === 'اسم الحساب') {
      list = [...list].sort((a, b) => sort === 'تنازلي' ? b.name.localeCompare(a.name, 'ar') : a.name.localeCompare(b.name, 'ar'));
    }

    return list;
  }

  // النص الديناميكي "التجميع بحسب: ..." حسب النوع المختار
  function groupingLabel() {
    const type = document.getElementById('as-account-type').value;
    const labels = { 'حسابات': 'رقم الحساب', 'عام': 'رقم الحساب', 'عميل': 'رقم العميل', 'صناديق': 'رقم الصندوق', 'بنوك': 'رقم البنك', 'موردين': 'رقم المورد' };
    return labels[type] || 'رقم الحساب';
  }

  async function fillAccountAutocomplete(side) {
    const input = document.getElementById(`as-${side}-account-input`);
    const list = document.getElementById(`as-${side}-account-list`);
    input.value = '';
    document.getElementById(`as-${side}-analytic-code`).value = '';

    const source = await buildEntityList();
    Utils.attachAutocomplete(input, list, (query) => query ? source.filter(it => it.label.includes(query)) : source, (item) => {
      input.value = item.displayValue || item.label;
      document.getElementById(`as-${side}-analytic-code`).value = item.analyticCode;
    });
  }

  // يحدد نطاق الحسابات حسب نوع التقرير وحقلي من/إلى
  function resolveRange(list, fromCode, toCode, reportType) {
    if (!fromCode && !toCode) return list;
    if (fromCode && !toCode) {
      if (reportType === 'اجمالي') {
        const idx = list.findIndex(x => x.analyticCode === fromCode);
        return idx === -1 ? [] : list.slice(idx);
      }
      const one = list.find(x => x.analyticCode === fromCode);
      return one ? [one] : [];
    }
    let startIdx = fromCode ? list.findIndex(x => x.analyticCode === fromCode) : 0;
    let endIdx = toCode ? list.findIndex(x => x.analyticCode === toCode) : list.length - 1;
    if (startIdx === -1) startIdx = 0;
    if (endIdx === -1) endIdx = list.length - 1;
    if (startIdx > endIdx) { const tmp = startIdx; startIdx = endIdx; endIdx = tmp; }
    return list.slice(startIdx, endIdx + 1);
  }

  function currenciesToIterate(entities, currencyId) {
    if (currencyId) return [currencyId];
    const set = new Set();
    entities.forEach(e => (e.currencies || []).forEach(id => set.add(id)));
    return Array.from(set);
  }

  function currencyById(id) { return currenciesCache.find(c => c.id === id); }

  const DETAIL_TITLES = { 'تحليلي': 'كشف تحليلي', 'مطابقة': 'كشف مطابقة', 'مصادقة': 'مصادقة حساب' };

  async function buildDetailBlock(entity, currencyId, fromDate, toDate, opType) {
    const tx = await ReportData.getLedgerTransactions({ accountCode: entity.accountCode, analyticCode: entity.analyticCode, fromDate, toDate, currencyId, opFilter: opType });
    const currency = currencyById(currencyId);
    const isAnalytic = entity.accountCode !== entity.analyticCode;
    const labelPrefix = isAnalytic ? 'التحليلي' : 'الفرعي';
    const displayCode = isAnalytic ? AccountAnalyticPicker.formatAnalyticDisplay(entity.accountCode, entity.analyticCode) : entity.accountCode;
    const headerRows = [
      [{ text: 'التاريخ', rowspan: 2 }, { text: 'نوع المستند', rowspan: 2 }, { text: 'رقم المستند', rowspan: 2 }, { text: 'البيان', rowspan: 2 }, { text: 'رقم المرجع', rowspan: 2 }, { text: 'المبلغ', colspan: 2 }, { text: 'الرصيد', rowspan: 2 }],
      [{ text: 'مدين' }, { text: 'دائن' }]
    ];
    const rows = tx.map(t => [t.date, t.docType, t.docNo, t.statement || '', t.refNo || '', t.debit ? t.debit.toFixed(2) : '', t.credit ? t.credit.toFixed(2) : '', t.balance.toFixed(2)]);
    const totalDebit = tx.reduce((s, t) => s + t.debit, 0);
    const totalCredit = tx.reduce((s, t) => s + t.credit, 0);
    const balance = totalDebit - totalCredit;
    const summaryRow = ['', '', '', `العدد : ${tx.length} — إجمالي العمليات`, '', totalDebit.toFixed(2), totalCredit.toFixed(2), balance.toFixed(2)];

    return {
      accountCode: displayCode, accountName: entity.name, labelPrefix, currencyLabel: currency ? `(${currency.symbol}) ${currency.name}` : '',
      headerRows, rows,
      totals: {
        summaryRow,
        balance,
        balanceFormatted: currency ? `${Math.abs(balance).toFixed(2)} ${currency.symbol}` : Math.abs(balance).toFixed(2),
        balanceWords: currency ? ReportPrint.amountToWords(balance, currency.name, currency.fraction) : ''
      },
      showSignatures: true
    };
  }

  // Summary parties must be expanded before location, amount and ordering filters.
  async function buildSummaryEntities(entities) {
    const type = document.getElementById('as-account-type').value;
    if (type === 'حسابات' || type === 'عام') {
      return entities.map(e => ({ ...e, analyticCode: type === 'حسابات' ? null : e.analyticCode, displayCode: e.accountCode }));
    }
    const list = [];
    for (const parent of entities) {
      const members = await FarisDB.getAllByIndex(PARTY_STORE[type], 'parentAccountCode', parent.accountCode);
      members.forEach(m => list.push({
        accountCode: parent.accountCode, analyticCode: `${m.parentAccountCode}-${m.partyNumber}`,
        displayCode: m.partyNumber, name: m.name, currencies: m.currencies || [],
        countryId: m.countryId, governorateId: m.governorateId, city: m.city
      }));
    }
    return list;
  }

  async function filteredTotals(entity, currencyId, fromDate, toDate, opType) {
    const tx = await ReportData.getLedgerTransactions({ accountCode: entity.accountCode,
      analyticCode: entity.analyticCode, currencyId, fromDate, toDate, opFilter: opType });
    const debit = tx.reduce((sum, t) => sum + t.debit, 0);
    const credit = tx.reduce((sum, t) => sum + t.credit, 0);
    return { debit, credit, balance: debit - credit };
  }

  function balanceColumns(balance) {
    const rounded = Math.round(balance * 100) / 100;
    return [rounded > 0 ? rounded.toFixed(2) : '', rounded < 0 ? Math.abs(rounded).toFixed(2) : ''];
  }

  async function buildSummaryTable(entities, currencyId, fromDate, toDate, opType) {
    const type = document.getElementById('as-account-type').value;
    const rows = [];
    let totalDebit = 0, totalCredit = 0;
    for (const ent of entities) {
      const totals = await filteredTotals(ent, currencyId, fromDate, toDate, opType);
      const [debit, credit] = balanceColumns(totals.balance);
      rows.push([ent.displayCode || ent.accountCode, ent.name, debit, credit]);
      totalDebit += Number(debit) || 0;
      totalCredit += Number(credit) || 0;
    }

    const headerRows = [
      [{ text: `التجميع بحسب : ${groupingLabel()}`, colspan: 2 }, { text: 'الرصيد الحالي', colspan: 2 }],
      [{ text: 'رقم التحليلي' }, { text: 'الاسم' }, { text: 'مدين' }, { text: 'دائن' }]
    ];
    const balance = totalDebit - totalCredit;
    const currency = currencyById(currencyId);

    let infoRow = null;
    if (type === 'عام' && entities.length === 1) {
      infoRow = { accountCode: entities[0].accountCode, accountName: entities[0].name };
    }

    return {
      accountName: currency ? `كشف إجمالي — عملة (${currency.symbol}) ${currency.name}` : 'كشف إجمالي',
      infoRow,
      headerRows,
      rows,
      totals: {
        summaryRow: ['الرصيد النهائي', '', ...balanceColumns(balance)],
        balance,
        balanceFormatted: currency ? `${Math.abs(balance).toFixed(2)} ${currency.symbol}` : Math.abs(balance).toFixed(2),
        balanceWords: currency ? ReportPrint.amountToWords(balance, currency.name, currency.fraction) : ''
      }
    };
  }

  async function onView() {
    const fromDate = document.getElementById('as-from').value;
    const toDate = document.getElementById('as-to').value;
    const reportType = document.getElementById('as-report-type').value;
    const opType = document.getElementById('as-op-type').value;
    const currencyId = document.getElementById('as-currency').value ? Number(document.getElementById('as-currency').value) : null;
    const fromCode = document.getElementById('as-from-analytic-code').value;
    const toCode = document.getElementById('as-to-analytic-code').value;

    const fullList = await buildEntityList();
    let entities = resolveRange(fullList, fromCode, toCode, reportType);
    lastResult = null;

    if (!entities.length) {
      Utils.toast('لا توجد حسابات ضمن هذا النطاق', 'error');
      document.getElementById('as-result').innerHTML = '';
      return;
    }

    const resultEl = document.getElementById('as-result');
    let htmlOut = '';

    if (reportType === 'اجمالي') {
      entities = await buildSummaryEntities(entities);
      const currencyIds = currencyId ? [currencyId] : [];
      if (!currencyId) {
        const set = new Set();
        for (const ent of entities) {
          (ent.currencies || []).forEach(id => set.add(Number(id)));
          const tx = await ReportData.getLedgerTransactions({ accountCode: ent.accountCode,
            analyticCode: ent.analyticCode, fromDate, toDate, opFilter: opType });
          tx.forEach(t => set.add(t.currencyId));
        }
        currencyIds.push(...set);
      }
      if (!currencyIds.length) {
        resultEl.innerHTML = '<p class="hint">لا توجد عملات مرتبطة بالحسابات المحددة</p>';
        return;
      }
      const blocks = [];
      for (const curId of currencyIds) {
        const candidates = [];
        for (const ent of entities) {
          const tx = await ReportData.getLedgerTransactions({ accountCode: ent.accountCode,
            analyticCode: ent.analyticCode, currencyId: curId, fromDate, toDate, opFilter: opType });
          if ((ent.currencies || []).some(id => Number(id) === curId) || tx.length) candidates.push(ent);
        }
        const filtered = await applyAdvancedFilters(candidates, fromDate, toDate, curId, opType);
        if (filtered.length) blocks.push(await buildSummaryTable(filtered, curId, fromDate, toDate, opType));
      }
      lastResult = { title: 'كشف إجمالي', reportKind: 'اجمالي', fromDate, toDate, blocks };
      htmlOut = blocks.map(b => renderSummaryBlock(b)).join('<hr class="report-block-sep">');
    } else {
      const blocks = [];
      const curIds = currencyId ? [currencyId] : [];
      if (!currencyId) {
        const foundCurrencies = new Set();
        for (const ent of entities) {
          const allTx = await ReportData.getLedgerTransactions({ accountCode: ent.accountCode,
            analyticCode: ent.analyticCode, fromDate, toDate, opFilter: opType });
          allTx.forEach(t => foundCurrencies.add(t.currencyId));
          (ent.currencies || []).forEach(id => foundCurrencies.add(Number(id)));
        }
        curIds.push(...foundCurrencies);
      }
      for (const curId of curIds) {
        const filtered = await applyAdvancedFilters(entities, fromDate, toDate, curId, opType);
        for (const ent of filtered) {
          const tx = await ReportData.getLedgerTransactions({ accountCode: ent.accountCode,
            analyticCode: ent.analyticCode, currencyId: curId, fromDate, toDate, opFilter: opType });
          if ((ent.currencies || []).some(id => Number(id) === curId) || tx.length) {
            blocks.push(await buildDetailBlock(ent, curId, fromDate, toDate, opType));
          }
        }
      }
      if (!blocks.length) {
        resultEl.innerHTML = '<p class="hint">لا توجد عملات مرتبطة بالحسابات المحددة، ولا حركات سابقة لها ضمن الفلاتر الحالية</p>';
        return;
      }
      lastResult = { title: DETAIL_TITLES[reportType] || 'كشف حساب', reportKind: reportType, fromDate, toDate, blocks };
      htmlOut = blocks.map(b => renderDetailBlock(b)).join('<hr class="report-block-sep">');
    }

    resultEl.innerHTML = htmlOut;
  }

  function balanceLabel(balance) {
    if (balance > 0) return 'إجمالي الرصيد عليكم';
    if (balance < 0) return 'إجمالي الرصيد لكم';
    return 'الرصيد متساوٍ (لا يوجد مستحق)';
  }

  function renderDetailBlock(b) {
    const theadRows = b.headerRows.map(row => `<tr>${row.map(c => `<th ${c.colspan ? `colspan="${c.colspan}"` : ''} ${c.rowspan ? `rowspan="${c.rowspan}"` : ''}>${Utils.escapeHtml(c.text)}</th>`).join('')}</tr>`).join('');
    return `
      <div class="account-info-bar-app">رقم الحساب ${Utils.escapeHtml(b.labelPrefix)}: <b>${Utils.escapeHtml(b.accountCode)}</b> — اسم الحساب ${Utils.escapeHtml(b.labelPrefix)}: <b>${Utils.escapeHtml(b.accountName)}</b> — العملة: <b>${Utils.escapeHtml(b.currencyLabel)}</b></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead>${theadRows}</thead>
          <tbody>${b.rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="8" class="empty-row">لا توجد حركات ضمن هذه الفلاتر — تحقق من نطاق التاريخ (من/إلى) ونوع العملية والعملة المختارة</td></tr>`}</tbody>
          <tfoot><tr>${b.totals.summaryRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>
        </table>
      </div>
      <p class="hint">${Utils.escapeHtml(balanceLabel(b.totals.balance))}: <b>${Utils.escapeHtml(b.totals.balanceFormatted)}</b> — ${Utils.escapeHtml(b.totals.balanceWords)}</p>
    `;
  }

  function renderSummaryBlock(b) {
    const theadRows = b.headerRows.map(row => `<tr>${row.map(c => `<th ${c.colspan ? `colspan="${c.colspan}"` : ''} ${c.rowspan ? `rowspan="${c.rowspan}"` : ''}>${Utils.escapeHtml(c.text)}</th>`).join('')}</tr>`).join('');
    const infoHtml = b.infoRow
      ? `<div class="account-info-bar-app">رقم الحساب الفرعي: <b>${Utils.escapeHtml(b.infoRow.accountCode)}</b> — اسم الحساب الفرعي: <b>${Utils.escapeHtml(b.infoRow.accountName)}</b></div>`
      : '';
    return `
      <h4>${Utils.escapeHtml(b.accountName)}</h4>
      ${infoHtml}
      <div class="table-scroll">
        <table class="data-table">
          <thead>${theadRows}</thead>
          <tbody>${b.rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="4" class="empty-row">لا توجد بيانات</td></tr>`}</tbody>
          <tfoot><tr>${b.totals.summaryRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>
        </table>
      </div>
      <p class="hint">${Utils.escapeHtml(balanceLabel(b.totals.balance))}: <b>${Utils.escapeHtml(b.totals.balanceFormatted)}</b> — ${Utils.escapeHtml(b.totals.balanceWords)}</p>
    `;
  }

  return { render };
})();
