/* =========================================================
   محرك حركة الصنف الموحّد (قراءة فقط)
   يجمع كل حركات الصنف من مصادرها الفعلية في قاعدة البيانات:
   - المخزون الافتتاحي (مستندات جديدة + سجلات قديمة متوافقة)
   - فواتير المبيعات / مرتجع المبيعات
   - فواتير المشتريات / مرجوع المشتريات
   بدون أي تكرار (لكل حركة مفتاح مصدر فريد)، وهذا هو المرجع
   الموحّد الذي تعتمد عليه بطاقة حركة الصنف وكل الشاشات الأخرى.
   كل حركة تحمل الكمية بوحدتها الأصلية للعرض (incomingQty/outgoingQty)
   وبأصغر وحدة قياس مربوطة بالصنف للرصيد التراكمي (incomingBaseQty/
   outgoingBaseQty)، عبر معامل ربط عبوة تلك الوحدة (linkFactor).
   أي مصدر حركة مستقبلي (تحويل مخزني...) يُضاف هنا فقط كدالة تجميع
   جديدة تُستدعى من gatherRawMovements.
   ========================================================= */

const ItemMovementEngine = (function () {

  // نوع الحركة -> الجهة التحليلية (تُستخدم في وضع "الحركة التحليلية")
  function analyticFromInvoiceOrReturn(doc) {
    if (doc.type === 'نقدي') return { type: 'صندوق', id: doc.cashboxId || null, name: doc.customerName || 'صندوق' };
    if (doc.type === 'آجل') return { type: 'عميل', id: doc.customerId || null, name: doc.customerName || 'عميل' };
    return { type: 'بنك', id: doc.bankId || null, name: doc.customerName || 'بنك' };
  }
  function analyticFromPurchase(doc) {
    if (doc.type === 'نقدي') return { type: 'صندوق', id: doc.cashboxId || null, name: doc.cashboxName || 'صندوق' };
    return { type: 'مورد', id: doc.supplierId || null, name: doc.supplierName || 'مورد' };
  }

  // معامل ربط عبوة الوحدة مع الصنف (لتطبيع الكمية لأصغر وحدة قياس)
  function unitLinkFactor(item, unitId) {
    if (!item) return 1;
    const u = item.units.find(x => x.unitId === unitId);
    return u ? (u.linkFactor || 1) : 1;
  }

  async function gatherRawMovements(itemCode) {
    const movements = [];
    const items = await FarisDB.getAll(STORES.INV_ITEMS);
    const item = items.find(i => i.code === itemCode);
    const factor = (unitId) => unitLinkFactor(item, unitId);

    // 1) المخزون الافتتاحي - المستندات الجديدة (تحمل التاريخ والمرجع والبيان)
    const docs = await FarisDB.getAll(STORES.INV_OPENING_STOCK_DOCS);
    docs.forEach(doc => {
      (doc.lines || []).forEach((l, idx) => {
        if (l.itemCode !== itemCode) return;
        const qty = Number(l.qty) || 0;
        movements.push({
          key: `opening-stock-doc-${doc.id}-${idx}`,
          sourceType: 'opening-stock', sourceId: doc.id,
          date: doc.date || '', type: 'رصيد افتتاحي', docNo: String(doc.id),
          itemCode: l.itemCode, itemName: l.itemName,
          warehouseId: doc.warehouseId, unitId: l.unitId, unitName: l.unitName,
          incomingQty: qty, outgoingQty: 0,
          incomingBaseQty: qty * factor(l.unitId), outgoingBaseQty: 0,
          unitCost: Number(l.cost) || 0, salePrice: null,
          reference: doc.reference || '', statement: doc.statement || 'رصيد افتتاحي',
          analytic: null
        });
      });
    });

    // 1ب) سجلات مخزون افتتاحي قديمة (متوافقة مع ما قبل نظام المستندات) - لا تملك docId
    const flatOpening = await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode);
    flatOpening.filter(r => !r.docId).forEach(r => {
      const qty = Number(r.quantity) || 0;
      movements.push({
        key: `opening-stock-flat-${r.id}`,
        sourceType: 'opening-stock', sourceId: r.id,
        date: '', type: 'رصيد افتتاحي', docNo: '—',
        itemCode: r.itemCode, itemName: '',
        warehouseId: r.warehouseId, unitId: r.unitId, unitName: '',
        incomingQty: qty, outgoingQty: 0,
        incomingBaseQty: qty * factor(r.unitId), outgoingBaseQty: 0,
        unitCost: Number(r.unitCost) || 0, salePrice: null,
        reference: '', statement: 'رصيد افتتاحي',
        analytic: null
      });
    });

    // 2) فواتير المبيعات (حركة منصرفة)
    const invoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    invoices.forEach(inv => {
      (inv.lines || []).forEach((l, idx) => {
        if (l.itemCode !== itemCode) return;
        const qty = Number(l.qty) || 0;
        movements.push({
          key: `invoice-sale-${inv.id}-${idx}`,
          sourceType: 'invoice-sale', sourceId: inv.id,
          date: inv.date || '', type: 'فاتورة مبيعات', docNo: inv.invoiceNo,
          itemCode: l.itemCode, itemName: l.itemName,
          warehouseId: l.warehouseId || inv.warehouseId, unitId: l.unitId, unitName: l.unitName,
          incomingQty: 0, outgoingQty: qty,
          incomingBaseQty: 0, outgoingBaseQty: qty * factor(l.unitId),
          unitCost: Number(l.costWarehouseCurrency) || 0, salePrice: Number(l.price) || 0,
          reference: inv.reference || '', statement: `فاتورة مبيعات رقم ${inv.invoiceNo}`,
          analytic: analyticFromInvoiceOrReturn(inv)
        });
      });
    });

    // 3) مرتجع المبيعات (حركة واردة)
    const returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    returns.forEach(ret => {
      (ret.lines || []).forEach((l, idx) => {
        if (l.itemCode !== itemCode) return;
        const qty = Number(l.qty) || 0;
        movements.push({
          key: `sales-return-${ret.id}-${idx}`,
          sourceType: 'sales-return', sourceId: ret.id,
          date: ret.date || '', type: 'مرتجع مبيعات', docNo: ret.returnNo,
          itemCode: l.itemCode, itemName: l.itemName,
          warehouseId: l.warehouseId || ret.warehouseId, unitId: l.unitId, unitName: l.unitName,
          incomingQty: qty, outgoingQty: 0,
          incomingBaseQty: qty * factor(l.unitId), outgoingBaseQty: 0,
          unitCost: Number(l.costWarehouseCurrency) || 0, salePrice: Number(l.price) || 0,
          reference: ret.reference || '', statement: `مرتجع مبيعات رقم ${ret.returnNo}`,
          analytic: analyticFromInvoiceOrReturn(ret)
        });
      });
    });

    // 4) فواتير المشتريات (حركة واردة) - تكلفة كل سطر محفوظة بالعملة المحلية، تُحوَّل لعملة المخزن للتناسق
    const purchaseInvoices = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    const warehouses = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const localCur = currencies.find(c => c.type === 'محلي');
    const convert = (amount, fromCur, toCur) => {
      if (!fromCur || !toCur || fromCur.id === toCur.id) return amount;
      const local = fromCur.type === 'محلي' ? amount : amount * fromCur.rate;
      return toCur.type === 'محلي' ? local : local / toCur.rate;
    };

    purchaseInvoices.forEach(pinv => {
      (pinv.lines || []).forEach((l, idx) => {
        if (l.itemCode !== itemCode) return;
        const qty = Number(l.qty) || 0;
        // ملاحظة: totalCostLocal في سطر فاتورة الشراء أصبح مخزَّنًا بعملة المخزون فعليًا (رغم اسم الحقل)
        const unitCost = qty ? (Number(l.totalCostLocal) || 0) / qty : 0;
        movements.push({
          key: `purchase-invoice-${pinv.id}-${idx}`,
          sourceType: 'purchase-invoice', sourceId: pinv.id,
          date: pinv.date || '', type: 'فاتورة مشتريات', docNo: pinv.invoiceNo,
          itemCode: l.itemCode, itemName: l.itemName,
          warehouseId: pinv.warehouseId, unitId: l.unitId, unitName: l.unitName,
          incomingQty: qty, outgoingQty: 0,
          incomingBaseQty: qty * factor(l.unitId), outgoingBaseQty: 0,
          unitCost, salePrice: null,
          reference: pinv.reference || '', statement: `فاتورة مشتريات رقم ${pinv.invoiceNo}`,
          analytic: analyticFromPurchase(pinv)
        });
      });
    });

    // 5) مرجوع المشتريات (حركة منصرفة - إرجاع للمورد)
    const purchaseReturns = await FarisDB.getAll(STORES.PURCHASE_RETURNS);
    purchaseReturns.forEach(ret => {
      (ret.lines || []).forEach((l, idx) => {
        if (l.itemCode !== itemCode) return;
        const qty = Number(l.qty) || 0;
        movements.push({
          key: `purchase-return-${ret.id}-${idx}`,
          sourceType: 'purchase-return', sourceId: ret.id,
          date: ret.date || '', type: 'مرجوع مشتريات', docNo: ret.returnNo,
          itemCode: l.itemCode, itemName: l.itemName,
          warehouseId: ret.warehouseId, unitId: l.unitId, unitName: l.unitName,
          incomingQty: 0, outgoingQty: qty,
          incomingBaseQty: 0, outgoingBaseQty: qty * factor(l.unitId),
          unitCost: Number(l.unitCostLocal) || 0, salePrice: Number(l.price) || 0,
          reference: ret.reference || '', statement: `مرجوع مشتريات رقم ${ret.returnNo}`,
          analytic: analyticFromPurchase(ret)
        });
      });
    });

    return movements;
  }

  // ترتيب زمني ثابت: التاريخ، ثم الرصيد الافتتاحي والوارد أولًا، ثم رقم المستند
  function sortMovements(list) {
    const typeOrder = { 'رصيد افتتاحي': 0, 'فاتورة مشتريات': 1, 'مرتجع مبيعات': 2, 'فاتورة مبيعات': 3, 'مرجوع مشتريات': 4 };
    return list.slice().sort((a, b) => {
      const d = String(a.date || '').localeCompare(String(b.date || ''));
      if (d !== 0) return d;
      const t = (typeOrder[a.type] ?? 9) - (typeOrder[b.type] ?? 9);
      if (t !== 0) return t;
      return String(a.docNo || '').localeCompare(String(b.docNo || ''));
    });
  }

  /**
   * يُرجع حركة الصنف الكاملة مع الرصيد التراكمي، مع تطبيق فلاتر العرض دون
   * كسر تسلسل الرصيد. الرصيد التراكمي يُحسب بأصغر وحدة قياس مربوطة بالصنف
   * (عبر معامل ربط كل حركة) بصرف النظر عن الوحدة المعروضة بكل صف، فيبقى
   * صحيحًا حتى لو اختلفت وحدات الحركات (حبة/درزن/كرتون...).
   * filters: { itemCode (إلزامي), warehouseId, unitId, fromDate, toDate }
   */
  async function getItemCard(filters) {
    const { itemCode, warehouseId, unitId, fromDate, toDate } = filters;
    if (!itemCode) return { rows: [], carriedForward: 0, totals: emptyTotals() };

    let all = await gatherRawMovements(itemCode);
    if (warehouseId) all = all.filter(m => m.warehouseId === warehouseId);
    if (unitId) all = all.filter(m => m.unitId === unitId);
    all = sortMovements(all);

    let balance = 0;
    all.forEach(m => {
      balance += m.incomingBaseQty - m.outgoingBaseQty;
      m.balance = balance;
    });

    const inRange = (d) => (!fromDate || (d && d >= fromDate)) && (!toDate || (d && d <= toDate));
    const before = all.filter(m => m.date && fromDate && m.date < fromDate);
    const carriedForward = before.length ? before[before.length - 1].balance : 0;

    const rows = all.filter(m => inRange(m.date));

    return { rows, carriedForward, totals: computeTotals(rows), allCount: all.length };
  }

  function emptyTotals() {
    return { incomingQty: 0, outgoingQty: 0, balance: 0, avgCost: 0, totalValue: 0, totalSale: 0 };
  }

  function computeTotals(rows) {
    const incomingQty = rows.reduce((s, r) => s + (r.incomingBaseQty ?? r.incomingQty), 0);
    const outgoingQty = rows.reduce((s, r) => s + (r.outgoingBaseQty ?? r.outgoingQty), 0);
    const balance = rows.length ? rows[rows.length - 1].balance : 0;
    const incomingValue = rows.filter(r => r.incomingQty > 0).reduce((s, r) => s + (r.incomingQty * r.unitCost), 0);
    const incomingQtyOnly = rows.filter(r => r.incomingQty > 0).reduce((s, r) => s + r.incomingQty, 0);
    const avgCost = incomingQtyOnly ? incomingValue / incomingQtyOnly : 0;
    const totalValue = balance * avgCost;
    const totalSale = rows.reduce((s, r) => s + (r.outgoingQty * (r.salePrice || 0)), 0);
    return { incomingQty, outgoingQty, balance, avgCost, totalValue, totalSale };
  }

  // تجميع إجمالي (بدون تفصيل جهة تحليلية) - سطر واحد
  function aggregateTotal(rows) {
    return computeTotals(rows);
  }

  // تجميع تحليلي: حسب الجهة (عميل/صندوق/بنك)، وسطر منفصل لحركة بلا جهة تحليلية (رصيد افتتاحي)
  function aggregateByAnalytic(rows) {
    const groups = new Map();
    rows.forEach(r => {
      const key = r.analytic ? `${r.analytic.type}:${r.analytic.id || r.analytic.name}` : 'none';
      if (!groups.has(key)) {
        groups.set(key, { label: r.analytic ? `${r.analytic.type} - ${r.analytic.name}` : 'بدون جهة تحليلية (رصيد افتتاحي)', rows: [] });
      }
      groups.get(key).rows.push(r);
    });
    return Array.from(groups.values()).map(g => ({ label: g.label, totals: computeTotals(g.rows) }));
  }

  // معلومات الربط المحاسبي (للعرض فقط - لا يُنشئ أي حركة محاسبية)
  async function getGlLinks(warehouseId) {
    const warehouses = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    const warehouse = warehouses.find(w => w.id === warehouseId);
    if (!warehouse) return null;
    const mapping = await FarisDB.get(STORES.INV_GL_MAPPING, warehouse.groupId).catch(() => null);
    return mapping || null;
  }

  /**
   * يمنع كسر تسلسل حركة المخزون الزمني: يتحقق هل يوجد لصنف معيّن في مخزن معيّن
   * حركة لاحقة (بتاريخ أبعد) من الاتجاه المعاكس (وارد↔منصرف) عن حركة تحمل المفتاح
   * excludeKey، بحيث لا يمكن تعديل/حذف حركة وارِدة (رصيد افتتاحي/مشتريات/مرتجع مبيعات)
   * إن كانت هناك حركة منصرفة بعدها اعتمدت على توفر هذه الكمية، والعكس أيضًا
   * (لا يمكن تعديل/حذف حركة منصرفة إن كانت هناك حركة واردة لاحقة مرتبطة بها، مثل
   * مرتجع مبيعات لاحق لفاتورة مبيعات).
   * يُرجع الحركة اللاحقة المُعيقة إن وُجدت، أو null إن كان التعديل/الحذف آمنًا.
   */
  async function findBlockingLaterMovement(itemCode, warehouseId, date, isIncoming, excludeKey) {
    const all = await gatherRawMovements(itemCode);
    const later = all.filter(m => {
      if (excludeKey && m.key === excludeKey) return false;
      if (warehouseId && m.warehouseId !== warehouseId) return false;
      if (!(String(m.date || '') > String(date || ''))) return false;
      const mIsIncoming = m.incomingQty > 0;
      return mIsIncoming !== isIncoming;
    });
    if (!later.length) return null;
    // نُرجع أقرب حركة معيقة (الأولى زمنيًا) لتوضيح السبب للمستخدم
    return sortMovements(later)[0];
  }

  return { getItemCard, aggregateTotal, aggregateByAnalytic, getGlLinks, findBlockingLaterMovement, gatherRawMovements };
})();
