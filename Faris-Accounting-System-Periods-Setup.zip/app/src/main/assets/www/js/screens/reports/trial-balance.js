/* =========================================================
   تقرير ميزان المراجعة
   يدعم التصفية حسب العملة، وخيارين للعرض:
   - بالعملة المحلية: كل الحركات (بأي عملة) تُحوَّل وتُجمع بالعملة المحلية
   - بعملتها الأصلية مقابل المحلية: يعرض المبلغ بعملة الحركة نفسها + عمود مقابله بالمحلية
   عمود الرصيد ينقسم دومًا لعمودين: رصيد مدين / رصيد دائن
   ========================================================= */

const ReportTrialBalance = (function () {
  let lastResult = null;

  async function render(container) {
    lastResult = null;
    const startOfYear = '2000-01-01';
    const today = new Date().toISOString().slice(0, 10);
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);

    container.innerHTML = `
      <div class="form-grid">
        <label class="required">من تاريخ<input type="date" id="tb-from" value="${startOfYear}"></label>
        <label class="required">إلى تاريخ<input type="date" id="tb-to" value="${today}"></label>
        <label class="optional">إظهار
          <select id="tb-show">
            <option value="غير صفرية" selected>غير الصفرية فقط</option>
            <option value="الكل">كل الحسابات</option>
            <option value="مدينة">الأرصدة المدينة فقط</option>
            <option value="دائنة">الأرصدة الدائنة فقط</option>
          </select>
        </label>
        <label class="optional">طريقة العرض
          <select id="tb-display">
            <option value="محلي">بالعملة المحلية</option>
            <option value="اصلي">بعملتها الأصلية مقابل المحلية</option>
          </select>
        </label>
        <label class="optional field-wide" id="tb-currency-wrap">العملة
          <select id="tb-currency"><option value="">كل العملات</option>${currencies.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('')}</select>
        </label>
      </div>
      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-primary" id="tb-view">🔍 عرض</button>
        <button class="btn btn-ghost" id="tb-reset">🔄 مسح الفلاتر</button>
        ${ReportPrint.toolbarHtml('tb')}
      </div>
      <div id="tb-result"></div>
    `;

    container.querySelector('#tb-view').addEventListener('click', onView);
    container.querySelector('#tb-reset').addEventListener('click', () => render(container));
    ReportPrint.bindToolbar('tb', async () => lastResult);
  }

  async function onView() {
    const fromDate = document.getElementById('tb-from').value;
    const toDate = document.getElementById('tb-to').value;
    const show = document.getElementById('tb-show').value;
    const displayMode = document.getElementById('tb-display').value; // محلي | اصلي
    const currencyId = document.getElementById('tb-currency').value ? Number(document.getElementById('tb-currency').value) : null;

    const accounts = await ReportData.getAllSubAccountsFlat();
    const currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    const rows = [];

    if (displayMode === 'محلي') {
      // كل الحركات (بأي عملة سُجِّلت) تُحوَّل وتُجمع بالعملة المحلية بصرف النظر عن فلتر العملة
      let totalDebit = 0, totalCredit = 0;
      for (const acc of accounts) {
        if (acc.analyticType && acc.analyticType !== 'عام') continue;
        const totals = await ReportData.getAccountTotalsLocal(acc.code, acc.code, fromDate, toDate, currenciesCache);
        if (show === 'غير صفرية' && totals.balance === 0) continue;
        if (show === 'مدينة' && totals.balance <= 0) continue;
        if (show === 'دائنة' && totals.balance >= 0) continue;

        const debitBalance = totals.balance >= 0 ? totals.balance : 0;
        const creditBalance = totals.balance < 0 ? Math.abs(totals.balance) : 0;
        rows.push([acc.code, acc.name, totals.debit.toFixed(2), totals.credit.toFixed(2), debitBalance ? debitBalance.toFixed(2) : '', creditBalance ? creditBalance.toFixed(2) : '']);
        totalDebit += totals.debit;
        totalCredit += totals.credit;
      }

      const headers = ['رقم الحساب', 'اسم الحساب', 'مدين', 'دائن', 'رصيد مدين', 'رصيد دائن'];
      const netDebit = Math.max(0, totalDebit - totalCredit);
      const netCredit = Math.max(0, totalCredit - totalDebit);
      const footerRow = ['', 'الإجمالي (بالعملة المحلية)', totalDebit.toFixed(2), totalCredit.toFixed(2), netDebit ? netDebit.toFixed(2) : '', netCredit ? netCredit.toFixed(2) : ''];
      lastResult = { title: 'ميزان المراجعة (بالعملة المحلية)', fromDate, toDate, headers, rows, footerRow };
      renderTable(headers, rows, footerRow);
    } else {
      // بعملتها الأصلية (أو عملة محددة) + عمود مقابل بالعملة المحلية لكل قيمة
      const currencySymbol = currencyId ? (currenciesCache.find(c => c.id === currencyId) || {}).symbol || '' : '';
      let totalDebit = 0, totalCredit = 0, totalDebitLocal = 0, totalCreditLocal = 0;

      for (const acc of accounts) {
        if (acc.analyticType && acc.analyticType !== 'عام') continue;
        const totals = await ReportData.getAccountTotals(acc.code, acc.code, fromDate, toDate, currencyId);
        if (!totals.count) continue;
        if (show === 'غير صفرية' && totals.balance === 0) continue;
        if (show === 'مدينة' && totals.balance <= 0) continue;
        if (show === 'دائنة' && totals.balance >= 0) continue;

        const totalsLocal = await ReportData.getAccountTotalsLocal(acc.code, acc.code, fromDate, toDate, currenciesCache, currencyId);
        const debitBalance = totals.balance >= 0 ? totals.balance : 0;
        const creditBalance = totals.balance < 0 ? Math.abs(totals.balance) : 0;
        const debitBalanceLocal = totalsLocal.balance >= 0 ? totalsLocal.balance : 0;
        const creditBalanceLocal = totalsLocal.balance < 0 ? Math.abs(totalsLocal.balance) : 0;

        rows.push([
          acc.code, acc.name,
          totals.debit.toFixed(2), totals.credit.toFixed(2),
          debitBalance ? debitBalance.toFixed(2) : '', creditBalance ? creditBalance.toFixed(2) : '',
          debitBalanceLocal ? debitBalanceLocal.toFixed(2) : '', creditBalanceLocal ? creditBalanceLocal.toFixed(2) : ''
        ]);
        totalDebit += totals.debit; totalCredit += totals.credit;
        totalDebitLocal += totalsLocal.debit; totalCreditLocal += totalsLocal.credit;
      }

      const headers = ['رقم الحساب', 'اسم الحساب', `مدين${currencySymbol ? ' (' + currencySymbol + ')' : ''}`, `دائن${currencySymbol ? ' (' + currencySymbol + ')' : ''}`, 'رصيد مدين', 'رصيد دائن', 'رصيد مدين (محلي)', 'رصيد دائن (محلي)'];
      const netDebit = Math.max(0, totalDebit - totalCredit);
      const netCredit = Math.max(0, totalCredit - totalDebit);
      const netDebitLocal = Math.max(0, totalDebitLocal - totalCreditLocal);
      const netCreditLocal = Math.max(0, totalCreditLocal - totalDebitLocal);
      const footerRow = ['', 'الإجمالي', totalDebit.toFixed(2), totalCredit.toFixed(2), netDebit ? netDebit.toFixed(2) : '', netCredit ? netCredit.toFixed(2) : '', netDebitLocal ? netDebitLocal.toFixed(2) : '', netCreditLocal ? netCreditLocal.toFixed(2) : ''];
      lastResult = { title: `ميزان المراجعة${currencySymbol ? ' - ' + currencySymbol : ' (كل العملات)'} مقابل العملة المحلية`, fromDate, toDate, headers, rows, footerRow };
      renderTable(headers, rows, footerRow);
    }
  }

  function renderTable(headers, rows, footerRow) {
    document.getElementById('tb-result').innerHTML = `
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${headers.length}" class="empty-row">لا توجد بيانات</td></tr>`}</tbody>
          <tfoot><tr>${footerRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>
        </table>
      </div>
    `;
  }

  return { render };
})();
