/* =========================================================
   قائمة الدخل / الميزانية العمومية
   ========================================================= */

const ReportIncomeBalance = (function () {
  let lastResult = null;
  let currentKind = null;

  const CONFIG = {
    income: { title: 'قائمة الدخل (أرباح وخسائر)', reportType: 'أرباح وخسائر' },
    balance: { title: 'الميزانية العمومية', reportType: 'ميزانية عمومية' }
  };

  async function render(container, kind) {
    currentKind = kind;
    lastResult = null;
    const today = new Date().toISOString().slice(0, 10);
    const startOfYear = '2000-01-01';

    container.innerHTML = `
      <div class="form-grid">
        <label class="required">من تاريخ<input type="date" id="ib-from" value="${startOfYear}"></label>
        <label class="required">إلى تاريخ<input type="date" id="ib-to" value="${today}"></label>
      </div>
      <div class="toolbar" style="margin-top:10px;">
        <button class="btn btn-primary" id="ib-view">🔍 عرض</button>
        <button class="btn btn-ghost" id="ib-reset">🔄 مسح الفلاتر</button>
        ${ReportPrint.toolbarHtml('ib')}
      </div>
      <div id="ib-result"></div>
    `;

    container.querySelector('#ib-view').addEventListener('click', onView);
    container.querySelector('#ib-reset').addEventListener('click', () => render(container, kind));
    ReportPrint.bindToolbar('ib', async () => lastResult);
  }

  async function onView() {
    const cfg = CONFIG[currentKind];
    const fromDate = document.getElementById('ib-from').value;
    const toDate = document.getElementById('ib-to').value;

    const allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    const roots = allAccounts.filter(a => a.rank === 1).sort((a, b) => String(a.code).localeCompare(String(b.code)));
    const norm = (s) => String(s || '').replace(/[أإآ]/g, 'ا').trim();
    // كل الحسابات الفرعية التي نوع تقريرها مطابق
    const relevant = allAccounts.filter(a => a.type === 'فرعي' && norm(a.reportType || 'ميزانية عمومية') === norm(cfg.reportType))
      .sort((a, b) => String(a.code).localeCompare(String(b.code)));

    const headers = ['رقم الحساب', 'اسم الحساب', 'مدين', 'دائن'];
    const rows = [];
    const rootDebitTotals = {};
    const rootCreditTotals = {};
    const used = new Set();

    const groups = roots.map(root => ({ root, accs: relevant.filter(a => String(a.code).startsWith(String(root.code)) && a.code !== root.code) }));
    groups.forEach(g => g.accs.forEach(a => used.add(a.code)));
    const orphans = relevant.filter(a => !used.has(a.code));
    if (orphans.length) groups.push({ root: { code: '', name: 'حسابات أخرى' }, accs: orphans });

    for (const { root, accs } of groups) {
      if (!accs.length) continue;
      let rootDebit = 0, rootCredit = 0;
      const groupRows = [];
      for (const acc of accs) {
        // null = كل الحسابات التحليلية (العملاء/الموردين/الصناديق) تحت هذا الحساب، مع تحويل العملات الأجنبية للمحلية
        const totals = await ReportData.getAccountTotalsLocal(acc.code, null, fromDate, toDate, currenciesCache);
        const bal = Math.round((totals.balance || 0) * 100) / 100;
        if (bal === 0) continue; // إخفاء الأرصدة الصفرية في التقريرين
        groupRows.push([acc.code, acc.name, bal > 0 ? bal.toFixed(2) : '', bal < 0 ? Math.abs(bal).toFixed(2) : '']);
        if (bal > 0) rootDebit += bal; else rootCredit += Math.abs(bal);
      }
      if (!groupRows.length) continue;
      rows.push([root.code, `— ${root.name} —`, '', '']);
      rows.push(...groupRows);
      rows.push(['', `إجمالي ${root.name}`, rootDebit.toFixed(2), rootCredit.toFixed(2)]);
      rootDebitTotals[root.name] = rootDebit;
      rootCreditTotals[root.name] = rootCredit;
    }

    // صافي كل جانب (مدين - دائن) لكل قسم رئيسي، لاستخدامه في حساب صافي الربح/الفرق
    const netOf = (rootName) => (rootDebitTotals[rootName] || 0) - (rootCreditTotals[rootName] || 0);

    let footerRow;
    if (currentKind === 'income') {
      // الإيرادات دائنة الطبيعة والمصروفات مدينة الطبيعة؛ صافي الربح = صافي دائن الإيرادات - صافي مدين المصروفات
      const revenueNet = -netOf('الإيرادات'); // موجب لو الإيرادات دائنة كما هو متوقع
      const expensesNet = netOf('المصروفات'); // موجب لو المصروفات مدينة كما هو متوقع
      const profit = revenueNet - expensesNet;
      footerRow = ['', 'صافي الربح / الخسارة (بالعملة المحلية)', profit >= 0 ? profit.toFixed(2) : '', profit < 0 ? Math.abs(profit).toFixed(2) : ''];
    } else {
      const assetsNet = netOf('الأصول');
      const liabilitiesNet = -netOf('الخصوم');
      const diff = assetsNet - liabilitiesNet;
      footerRow = ['', 'الفرق (الأصول - الخصوم) بالعملة المحلية', diff >= 0 ? diff.toFixed(2) : '', diff < 0 ? Math.abs(diff).toFixed(2) : ''];
    }

    lastResult = { title: `${cfg.title} (بالعملة المحلية)`, fromDate, toDate, headers, rows, footerRow };

    document.getElementById('ib-result').innerHTML = `
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="4" class="empty-row">لا توجد بيانات — تأكد من تصنيف الحسابات (نوع التقرير) في الدليل المحاسبي</td></tr>`}</tbody>
          <tfoot><tr>${footerRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>
        </table>
      </div>
    `;
  }

  return { render };
})();
