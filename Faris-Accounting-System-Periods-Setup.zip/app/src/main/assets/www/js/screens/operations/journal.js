/* =========================================================
   القيود اليومية
   ========================================================= */

const OpJournal = (function () {
  let selectedId = null;
  let currenciesCache = [];
  let draftLines = []; // الأسطر الحالية قيد الإضافة/التعديل
  let lineCounter = 0;

  async function render(container) {
    selectedId = null;
    draftLines = [];
    lineCounter = 0;

    container.innerHTML = `
      <div class="jr-sticky-top">
        <div class="toolbar icon-only">
          <button class="btn btn-icon" id="jr-add" title="إضافة قيد">➕</button>
          <button class="btn btn-icon" id="jr-save" title="حفظ القيد">💾</button>
          <button class="btn btn-icon" id="jr-import" title="استيراد إكسل">📥</button>
          <button class="btn btn-icon" id="jr-print" title="طباعة">🖨️</button>
          <button class="btn btn-icon" id="jr-edit" disabled title="تعديل">✏️</button>
          <button class="btn btn-icon" id="jr-del" disabled title="حذف">🗑️</button>
        </div>
        <div class="toolbar search-row">
          <input type="text" id="jr-search" placeholder="🔍 بحث...">
          <select id="jr-search-col"><option value="">كل الأعمدة</option></select>
        </div>

        <div id="jr-entry-form" style="display:none;">
        <div class="form-grid" style="margin-bottom:10px;">
          <label class="optional">رقم القيد<input type="text" id="jr-no"></label>
          <label class="required">التاريخ<input type="date" id="jr-date" required></label>
          <label class="optional">العملة المحلية<input type="text" id="jr-local-currency" readonly></label>
        </div>

        <div class="table-scroll">
          <table class="data-table" id="jr-draft-table">
            <thead><tr>
              <th>اسم الحساب</th><th>الحساب التحليلي</th><th>البيان</th><th>العملة</th><th>مدين</th><th>دائن</th><th>رقم المرجع</th><th></th>
            </tr></thead>
            <tbody>
              <tr class="table-input-row" id="jr-entry-row">
                <td>${AccountAnalyticPicker.markupCompact('jrl')}</td>
                <td>${AccountAnalyticPicker.markupAnalyticCompact('jrl')}</td>
                <td><input type="text" id="jrl-statement" class="table-input"></td>
                <td><select id="jrl-currency" class="table-input"><option value="">—</option></select></td>
                <td><input type="number" step="0.01" id="jrl-debit" class="table-input" value="0"></td>
                <td><input type="number" step="0.01" id="jrl-credit" class="table-input" value="0"></td>
                <td><input type="text" id="jrl-ref" class="table-input"></td>
                <td><button type="button" class="btn btn-icon" id="jr-line-add">➕</button></td>
              </tr>
            </tbody>
            <tbody id="jr-draft-rows"></tbody>
          <tfoot><tr>
            <td colspan="4"><b>الإجمالي</b></td>
            <td id="jr-total-debit">0</td><td id="jr-total-credit">0</td><td colspan="2"></td>
          </tr></tfoot>
        </table>
        </div>
        </div>
      </div>

      <h3 style="margin-top:16px;">القيود المحفوظة</h3>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم القيد</th><th>التاريخ</th><th>عدد الأسطر</th><th>إجمالي مدين</th><th>إجمالي دائن</th></tr></thead>
          <tbody id="jr-saved-rows"></tbody>
        </table>
      </div>

      <div class="popup-sheet" id="jr-import-popup">
        <div class="popup-header"><span>استيراد قيود من إكسل</span><button class="btn-close" id="jr-import-close">✖️</button></div>
        <p class="hint">يبدأ الاستيراد من الصف الثاني. كل صف = سطر قيد واحد، الأسطر التي تحمل نفس (رقم القيد + التاريخ) تُجمع في قيد واحد. ترتيب الأعمدة:<br>
          <b>1) رقم القيد &nbsp;2) التاريخ &nbsp;3) رقم الحساب التحليلي &nbsp;4) البيان &nbsp;5) رمز العملة &nbsp;6) مدين &nbsp;7) دائن &nbsp;8) رقم المرجع</b></p>
        <input type="file" id="jr-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="jr-import-status"></p>
      </div>
    `;

    await AccountAnalyticPicker.init('jrl');
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    document.getElementById('jr-local-currency').value = localCurrencyLabel();

    document.getElementById('jr-search-col').innerHTML += ['رقم القيد', 'التاريخ', 'اسم الحساب', 'اسم الحساب التحليلي', 'البيان', 'رمز العملة']
      .map(c => `<option value="${c}">${c}</option>`).join('');

    document.getElementById('jr-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('jr-no').value = await nextEntryNo();

    container.querySelector('#jr-line-add').addEventListener('click', onAddLine);
    container.querySelector('#jrl-ref').addEventListener('blur', onRefBlurCheck);
    container.querySelector('#jr-save').addEventListener('click', onSaveEntry);
    container.querySelector('#jr-add').addEventListener('click', async () => {
      draftLines = [];
      drawDraftRows();
      document.getElementById('jr-no').dataset.editId = '';
      document.getElementById('jr-no').value = await nextEntryNo();
      document.getElementById('jr-date').value = new Date().toISOString().slice(0, 10);
      showEntryForm(true);
    });
    container.querySelector('#jr-edit').addEventListener('click', () => loadEntryToDraft(selectedId));
    container.querySelector('#jr-del').addEventListener('click', onDeleteEntry);

    container.querySelector('#jr-import').addEventListener('click', () => {
      document.getElementById('jr-import-status').textContent = '';
      document.getElementById('jr-import-file').value = '';
      Utils.openSheet(document.getElementById('jr-import-popup'));
    });
    container.querySelector('#jr-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('jr-import-popup')));
    container.querySelector('#jr-import-file').addEventListener('change', onImportExcel);
    container.querySelector('#jr-print').addEventListener('click', onPrint);

    container.querySelector('#jr-search').addEventListener('input', () => loadSavedRows());
    container.querySelector('#jr-search-col').addEventListener('change', () => loadSavedRows());

    drawDraftRows();
    await loadSavedRows();
    Utils.applyInlineLabels(container);
  }

  function showEntryForm(show) {
    const f = document.getElementById('jr-entry-form');
    if (f) f.style.display = show ? '' : 'none';
  }

  function localCurrencyLabel() {
    const c = currenciesCache.find(c => c.type === 'محلي');
    return c ? (c.symbol || c.name) : '';
  }

  async function nextEntryNo() {
    const items = await FarisDB.getAll(STORES.JOURNAL);
    const numeric = items.map(i => Number(i.entryNo)).filter(n => !isNaN(n));
    return String(numeric.length ? Math.max(...numeric) + 1 : 1);
  }

  function currencySymbol(id) {
    const c = currenciesCache.find(c => c.id === id);
    return c ? c.symbol : '';
  }

  async function onRefBlurCheck() {
    const field = document.getElementById('jrl-ref');
    const value = field.value.trim();
    if (!value) return;

    const inDraft = draftLines.some(l => l.refNo === value);
    let inSaved = false;
    if (!inDraft) {
      const entries = await FarisDB.getAll(STORES.JOURNAL);
      inSaved = entries.some(entry => (entry.lines || []).some(l => l.refNo === value));
    }
    if (inDraft || inSaved) {
      Utils.toast('رقم المرجع مكرر، تأكد من الرقم', 'error');
      field.classList.add('field-invalid');
    } else {
      field.classList.remove('field-invalid');
    }
  }

  async function onAddLine() {
    const picked = await AccountAnalyticPicker.getValue('jrl');
    if (!picked) { Utils.toast('اختر الحساب والحساب التحليلي والعملة', 'error'); return; }

    const debit = Number(document.getElementById('jrl-debit').value) || 0;
    const credit = Number(document.getElementById('jrl-credit').value) || 0;
    if (debit === 0 && credit === 0) { Utils.toast('أدخل مبلغًا مدينًا أو دائنًا', 'error'); return; }

    draftLines.push({
      _id: ++lineCounter,
      ...picked,
      statement: document.getElementById('jrl-statement').value.trim(),
      debit, credit,
      refNo: document.getElementById('jrl-ref').value.trim()
    });

    resetEntryRow();
    drawDraftRows();
  }

  function resetEntryRow() {
    AccountAnalyticPicker.resetAll('jrl');
    document.getElementById('jrl-currency').innerHTML = '<option value="">—</option>';
    document.getElementById('jrl-statement').value = '';
    document.getElementById('jrl-debit').value = '0';
    document.getElementById('jrl-credit').value = '0';
    document.getElementById('jrl-ref').value = '';
  }

  function drawDraftRows() {
    const tbody = document.getElementById('jr-draft-rows');
    tbody.innerHTML = draftLines.map(l => `
      <tr data-lid="${l._id}">
        <td>${Utils.escapeHtml(l.accountName)}</td><td>${Utils.escapeHtml(l.analyticName)}</td>
        <td>${Utils.escapeHtml(l.statement)}</td><td>${Utils.escapeHtml(currencySymbol(l.currencyId))}</td>
        <td>${l.debit}</td><td>${l.credit}</td><td>${Utils.escapeHtml(l.refNo)}</td>
        <td><button type="button" class="btn-close" data-remove="${l._id}">✖️</button></td>
      </tr>`).join('') || '<tr><td colspan="8" class="empty-row">أضف أسطر القيد أولًا</td></tr>';

    tbody.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', () => {
        draftLines = draftLines.filter(l => l._id !== Number(btn.dataset.remove));
        drawDraftRows();
      });
    });

    const totalDebit = draftLines.reduce((s, l) => s + l.debit, 0);
    const totalCredit = draftLines.reduce((s, l) => s + l.credit, 0);
    document.getElementById('jr-total-debit').textContent = totalDebit.toFixed(2);
    document.getElementById('jr-total-credit').textContent = totalCredit.toFixed(2);
  }

  async function onSaveEntry() {
    if (document.getElementById('jr-entry-form').style.display === 'none') { Utils.toast('اضغط زر الإضافة أولاً', 'info'); return; }
    if (draftLines.length < 2) { Utils.toast('يجب إضافة سطرين على الأقل', 'error'); return; }
    const totalDebit = draftLines.reduce((s, l) => s + l.debit, 0);
    const totalCredit = draftLines.reduce((s, l) => s + l.credit, 0);
    if (Math.abs(totalDebit - totalCredit) > 0.009) {
      Utils.toast('يجب أن يتساوى إجمالي المدين مع إجمالي الدائن قبل الحفظ', 'error');
      return;
    }

    const sheet = document.getElementById('jr-no');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    const entry = {
      entryNo: document.getElementById('jr-no').value.trim(),
      date: document.getElementById('jr-date').value,
      lines: draftLines.map(({ _id, ...rest }) => rest)
    };
    if (editId) entry.id = editId;

    await FarisDB.put(STORES.JOURNAL, entry);
    Utils.toast('تم حفظ القيد بنجاح', 'success');

    draftLines = [];
    drawDraftRows();
    document.getElementById('jr-no').dataset.editId = '';
    document.getElementById('jr-no').value = await nextEntryNo();
    document.getElementById('jr-date').value = new Date().toISOString().slice(0, 10);
    showEntryForm(false);
    await loadSavedRows();
  }

  async function loadSavedRows() {
    let items = await FarisDB.getAll(STORES.JOURNAL);
    const search = document.getElementById('jr-search').value.trim();
    const col = document.getElementById('jr-search-col').value;

    if (search) {
      items = items.filter(it => {
        const haystack = col
          ? (col === 'رقم القيد' ? it.entryNo : col === 'التاريخ' ? it.date
            : it.lines.map(l => ({ 'اسم الحساب': l.accountName, 'اسم الحساب التحليلي': l.analyticName, 'البيان': l.statement, 'رمز العملة': currencySymbol(l.currencyId) }[col] || '')).join(' '))
          : JSON.stringify(it);
        return String(haystack).includes(search);
      });
    }

    const rows = document.getElementById('jr-saved-rows');
    rows.innerHTML = items.map(it => `
      <tr data-id="${it.id}">
        <td>${Utils.escapeHtml(it.entryNo)}</td><td>${Utils.escapeHtml(it.date)}</td>
        <td>${it.lines.length}</td>
        <td>${it.lines.reduce((s, l) => s + l.debit, 0).toFixed(2)}</td>
        <td>${it.lines.reduce((s, l) => s + l.credit, 0).toFixed(2)}</td>
      </tr>`).join('') || '<tr><td colspan="5" class="empty-row">لا توجد قيود محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#jr-saved-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('jr-edit').disabled = false;
    document.getElementById('jr-del').disabled = false;
  }

  async function loadEntryToDraft(id) {
    if (!id) return;
    const entry = await FarisDB.get(STORES.JOURNAL, id);
    draftLines = entry.lines.map(l => ({ _id: ++lineCounter, ...l }));
    document.getElementById('jr-no').value = entry.entryNo;
    document.getElementById('jr-no').dataset.editId = id;
    document.getElementById('jr-date').value = entry.date;
    drawDraftRows();
    showEntryForm(true);
    Utils.toast('عدّل الأسطر ثم اضغط حفظ القيد', 'info');
  }

  async function onDeleteEntry() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف هذا القيد؟');
    if (!ok) return;
    await FarisDB.remove(STORES.JOURNAL, selectedId);
    selectedId = null;
    document.getElementById('jr-edit').disabled = true;
    document.getElementById('jr-del').disabled = true;
    await loadSavedRows();
    Utils.toast('تم الحذف', 'success');
  }

  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('jr-import-status');
    if (typeof XLSX === 'undefined') {
      statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل، تأكد من الاتصال بالإنترنت.';
      return;
    }
    statusEl.textContent = 'جاري القراءة...';
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }).slice(1);

      const currencies = await FarisDB.getAll(STORES.CURRENCIES);
      const grouped = {};

      for (const row of rows) {
        const [entryNo, date, analyticCodeVal, statement, currencySymbolVal, debit, credit, refNo] = row.map(v => String(v ?? '').trim());
        const resolved = await AccountAnalyticPicker.resolveByAnalyticCode(analyticCodeVal);
        const currency = currencies.find(c => c.symbol === currencySymbolVal || c.name === currencySymbolVal);
        if (!resolved || !currency) continue;

        const key = `${entryNo}||${date}`;
        if (!grouped[key]) grouped[key] = { entryNo: entryNo || '', date: Utils.normalizeImportDate(date) || new Date().toISOString().slice(0, 10), lines: [] };
        grouped[key].lines.push({
          accountCode: resolved.accountCode, accountName: resolved.accountName,
          analyticCode: resolved.analyticCode, analyticName: resolved.analyticName,
          currencyId: currency.id, statement, debit: Number(debit) || 0, credit: Number(credit) || 0, refNo
        });
      }

      let added = 0, skippedUnbalanced = 0;
      for (const key in grouped) {
        const entry = grouped[key];
        const totalDebit = entry.lines.reduce((s, l) => s + l.debit, 0);
        const totalCredit = entry.lines.reduce((s, l) => s + l.credit, 0);
        if (entry.lines.length < 2 || Math.abs(totalDebit - totalCredit) > 0.009) { skippedUnbalanced++; continue; }
        if (!entry.entryNo) entry.entryNo = await nextEntryNo();
        await FarisDB.put(STORES.JOURNAL, entry);
        added++;
      }

      statusEl.textContent = `تم استيراد ${added} قيد، وتخطي ${skippedUnbalanced} قيد غير متوازن أو ناقص.`;
      await loadSavedRows();
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف.';
    }
    e.target.value = '';
  }

  async function onPrint() {
    const items = await FarisDB.getAll(STORES.JOURNAL);
    const headers = ['رقم القيد', 'التاريخ', 'اسم الحساب', 'الحساب التحليلي', 'البيان', 'العملة', 'مدين', 'دائن'];
    const rows = [];
    items.forEach(it => it.lines.forEach(l => {
      rows.push([it.entryNo, it.date, l.accountName, l.analyticName, l.statement, currencySymbol(l.currencyId), l.debit, l.credit]);
    }));
    Utils.printTable('القيود اليومية', headers, rows);
  }

  return { render };
})();
