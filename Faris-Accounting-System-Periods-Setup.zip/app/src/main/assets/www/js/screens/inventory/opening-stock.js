/* =========================================================
   المخزون الافتتاحي
   شاشة موحّدة على نمط الفواتير: هيدر + جدول أصناف جاهز الصفوف
   (لا يحتاج زر إضافة سطر) + قيد تلقائي عند الحفظ
   ========================================================= */

const InvOpeningStock = (function () {
  let mode = 'add'; // add | search
  let draftRows = [];   // كل عنصر: { rid, itemCode, itemName, unitId, qty, cost }
  let rowCounter = 0;
  let editId = null;
  let currentJournalId = null;
  let selectedDocId = null;

  let itemsCache = [];
  let unitsFlat = [];
  let warehousesCache = [];
  let currenciesCache = [];
  let mainGroupsCache = [];

  const MIN_ROWS = 5;

  function currencyById(id) { return currenciesCache.find(c => c.id === id); }
  function unitById(id) { return unitsFlat.find(u => u.id === id); }
  function convertAmount(amount, fromCurrency, toCurrency) {
    if (!fromCurrency || !toCurrency || fromCurrency.id === toCurrency.id) return amount;
    const local = fromCurrency.type === 'محلي' ? amount : amount * fromCurrency.rate;
    return toCurrency.type === 'محلي' ? local : local / toCurrency.rate;
  }
  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

  async function render(container) {
    mode = 'add';
    draftRows = [];
    rowCounter = 0;
    editId = null;
    selectedDocId = null;

    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);

    container.innerHTML = `
      <div class="toolbar icon-only" id="os-toolbar">
        <button class="btn btn-icon" id="os-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="os-save" title="حفظ">💾</button>
        <button class="btn btn-icon" id="os-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="os-edit" title="تعديل" disabled>✏️</button>
        <button class="btn btn-icon" id="os-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="os-journal" title="عرض القيد" disabled>📋</button>
        <button class="btn btn-icon hidden" id="os-import" title="استيراد إكسل">📥</button>
        <button class="btn btn-icon" id="os-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="os-undo" title="تراجع من الإضافة">↩️</button>
        <button class="btn btn-icon" id="os-exit" title="خروج من الشاشة">❎</button>
      </div>

      <div id="os-add-view"></div>
      <div id="os-search-view" class="hidden"></div>

      <div class="popup-sheet" id="os-journal-popup">
        <div class="popup-header"><span>القيد المحاسبي التلقائي</span><button class="btn-close" id="os-journal-close">✖️</button></div>
        <div id="os-journal-content"></div>
      </div>

      <div class="popup-sheet" id="os-newitem-popup">
        <div class="popup-header"><span>إضافة صنف جديد</span><button class="btn-close" id="os-newitem-close">✖️</button></div>
        <div class="form-grid">
          <label class="required"><input type="text" id="os-ni-code" placeholder="رقم الصنف"></label>
          <label class="required"><input type="text" id="os-ni-name" placeholder="اسم الصنف"></label>
          <label class="required"><select id="os-ni-main-group"><option value="" disabled selected hidden>المجموعة الرئيسية</option></select></label>
          <label class="required"><select id="os-ni-unit"><option value="" disabled selected hidden>الوحدة الأساسية</option></select></label>
        </div>
        <button type="button" class="btn btn-primary full" id="os-ni-save">💾 حفظ الصنف</button>
      </div>

      <div class="popup-sheet" id="os-line-menu-popup">
        <div class="popup-header"><span id="os-line-menu-title">خيارات الصف</span><button class="btn-close" id="os-line-menu-close">✖️</button></div>
        <div class="sheet-actions" style="flex-direction:column; gap:8px;">
          <button type="button" class="btn btn-ghost full" id="os-line-menu-newitem">➕ إضافة صنف جديد</button>
          <button type="button" class="btn btn-danger full" id="os-line-menu-delete">🗑️ حذف الصف</button>
        </div>
      </div>

      <div class="popup-sheet" id="os-import-popup">
        <div class="popup-header"><span>استيراد المخزون الافتتاحي من إكسل</span><button class="btn-close" id="os-import-close">✖️</button></div>
        <p class="hint">يبدأ الاستيراد من الصف الثاني، ويُضاف كأسطر جديدة في المستند الحالي. رقم الصنف يجب أن يكون مضافًا مسبقًا في شاشة بيانات الأصناف (يُصحَّح اسم الصنف تلقائيًا من قاعدة البيانات). ترتيب الأعمدة:<br>
          <b>A) رقم الصنف &nbsp;B) اسم الصنف (يُتجاهل ويُصحَّح تلقائيًا) &nbsp;C) الوحدة (بالاسم) &nbsp;D) المخزن (بالاسم، للتأكيد فقط) &nbsp;E) الكمية &nbsp;F) تكلفة الوحدة &nbsp;G) التكلفة (تُحسب تلقائيًا)</b></p>
        <input type="file" id="os-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="os-import-status"></p>
      </div>
    `;

    bindToolbar(container);
    renderAddView();
    setToolbarState('add-empty');
    document.getElementById('os-no').value = await nextDocNo();
  }

  function bindToolbar(container) {
    container.querySelector('#os-add').addEventListener('click', onAddNew);
    container.querySelector('#os-save').addEventListener('click', onSaveDoc);
    container.querySelector('#os-search').addEventListener('click', onToggleSearch);
    container.querySelector('#os-edit').addEventListener('click', onEditSelected);
    container.querySelector('#os-print').addEventListener('click', onPrintSelected);
    container.querySelector('#os-journal').addEventListener('click', onViewJournal);
    container.querySelector('#os-journal-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('os-journal-popup')));
    container.querySelector('#os-del').addEventListener('click', onDelete);
    container.querySelector('#os-undo').addEventListener('click', onUndo);
    container.querySelector('#os-exit').addEventListener('click', () => App.show('inventory', { replace: true }));

    container.querySelector('#os-import').addEventListener('click', () => {
      document.getElementById('os-import-status').textContent = '';
      document.getElementById('os-import-file').value = '';
      Utils.openSheet(document.getElementById('os-import-popup'));
    });
    container.querySelector('#os-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('os-import-popup')));
    container.querySelector('#os-import-file').addEventListener('change', onImportExcel);

    container.querySelector('#os-newitem-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('os-newitem-popup')));
    container.querySelector('#os-ni-save').addEventListener('click', onSaveNewItem);

    container.querySelector('#os-line-menu-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('os-line-menu-popup')));
    container.querySelector('#os-line-menu-newitem').addEventListener('click', () => { Utils.closeSheet(document.getElementById('os-line-menu-popup')); openNewItemPopup(); });
    container.querySelector('#os-line-menu-delete').addEventListener('click', onLineMenuDelete);
  }

  function setToolbarState(state) {
    const dis = (id, v) => { document.getElementById(id).disabled = v; };
    const importBtn = document.getElementById('os-import');
    if (state === 'add-empty') { dis('os-edit', true); dis('os-print', true); dis('os-journal', true); dis('os-del', true); importBtn.classList.remove('hidden'); }
    else if (state === 'add-saved') { dis('os-edit', false); dis('os-print', false); dis('os-journal', false); dis('os-del', false); importBtn.classList.add('hidden'); }
    else if (state === 'search-none') { dis('os-edit', true); dis('os-print', true); dis('os-journal', true); dis('os-del', true); importBtn.classList.add('hidden'); }
    else if (state === 'search-selected') { dis('os-edit', false); dis('os-print', false); dis('os-journal', false); dis('os-del', false); importBtn.classList.add('hidden'); }
  }

  /* -------------------- شاشة الإضافة -------------------- */
  function renderAddView() {
    const el = document.getElementById('os-add-view');
    el.classList.remove('hidden');
    document.getElementById('os-search-view').classList.add('hidden');

    el.innerHTML = `
      <div class="form-grid">
        <label class="optional"><input type="text" id="os-no" placeholder="الرقم" readonly></label>
        <label class="required"><input type="date" id="os-date" aria-label="التاريخ" required></label>
        <label class="required"><select id="os-warehouse" required><option value="" disabled selected hidden>المخزون</option></select></label>
        <label class="required"><select id="os-currency"></select></label>
        <label class="optional"><input type="text" id="os-exchange-rate" placeholder="سعر الصرف" readonly></label>
        <label class="optional"><input type="text" id="os-local-amount" placeholder="المبلغ المحلي" readonly></label>
        <label class="optional"><input type="text" id="os-reference" placeholder="المرجع"></label>
        <label class="optional"><input type="text" id="os-statement" placeholder="البيان"></label>
      </div>

      <div class="table-scroll" id="os-items-scroll" style="max-height:270px; overflow-y:auto; overflow-x:auto;">
        <table class="data-table" id="os-items-table" style="table-layout:auto; width:auto; min-width:100%;">
          <thead><tr>
            <th></th><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>رمز المخزون</th><th>الكمية</th><th>التكلفة</th><th>إجمالي التكلفة</th>
          </tr></thead>
          <tbody id="os-rows"></tbody>
        </table>
      </div>

      <table class="data-table" style="margin-top:8px;">
        <tbody>
          <tr><td><b>إجمالي الكمية</b></td><td id="os-total-qty">0</td>
              <td><b>إجمالي التكلفة</b></td><td id="os-total-cost"><b>0.00</b></td></tr>
        </tbody>
      </table>
    `;

    document.getElementById('os-warehouse').innerHTML = '<option value="" disabled selected hidden>المخزون</option>' + warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');
    document.getElementById('os-currency').innerHTML = '<option value="" disabled selected hidden>العملة</option>' + currenciesCache.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    document.getElementById('os-date').value = new Date().toISOString().slice(0, 10);
    if (warehousesCache.length) document.getElementById('os-currency').value = warehousesCache[0].currencyId;

    document.getElementById('os-warehouse').addEventListener('change', () => {
      const wh = warehousesCache.find(w => w.id === Number(document.getElementById('os-warehouse').value));
      if (wh) document.getElementById('os-currency').value = wh.currencyId;
      updateWarehouseCodeOnRows();
      updateExchangeAndLocalAmount();
    });
    document.getElementById('os-currency').addEventListener('change', updateExchangeAndLocalAmount);

    draftRows = [];
    for (let i = 0; i < MIN_ROWS; i++) draftRows.push(blankRow());
    drawRows();
    updateExchangeAndLocalAmount();
  }

  function blankRow() { return { rid: ++rowCounter, itemCode: '', itemName: '', unitId: null, qty: '', cost: '' }; }

  function warehouseCode() {
    const wh = warehousesCache.find(w => w.id === Number(document.getElementById('os-warehouse').value));
    return wh ? (wh.code || wh.name) : '';
  }

  function updateWarehouseCodeOnRows() {
    document.querySelectorAll('#os-rows tr[data-rid] .os-wh-code').forEach(td => { td.textContent = warehouseCode(); });
  }

  function updateExchangeAndLocalAmount() {
    const currency = currencyById(Number(document.getElementById('os-currency').value));
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');
    const rateField = document.getElementById('os-exchange-rate');
    const amountField = document.getElementById('os-local-amount');
    if (!currency || !localCurrency) { rateField.value = ''; amountField.value = ''; return; }
    rateField.value = currency.type === 'محلي' ? '1' : currency.rate;
    const totalCost = draftRows.reduce((s, r) => s + ((Number(r.qty) || 0) * (Number(r.cost) || 0)), 0);
    amountField.value = convertAmount(totalCost, currency, localCurrency).toFixed(2);
  }

  /* -------------------- جدول الأصناف (صفوف جاهزة قابلة للتوسع) -------------------- */
  function drawRows() {
    const tbody = document.getElementById('os-rows');
    tbody.innerHTML = '';
    draftRows.forEach(row => tbody.appendChild(buildRowEl(row)));
    recomputeTotals();
  }

  function buildRowEl(row) {
    const unitOptions = (code => {
      const item = itemsCache.find(i => i.code === code);
      return (item ? item.units : []).map(u => {
        const unit = unitById(u.unitId);
        return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
      }).join('');
    })(row.itemCode);

    const tr = Utils.el(`
      <tr data-rid="${row.rid}">
        <td><button type="button" class="btn-close" data-menu="${row.rid}">⋮</button></td>
        <td>
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input os-item-input" autocomplete="off" value="${row.itemCode ? Utils.escapeHtml(row.itemCode + ' - ' + row.itemName) : ''}">
            <div class="autocomplete-list os-item-list"></div>
          </div>
        </td>
        <td class="os-name-preview">${Utils.escapeHtml(row.itemName || '')}</td>
        <td><select class="table-input os-unit">${unitOptions}</select></td>
        <td class="os-wh-code">${Utils.escapeHtml(warehouseCode())}</td>
        <td><input type="number" step="0.01" class="table-input os-qty" value="${row.qty}"></td>
        <td><input type="number" step="0.01" class="table-input os-cost" value="${row.cost}"></td>
        <td class="os-total-preview">0.00</td>
      </tr>
    `);

    const itemInput = tr.querySelector('.os-item-input');
    const itemList = tr.querySelector('.os-item-list');
    Utils.attachAutocomplete(itemInput, itemList, (query) => {
      const list = itemsCache.map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: `${it.code} - ${it.name}` }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      itemInput.value = item.displayValue;
      onRowItemChosen(row.rid, item.value);
    });

    tr.querySelector('.os-unit').addEventListener('change', (e) => { row.unitId = Number(e.target.value) || null; recomputeTotals(); });
    tr.querySelector('.os-qty').addEventListener('input', (e) => { row.qty = e.target.value; updateRowTotalPreview(tr, row); recomputeTotals(); });
    tr.querySelector('.os-cost').addEventListener('input', (e) => { row.cost = e.target.value; updateRowTotalPreview(tr, row); recomputeTotals(); });
    tr.querySelector('[data-menu]').addEventListener('click', () => openLineMenu(row.rid));

    updateRowTotalPreview(tr, row);
    return tr;
  }

  function updateRowTotalPreview(tr, row) {
    const qty = Number(row.qty) || 0;
    const cost = Number(row.cost) || 0;
    tr.querySelector('.os-total-preview').textContent = (qty * cost).toFixed(2);
  }

  function onRowItemChosen(rid, code) {
    const row = draftRows.find(r => r.rid === rid);
    if (!row) return;
    const item = itemsCache.find(i => i.code === code);
    row.itemCode = code;
    row.itemName = item ? item.name : '';
    row.unitId = item && item.units.length ? (item.units.find(u => u.isBase) || item.units[0]).unitId : null;

    const tr = document.querySelector(`#os-rows tr[data-rid="${rid}"]`);
    tr.querySelector('.os-name-preview').textContent = row.itemName;
    const unitSelect = tr.querySelector('.os-unit');
    unitSelect.innerHTML = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
    if (row.unitId) unitSelect.value = row.unitId;

    ensureTrailingBlankRow();
  }

  // يضمن وجود صف فارغ واحد دائمًا في نهاية الجدول للاستمرار بالإدخال دون زر إضافة
  function ensureTrailingBlankRow() {
    const last = draftRows[draftRows.length - 1];
    if (last && last.itemCode) {
      const row = blankRow();
      draftRows.push(row);
      document.getElementById('os-rows').appendChild(buildRowEl(row));
    }
  }

  function recomputeTotals() {
    const filled = draftRows.filter(r => r.itemCode && Number(r.qty) > 0);
    const totalQty = filled.reduce((s, r) => s + Number(r.qty), 0);
    const totalCost = filled.reduce((s, r) => s + (Number(r.qty) * Number(r.cost || 0)), 0);
    document.getElementById('os-total-qty').textContent = totalQty;
    document.getElementById('os-total-cost').innerHTML = `<b>${totalCost.toFixed(2)}</b>`;
    updateExchangeAndLocalAmount();
  }

  /* -------------------- قائمة خيارات الصف -------------------- */
  let activeMenuRid = null;
  function openLineMenu(rid) {
    activeMenuRid = rid;
    const row = draftRows.find(r => r.rid === rid);
    document.getElementById('os-line-menu-title').textContent = row && row.itemName ? `صنف: ${row.itemName}` : 'خيارات الصف';
    Utils.openSheet(document.getElementById('os-line-menu-popup'));
  }
  function onLineMenuDelete() {
    draftRows = draftRows.filter(r => r.rid !== activeMenuRid);
    if (!draftRows.length || draftRows.every(r => r.itemCode)) draftRows.push(blankRow());
    Utils.closeSheet(document.getElementById('os-line-menu-popup'));
    drawRows();
  }

  /* -------------------- إضافة صنف جديد سريعًا -------------------- */
  function openNewItemPopup() {
    document.getElementById('os-ni-code').value = '';
    document.getElementById('os-ni-name').value = '';
    document.getElementById('os-ni-main-group').innerHTML = '<option value="" disabled selected hidden>المجموعة الرئيسية</option>' +
      mainGroupsCache.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    document.getElementById('os-ni-unit').innerHTML = '<option value="" disabled selected hidden>الوحدة الأساسية</option>' +
      unitsFlat.map(u => `<option value="${u.id}">${Utils.escapeHtml(u.name)}</option>`).join('');
    Utils.openSheet(document.getElementById('os-newitem-popup'));
  }

  async function onSaveNewItem() {
    const code = document.getElementById('os-ni-code').value.trim();
    const name = document.getElementById('os-ni-name').value.trim();
    const mainGroupId = Number(document.getElementById('os-ni-main-group').value) || null;
    const unitId = Number(document.getElementById('os-ni-unit').value) || null;
    if (!code || !name || !mainGroupId || !unitId) { Utils.toast('أكمل كل الحقول', 'error'); return; }
    if (itemsCache.some(i => i.code === code)) { Utils.toast('رقم الصنف مستخدم مسبقًا', 'error'); return; }

    const value = { code, name, mainGroupId, subGroupId: null, detailGroupId: null, units: [{ unitId, package: 1, level: 'أصغر وحدة', linkFactor: 1, isBase: true, isSellUnit: true, isPurchaseUnit: true }] };
    await FarisDB.put(STORES.INV_ITEMS, value);
    itemsCache.push(value);
    Utils.toast('تمت إضافة الصنف', 'success');
    Utils.closeSheet(document.getElementById('os-newitem-popup'));

    if (activeMenuRid) onRowItemChosen(activeMenuRid, code);
    const tr = document.querySelector(`#os-rows tr[data-rid="${activeMenuRid}"]`);
    if (tr) tr.querySelector('.os-item-input').value = `${code} - ${name}`;
  }

  /* -------------------- الترقيم -------------------- */
  async function nextDocNo() {
    const docs = await FarisDB.getAll(STORES.INV_OPENING_STOCK_DOCS);
    return String((docs.length ? Math.max(...docs.map(d => Number(d.id) || 0)) : 0) + 1);
  }

  async function onAddNew() {
    mode = 'add';
    editId = null;
    currentJournalId = null;
    renderAddView();
    document.getElementById('os-no').value = await nextDocNo();
    setToolbarState('add-empty');
  }

  function onUndo() {
    editId = null;
    currentJournalId = null;
    renderAddView();
    setToolbarState('add-empty');
  }

  /* -------------------- توليد القيد التلقائي -------------------- */
  async function buildJournalLines(doc) {
    const warehouse = warehousesCache.find(w => w.id === doc.warehouseId);
    if (!warehouse) return { error: 'تعذر تحديد المخزن' };

    const mapping = await FarisDB.get(STORES.INV_GL_MAPPING, warehouse.groupId);
    const allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const resolveAccount = (acc) => {
      if (!acc) return acc;
      const found = allAccounts.find(a => a.code === acc.code);
      return found ? { code: acc.code, name: found.name } : acc;
    };
    const missing = [];
    if (!mapping || !mapping.inventoryAccount) missing.push('حساب المخزون');
    if (!mapping || !mapping.openingStockAccount) missing.push('حساب الرصيد الافتتاحي للمخزون');
    if (missing.length) {
      return { error: `تعذر إنشاء القيد، الحسابات التالية غير مربوطة في "ربط المخزون بالأستاذ العام" لمجموعة مخازن (${warehouse.name}): ${missing.join('، ')}` };
    }

    const warehouseCurrency = currencyById(warehouse.currencyId);
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');
    const whRate = warehouseCurrency.type === 'محلي' ? 1 : warehouseCurrency.rate;
    const totalCost = doc.lines.reduce((s, l) => s + (l.qty * l.cost), 0);

    const mk = (account, currency, rate, statement, debit, credit) => ({
      accountCode: account.code, accountName: account.name,
      analyticCode: account.code, analyticName: account.name,
      currencyId: currency.id, currencySymbol: currency.symbol, exchangeRate: rate,
      statement,
      debit: round2(debit), credit: round2(credit),
      debitLocal: round2(convertAmount(debit, currency, localCurrency)),
      creditLocal: round2(convertAmount(credit, currency, localCurrency))
    });

    const lines = [
      mk(resolveAccount(mapping.inventoryAccount), warehouseCurrency, whRate, 'المخزون الافتتاحي', totalCost, 0),
      mk(resolveAccount(mapping.openingStockAccount), warehouseCurrency, whRate, 'رصيد افتتاحي للمخزون', 0, totalCost)
    ];
    return { lines };
  }

  async function onSaveDoc() {
    const warehouseId = Number(document.getElementById('os-warehouse').value);
    if (!warehouseId) { Utils.toast('اختر المخزون', 'error'); return; }
    const currencyId = Number(document.getElementById('os-currency').value);
    if (!currencyId) { Utils.toast('اختر العملة', 'error'); return; }
    const date = document.getElementById('os-date').value;
    if (!date) { Utils.toast('أدخل التاريخ', 'error'); return; }

    const filledRows = draftRows.filter(r => r.itemCode && Number(r.qty) > 0);
    if (!filledRows.length) { Utils.toast('أضف صنفًا واحدًا على الأقل بكمية صحيحة', 'error'); return; }
    const invalidCost = filledRows.some(r => !(Number(r.cost) >= 0) || r.cost === '');
    if (invalidCost) { Utils.toast('أدخل تكلفة صحيحة لكل الأصناف المدخلة', 'error'); return; }
    const missingUnit = filledRows.some(r => !r.unitId);
    if (missingUnit) { Utils.toast('اختر وحدة قياس لكل الأصناف المدخلة', 'error'); return; }

    const whCode = warehouseCode();
    const doc = {
      date, warehouseId, currencyId,
      reference: document.getElementById('os-reference').value.trim(),
      statement: document.getElementById('os-statement').value.trim(),
      lines: filledRows.map(r => ({ itemCode: r.itemCode, itemName: r.itemName, unitId: r.unitId, unitName: unitById(r.unitId) ? unitById(r.unitId).name : '', warehouseCode: whCode, qty: Number(r.qty), cost: Number(r.cost) }))
    };
    if (editId) doc.id = editId;
    if (currentJournalId) doc.journalId = currentJournalId;

    const journalResult = await buildJournalLines(doc);
    if (journalResult.error) { Utils.toast(journalResult.error, 'error'); return; }
    doc.journalLines = journalResult.lines;

    // عند التعديل: نحذف السجلات المسطّحة والقيد القديمين قبل إعادة إنشائهما
    if (editId) {
      const oldFlat = await FarisDB.getAll(STORES.INV_OPENING_STOCK);
      for (const rec of oldFlat.filter(r => r.docId === editId)) {
        await FarisDB.remove(STORES.INV_OPENING_STOCK, rec.id);
      }
    }

    const savedId = await FarisDB.put(STORES.INV_OPENING_STOCK_DOCS, doc);

    for (const line of doc.lines) {
      await FarisDB.put(STORES.INV_OPENING_STOCK, {
        docId: savedId, itemCode: line.itemCode, warehouseId: doc.warehouseId,
        unitId: line.unitId, quantity: line.qty, unitCost: line.cost
      });
    }

    const journalPayload = { date: doc.date, lines: journalResult.lines.map(l => ({ ...l, refNo: String(savedId) })) };
    if (currentJournalId) {
      // تعديل رصيد افتتاحي موجود: نحدّث نفس القيد بدل إنشاء قيد جديد يسبب تكرارًا
      const existingEntry = await FarisDB.get(STORES.JOURNAL, currentJournalId);
      journalPayload.id = currentJournalId;
      journalPayload.entryNo = existingEntry ? existingEntry.entryNo : String(currentJournalId);
      await FarisDB.put(STORES.JOURNAL, journalPayload);
    } else {
      const journalEntries = await FarisDB.getAll(STORES.JOURNAL);
      const entryNo = journalEntries.length ? Math.max(...journalEntries.map(j => Number(j.entryNo) || 0)) + 1 : 1;
      journalPayload.entryNo = String(entryNo);
      currentJournalId = await FarisDB.put(STORES.JOURNAL, journalPayload);
      await FarisDB.put(STORES.INV_OPENING_STOCK_DOCS, { ...doc, id: savedId, journalId: currentJournalId });
    }

    Utils.toast('تم حفظ الرصيد الافتتاحي وترحيل قيده المحاسبي بنجاح', 'success');
    editId = savedId;
    setToolbarState('add-saved');
  }

  /* -------------------- البحث / القائمة المحفوظة -------------------- */
  async function onToggleSearch() {
    mode = mode === 'search' ? 'add' : 'search';
    if (mode === 'search') {
      document.getElementById('os-add-view').classList.add('hidden');
      const el = document.getElementById('os-search-view');
      el.classList.remove('hidden');
      await renderSearchView(el);
    } else {
      document.getElementById('os-search-view').classList.add('hidden');
      document.getElementById('os-add-view').classList.remove('hidden');
      setToolbarState('add-empty');
    }
  }

  async function renderSearchView(el) {
    el.innerHTML = `
      <div class="toolbar search-row">
        <input type="text" id="os-list-search" placeholder="🔍 بحث...">
      </div>
      <div class="table-scroll" style="overflow-x:auto;">
        <table class="data-table">
          <thead><tr><th>الرقم</th><th>التاريخ</th><th>المخزون</th><th>المبلغ المحلي</th><th>العملة</th><th>رقم المرجع</th><th>البيان</th></tr></thead>
          <tbody id="os-list-rows"></tbody>
        </table>
      </div>
    `;
    el.querySelector('#os-list-search').addEventListener('input', loadListRows);
    await loadListRows();
    setToolbarState('search-none');
  }

  async function loadListRows() {
    let docs = await FarisDB.getAll(STORES.INV_OPENING_STOCK_DOCS);
    const search = document.getElementById('os-list-search').value.trim();
    const whMap = Object.fromEntries(warehousesCache.map(w => [w.id, w.name]));
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');

    if (search) {
      docs = docs.filter(d => {
        const haystack = [d.id, d.date, whMap[d.warehouseId], d.reference, d.statement].join(' ');
        return haystack.includes(search);
      });
    }

    const rows = document.getElementById('os-list-rows');
    rows.innerHTML = docs.map(d => {
      const currency = currencyById(d.currencyId);
      const totalCost = d.lines.reduce((s, l) => s + (l.qty * l.cost), 0);
      const localAmount = currency && localCurrency ? convertAmount(totalCost, currency, localCurrency) : totalCost;
      return `<tr data-id="${d.id}">
        <td>${d.id}</td><td>${Utils.escapeHtml(d.date)}</td><td>${Utils.escapeHtml(whMap[d.warehouseId] || '')}</td>
        <td>${localAmount.toFixed(2)}</td><td>${currency ? Utils.escapeHtml(currency.symbol) : ''}</td>
        <td>${Utils.escapeHtml(d.reference || '')}</td><td>${Utils.escapeHtml(d.statement || '')}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="7" class="empty-row">لا توجد أرصدة افتتاحية محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectDocRow(Number(tr.dataset.id), tr));
    });
  }

  function selectDocRow(id, tr) {
    selectedDocId = id;
    document.querySelectorAll('#os-list-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    setToolbarState('search-selected');
  }

  async function loadDocIntoAddFields(id) {
    const doc = await FarisDB.get(STORES.INV_OPENING_STOCK_DOCS, id);
    document.getElementById('os-add-view').classList.remove('hidden');
    document.getElementById('os-search-view').classList.add('hidden');
    renderAddView();

    document.getElementById('os-no').value = doc.id;
    document.getElementById('os-date').value = doc.date;
    document.getElementById('os-warehouse').value = doc.warehouseId;
    document.getElementById('os-currency').value = doc.currencyId;
    document.getElementById('os-reference').value = doc.reference || '';
    document.getElementById('os-statement').value = doc.statement || '';

    draftRows = doc.lines.map(l => ({ rid: ++rowCounter, itemCode: l.itemCode, itemName: l.itemName, unitId: l.unitId, qty: l.qty, cost: l.cost }));
    draftRows.push(blankRow());
    drawRows();

    editId = doc.id;
    currentJournalId = doc.journalId || null;
    setToolbarState('add-saved');
    mode = 'add';
  }

  // يتحقق أن تعديل/حذف الرصيد الافتتاحي آمن زمنيًا: لا حركة منصرفة لاحقة اعتمدت على توفر هذه الكمية
  async function findLockingMovement(doc) {
    for (let idx = 0; idx < (doc.lines || []).length; idx++) {
      const l = doc.lines[idx];
      const key = `opening-stock-doc-${doc.id}-${idx}`;
      const blocker = await ItemMovementEngine.findBlockingLaterMovement(l.itemCode, doc.warehouseId, doc.date, true, key);
      if (blocker) return { itemName: l.itemName, blocker };
    }
    return null;
  }

  async function onEditSelected() {
    if (!selectedDocId) return;
    const doc = await FarisDB.get(STORES.INV_OPENING_STOCK_DOCS, selectedDocId);
    const locked = await findLockingMovement(doc);
    if (locked) {
      Utils.toast(`لا يمكن تعديل الرصيد الافتتاحي: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    await loadDocIntoAddFields(selectedDocId);
  }

  async function onDelete() {
    const id = editId || selectedDocId;
    if (!id) return;
    const doc = await FarisDB.get(STORES.INV_OPENING_STOCK_DOCS, id);
    const locked = await findLockingMovement(doc);
    if (locked) {
      Utils.toast(`لا يمكن حذف الرصيد الافتتاحي: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذا الرصيد الافتتاحي؟ (لا يمكن التراجع)');
    if (!ok) return;

    const flat = await FarisDB.getAll(STORES.INV_OPENING_STOCK);
    for (const rec of flat.filter(r => r.docId === id)) {
      await FarisDB.remove(STORES.INV_OPENING_STOCK, rec.id);
    }
    if (doc && doc.journalId) {
      await FarisDB.remove(STORES.JOURNAL, doc.journalId);
    }
    await FarisDB.remove(STORES.INV_OPENING_STOCK_DOCS, id);

    Utils.toast('تم حذف الرصيد الافتتاحي', 'success');
    if (mode === 'search') { selectedDocId = null; await loadListRows(); }
    else onAddNew();
  }

  async function onViewJournal() {
    const id = editId || selectedDocId;
    if (!id) return;
    const doc = await FarisDB.get(STORES.INV_OPENING_STOCK_DOCS, id);
    const lines = doc.journalLines || [];
    const rows = lines.map(l => `
      <tr>
        <td>${Utils.escapeHtml(l.accountCode)}</td>
        <td>${Utils.escapeHtml(l.accountName)}</td>
        <td>${Utils.escapeHtml(l.currencySymbol || '')}</td>
        <td>${l.exchangeRate || ''}</td>
        <td>${Utils.escapeHtml(l.statement)}</td>
        <td>${l.debit || ''}</td>
        <td>${l.credit || ''}</td>
        <td>${l.debitLocal || ''}</td>
        <td>${l.creditLocal || ''}</td>
      </tr>`).join('') || '<tr><td colspan="9" class="empty-row">لا يوجد قيد محفوظ</td></tr>';

    document.getElementById('os-journal-content').innerHTML = `
      <div class="table-scroll" style="overflow-x:auto;">
        <table class="data-table" style="table-layout:auto; width:auto; min-width:100%;">
          <thead><tr>
            <th>رقم الحساب</th><th>اسم الحساب</th><th>رمز العملة</th><th>سعر الصرف</th><th>البيان</th>
            <th>مدين</th><th>دائن</th><th>مدين محلي</th><th>دائن محلي</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
    Utils.openSheet(document.getElementById('os-journal-popup'));
  }

  function onPrintSelected() {
    const id = editId || selectedDocId;
    if (!id) return;
    FarisDB.get(STORES.INV_OPENING_STOCK_DOCS, id).then(doc => {
      const currency = currencyById(doc.currencyId);
      const headers = ['م', 'رقم الصنف', 'اسم الصنف', 'الوحدة', 'رمز المخزون', 'الكمية', 'التكلفة', 'إجمالي التكلفة'];
      const rows = doc.lines.map((l, i) => [i + 1, l.itemCode, l.itemName, l.unitName, l.warehouseCode, l.qty, l.cost.toFixed(2), (l.qty * l.cost).toFixed(2)]);
      const totalCost = doc.lines.reduce((s, l) => s + (l.qty * l.cost), 0);
      const footerRow = ['', '', '', '', '', '', 'الإجمالي', `${totalCost.toFixed(2)} ${currency ? currency.symbol : ''}`];
      ReportPrint.print({
        title: `رصيد افتتاحي رقم ${doc.id}`,
        subtitle: `${doc.statement ? doc.statement + ' — ' : ''}التاريخ: ${doc.date}`,
        headers, rows, footerRow
      });
    });
  }

  /* -------------------- استيراد إكسل (يُضاف إلى المستند الحالي قبل الحفظ) -------------------- */
  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('os-import-status');
    if (typeof XLSX === 'undefined') {
      statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل، تأكد من الاتصال بالإنترنت.';
      return;
    }
    statusEl.textContent = 'جاري القراءة...';
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }).slice(1);
      let added = 0, skipped = 0;

      for (const row of rows) {
        const [itemCode, , unitName_, , qty, cost] = row.map(v => String(v ?? '').trim());
        if (!itemCode) continue;
        const item = itemsCache.find(i => i.code === itemCode);
        if (!item) { skipped++; continue; }
        const unitDef = item.units.find(u => (unitById(u.unitId) || {}).name === unitName_) || item.units.find(u => u.isBase) || item.units[0];
        if (!unitDef) { skipped++; continue; }

        // إزالة صف فارغ ختامي واحد قبل الإضافة إن وُجد
        if (draftRows.length && !draftRows[draftRows.length - 1].itemCode) draftRows.pop();
        draftRows.push({ rid: ++rowCounter, itemCode: item.code, itemName: item.name, unitId: unitDef.unitId, qty: Number(qty) || 0, cost: Number(cost) || 0 });
        added++;
      }
      draftRows.push(blankRow());
      drawRows();
      statusEl.textContent = `تم استيراد ${added} سطر، وتخطي ${skipped} (رقم الصنف غير موجود في بيانات الأصناف).`;
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف.';
    }
    e.target.value = '';
  }

  return { render };
})();
