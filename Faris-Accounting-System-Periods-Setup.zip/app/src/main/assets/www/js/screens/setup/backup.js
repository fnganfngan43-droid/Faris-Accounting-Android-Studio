/* =========================================================
   شاشة النسخ الاحتياطي - فرعية من التهيئة
   ========================================================= */

const SetupBackup = (function () {
  const SETTINGS_ID = 'main';

  function init() {}

  async function render(container) {
    const settings = (await FarisDB.get(STORES.BACKUP_SETTINGS, SETTINGS_ID)) || {
      id: SETTINGS_ID, autoBackup: false, driveEnabled: false, driveEmail: '', lastBackup: null
    };

    container.innerHTML = `
      <div class="form-page">
        <h3>النسخ الاحتياطي المحلي</h3>
        <p class="hint">يعمل بدون اتصال إنترنت. يتم حفظ نسخة كاملة من بيانات التطبيق كملف JSON على الجهاز.</p>
        <div class="row-actions">
          <button class="btn btn-primary" id="bk-export">⬇️ نسخ احتياطي الآن</button>
          <label class="btn btn-ghost file-btn">
            ⬆️ استعادة من ملف
            <input type="file" id="bk-import-file" accept="application/json" class="hidden-file">
          </label>
        </div>
        <p class="hint" id="bk-last">آخر نسخة احتياطية: ${settings.lastBackup ? new Date(settings.lastBackup).toLocaleString('ar') : 'لا يوجد'}</p>

        <label class="checkbox-row"><input type="checkbox" id="bk-auto" ${settings.autoBackup ? 'checked' : ''}> تفعيل نسخ تلقائي كل 12 ساعة (يُنفذ عند فتح التطبيق إذا مرّت المدة)</label>

        <h3>النسخ الاحتياطي على Google Drive</h3>
        <p class="hint">اختياري، يتطلب اتصال إنترنت. يعمل باقي التطبيق بدون إنترنت بشكل كامل حتى مع تفعيل هذا الخيار.</p>
        <label class="checkbox-row"><input type="checkbox" id="bk-drive" ${settings.driveEnabled ? 'checked' : ''}> تفعيل النسخ على Drive</label>
        <label>البريد الإلكتروني المرتبط<input type="email" id="bk-drive-email" value="${Utils.escapeHtml(settings.driveEmail || '')}" dir="ltr"></label>
        <button class="btn btn-secondary" id="bk-drive-now">⬆️ نسخ الآن على Drive</button>

        <button class="btn btn-primary full" id="bk-save-settings">حفظ إعدادات النسخ الاحتياطي</button>
      </div>
    `;

    container.querySelector('#bk-export').addEventListener('click', () => doLocalExport(true));
    container.querySelector('#bk-import-file').addEventListener('change', onImportFile);
    container.querySelector('#bk-save-settings').addEventListener('click', onSaveSettings);
    container.querySelector('#bk-drive-now').addEventListener('click', onDriveBackupNow);
  }

  function downloadJson(obj, filename) {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function doLocalExport(showToast) {
    const dump = await FarisDB.exportAll();
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    downloadJson(dump, `faris-backup-${stamp}.json`);

    const settings = (await FarisDB.get(STORES.BACKUP_SETTINGS, SETTINGS_ID)) || { id: SETTINGS_ID };
    settings.lastBackup = new Date().toISOString();
    await FarisDB.put(STORES.BACKUP_SETTINGS, settings);

    if (showToast) Utils.toast('تم إنشاء النسخة الاحتياطية بنجاح', 'success');
    const lastEl = document.getElementById('bk-last');
    if (lastEl) lastEl.textContent = `آخر نسخة احتياطية: ${new Date(settings.lastBackup).toLocaleString('ar')}`;
  }

  async function onImportFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const ok = await Utils.confirmDialog('سيتم استبدال جميع البيانات الحالية بمحتوى النسخة الاحتياطية. هل تريد المتابعة؟');
    if (!ok) { e.target.value = ''; return; }

    try {
      const text = await file.text();
      const dump = JSON.parse(text);
      await FarisDB.importAll(dump);
      Utils.toast('تمت الاستعادة بنجاح، يفضل إعادة فتح التطبيق', 'success');
    } catch (err) {
      Utils.toast('تعذّرت قراءة ملف النسخة الاحتياطية', 'error');
    }
    e.target.value = '';
  }

  async function onSaveSettings() {
    const settings = (await FarisDB.get(STORES.BACKUP_SETTINGS, SETTINGS_ID)) || { id: SETTINGS_ID };
    settings.autoBackup = document.getElementById('bk-auto').checked;
    settings.driveEnabled = document.getElementById('bk-drive').checked;
    settings.driveEmail = document.getElementById('bk-drive-email').value.trim();
    await FarisDB.put(STORES.BACKUP_SETTINGS, settings);
    Utils.toast('تم حفظ إعدادات النسخ الاحتياطي', 'success');
  }

  async function onDriveBackupNow() {
    const settings = (await FarisDB.get(STORES.BACKUP_SETTINGS, SETTINGS_ID)) || {};
    if (!settings.driveEnabled) {
      Utils.toast('فعّل خيار النسخ على Drive أولًا واحفظ الإعدادات', 'error');
      return;
    }
    if (!navigator.onLine) {
      Utils.toast('لا يوجد اتصال إنترنت، لا يمكن النسخ على Drive الآن', 'error');
      return;
    }
    // ملاحظة: رفع فعلي إلى Google Drive يتطلب ربط Google API/OAuth من الغلاف الأصلي للتطبيق (WebView Bridge)
    Utils.toast('جاري تجهيز الاتصال بـ Drive... (يتطلب إعداد مفاتيح Google API)', 'info');
  }

  // يُستدعى عند بدء تشغيل التطبيق للتحقق من موعد النسخ التلقائي
  async function checkAutoBackup() {
    const settings = await FarisDB.get(STORES.BACKUP_SETTINGS, SETTINGS_ID);
    if (!settings || !settings.autoBackup) return;

    const last = settings.lastBackup ? new Date(settings.lastBackup).getTime() : 0;
    const now = Date.now();
    const twelveHours = 12 * 60 * 60 * 1000;

    if (now - last >= twelveHours) {
      await doLocalExport(false);
      Utils.toast('تم إنشاء نسخة احتياطية تلقائية', 'info');
    }
  }

  return { init, render, checkAutoBackup };
})();
