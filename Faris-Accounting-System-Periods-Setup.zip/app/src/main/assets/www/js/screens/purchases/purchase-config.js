/* =========================================================
   تهيئة المشتريات
   إعدادات عامة فقط - الربط المحاسبي موحّد عبر "ربط المخزون بالأستاذ العام"
   ========================================================= */

const PurchaseConfig = (function () {
  const SETTINGS_ID = 'main';
  const DEFAULTS = { allowPriceEditAfterSave: false, requireExpenseDistribution: false, invoicePrefix: 'PI-' };

  async function getSettings() {
    const saved = await FarisDB.get(STORES.PURCHASE_SETTINGS, SETTINGS_ID);
    return { ...DEFAULTS, ...(saved || {}) };
  }

  async function render(container) {
    const s = await getSettings();
    container.innerHTML = `
      <p class="hint">الربط المحاسبي لفواتير المشتريات (حساب المخزون) يُدار من شاشة "ربط المخزون بالأستاذ العام" في المخزون؛ حسابات المصاريف تُختار مباشرة داخل كل فاتورة من تبويب "مصاريف".</p>
      <div class="form-grid">
        <label class="optional">بادئة ترقيم فاتورة المشتريات<input type="text" id="pc-prefix" value="${Utils.escapeHtml(s.invoicePrefix)}"></label>
        <label class="checkbox-row"><input type="checkbox" id="pc-price-edit" ${s.allowPriceEditAfterSave ? 'checked' : ''}> السماح بتعديل السعر بعد الحفظ</label>
        <label class="checkbox-row"><input type="checkbox" id="pc-require-dist" ${s.requireExpenseDistribution ? 'checked' : ''}> إلزام توزيع المصاريف قبل الحفظ عند وجود مصاريف مضافة</label>
      </div>
      <button type="button" class="btn btn-primary full" id="pc-save">💾 حفظ الإعدادات</button>
    `;
    container.querySelector('#pc-save').addEventListener('click', async () => {
      await FarisDB.put(STORES.PURCHASE_SETTINGS, {
        id: SETTINGS_ID,
        invoicePrefix: document.getElementById('pc-prefix').value.trim() || 'PI-',
        allowPriceEditAfterSave: document.getElementById('pc-price-edit').checked,
        requireExpenseDistribution: document.getElementById('pc-require-dist').checked
      });
      Utils.toast('تم حفظ إعدادات المشتريات', 'success');
    });
  }

  return { render, getSettings };
})();
