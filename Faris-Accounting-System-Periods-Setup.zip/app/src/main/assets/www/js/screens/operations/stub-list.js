/* =========================================================
   المبيعات / مرتجع المبيعات / الخصم
   (الهيكل والشريط فقط، حسب المواصفات الحالية؛ الحقول التفصيلية ستُضاف لاحقًا)
   ========================================================= */

const OpStubList = (function () {
  const TITLES = { sales: 'فواتير مبيعات', salesReturn: 'مرتجع المبيعات', discount: 'الخصم' };

  function render(container, key) {
    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="stub-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="stub-import" title="استيراد إكسل">📥</button>
        <button class="btn btn-icon" id="stub-print" title="طباعة">🖨️</button>
        <button class="btn btn-icon" id="stub-edit" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" id="stub-del" disabled title="حذف">🗑️</button>
      </div>
      <div class="toolbar search-row">
        <input type="text" id="stub-search" placeholder="🔍 بحث...">
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>لا توجد بيانات بعد</th></tr></thead>
          <tbody><tr><td class="empty-row">شاشة "${TITLES[key]}" جاهزة هيكليًا، وستُستكمل حقولها في مرحلة قادمة.</td></tr></tbody>
        </table>
      </div>
    `;

    container.querySelector('#stub-add').addEventListener('click', () => Utils.toast('سيتم إضافة حقول هذه الشاشة في مرحلة قادمة', 'info'));
    container.querySelector('#stub-import').addEventListener('click', () => Utils.toast('سيتم تفعيل الاستيراد بعد تحديد حقول الشاشة', 'info'));
    container.querySelector('#stub-print').addEventListener('click', () => Utils.toast('سيتم تفعيل الطباعة بعد تحديد حقول الشاشة', 'info'));
  }

  return { render };
})();
