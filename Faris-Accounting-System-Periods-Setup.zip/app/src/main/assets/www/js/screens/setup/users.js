/* =========================================================
   شاشة المستخدمون (فرعية من التهيئة)
   ========================================================= */

const SetupUsers = (function () {
  let selectedId = null;

  function init() {}

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="u-add">➕ إضافة</button>
        <button class="btn btn-icon" id="u-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="u-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم المستخدم</th><th>اسم المستخدم</th><th>طلب كلمة مرور</th></tr></thead>
          <tbody id="u-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="u-sheet">
        <div class="sheet-handle"></div>
        <h3>بيانات المستخدم</h3>
        <form id="u-form">
          <div class="form-grid">
            <label class="required field-wide">اسم المستخدم<input type="text" id="u-name" required></label>
            <label class="required">رقم المستخدم<input type="text" id="u-number" required></label>
            <label class="optional">كلمة المرور<input type="password" id="u-pass"></label>
            <label class="checkbox-row field-wide"><input type="checkbox" id="u-require"> طلب كلمة المرور عند الدخول</label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="u-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#u-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#u-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#u-del').addEventListener('click', onDelete);
    container.querySelector('#u-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('u-sheet')));
    container.querySelector('#u-form').addEventListener('submit', onSave);

    await loadRows();
  }

  async function loadLastUserNumber() {
    const users = await FarisDB.getAll(STORES.USERS);
    if (!users.length) return '';
    const last = users.reduce((a, b) => (a.id > b.id ? a : b));
    return last.userNumber;
  }

  async function loadRows() {
    const users = await FarisDB.getAll(STORES.USERS);
    const rows = document.getElementById('u-rows');
    rows.innerHTML = users.map(u => `
      <tr data-id="${u.id}">
        <td>${Utils.escapeHtml(u.userNumber)}</td>
        <td>${Utils.escapeHtml(u.userName)}</td>
        <td>${u.requirePassword ? 'نعم' : 'لا'}</td>
      </tr>`).join('') || '<tr><td colspan="3" class="empty-row">لا يوجد مستخدمون بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#u-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('u-edit').disabled = false;
    document.getElementById('u-del').disabled = false;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('u-sheet');
    document.getElementById('u-form').reset();

    if (id) {
      const user = await FarisDB.get(STORES.USERS, id);
      document.getElementById('u-name').value = user.userName;
      document.getElementById('u-number').value = user.userNumber;
      document.getElementById('u-pass').value = user.password || '';
      document.getElementById('u-require').checked = !!user.requirePassword;
      sheet.dataset.editId = id;
    } else {
      document.getElementById('u-number').value = await loadLastUserNumber();
      sheet.dataset.editId = '';
    }
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('u-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    const value = {
      userName: document.getElementById('u-name').value.trim(),
      userNumber: document.getElementById('u-number').value.trim(),
      password: document.getElementById('u-pass').value,
      requirePassword: document.getElementById('u-require').checked
    };
    if (editId) value.id = editId;

    const all = await FarisDB.getAll(STORES.USERS);
    const dup = all.some(u => u.userName === value.userName && u.id !== editId);
    if (dup) {
      Utils.toast('اسم المستخدم موجود مسبقًا، اختر اسمًا آخر', 'error');
      document.getElementById('u-name').classList.add('field-invalid');
      return;
    }
    document.getElementById('u-name').classList.remove('field-invalid');

    try {
      await FarisDB.put(STORES.USERS, value);
      Utils.closeSheet(sheet);
      Utils.toast('تم الحفظ بنجاح', 'success');
      await loadRows();
    } catch (err) {
      Utils.toast('رقم المستخدم مستخدم مسبقًا', 'error');
    }
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف هذا المستخدم؟');
    if (!ok) return;
    await FarisDB.remove(STORES.USERS, selectedId);
    selectedId = null;
    document.getElementById('u-edit').disabled = true;
    document.getElementById('u-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { init, render };
})();
