/* =========================================================
   FARIS ACCOUNTING - utils.js
   دوال مساعدة عامة تستخدم في كل الشاشات
   ========================================================= */

const Utils = (function () {

  function toast(message, type = 'info') {
    const box = document.getElementById('toast-box');
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = message;
    box.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 300);
    }, 2600);
  }

  function confirmDialog(message) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'confirm-overlay';
      overlay.innerHTML = `
        <div class="confirm-box">
          <p>${message}</p>
          <div class="confirm-actions">
            <button class="btn btn-ghost" data-action="cancel">إلغاء</button>
            <button class="btn btn-danger" data-action="ok">تأكيد</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      requestAnimationFrame(() => overlay.classList.add('show'));

      overlay.addEventListener('click', (e) => {
        const action = e.target.dataset.action;
        if (!action) return;
        overlay.classList.remove('show');
        setTimeout(() => overlay.remove(), 200);
        resolve(action === 'ok');
      });
    });
  }

  function openSheet(sheetEl) {
    sheetEl.classList.add('open');
    document.getElementById('app-overlay').classList.add('show');
    applyInlineLabels(sheetEl);
  }

  function closeSheet(sheetEl) {
    sheetEl.classList.remove('open');
    const anyOpen = document.querySelectorAll('.bottom-sheet.open, .popup-sheet.open').length > 0;
    if (!anyOpen) document.getElementById('app-overlay').classList.remove('show');
  }

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstChild;
  }

  // يبقي الحقل النشط ظاهرًا فوق لوحة المفاتيح داخل اللوائح القابلة للتمرير
  function bindKeyboardAwareScroll(sheetEl) {
    sheetEl.querySelectorAll('input, select, textarea').forEach((field) => {
      field.addEventListener('focus', () => {
        setTimeout(() => field.scrollIntoView({ block: 'center', behavior: 'smooth' }), 250);
      });
    });
  }

  // يحوّل نص التسمية الظاهر فوق الحقل إلى نص توضيحي (placeholder) داخل الحقل نفسه.
  // يُستدعى تلقائيًا عند فتح أي Bottom Sheet / Popup Sheet، ويمكن استدعاؤه يدويًا للنماذج المضمّنة في الصفحة.
  function applyInlineLabels(root) {
    root.querySelectorAll('label').forEach((label) => {
      // نستثني: صفوف الشيكبوكس، مجموعات اختيار العملات، وحقول "اسم + زر إضافة" لأنها تحتاج تسمية ظاهرة
      if (label.classList.contains('checkbox-row')) return;
      if (label.classList.contains('currency-check')) return;
      if (label.querySelector('.checkbox-grid')) return;
      if (label.querySelector('.row-inline')) return;
      if (label.dataset.noInlineLabel) return;

      const textNode = Array.from(label.childNodes).find(n => n.nodeType === 3 && n.textContent.trim());
      if (!textNode) return;
      const text = textNode.textContent.trim();
      const field = label.querySelector('input, select, textarea');
      if (!field) return;
      // حقول الشيكبوكس/الراديو لا يمكنها إظهار نص توضيحي (placeholder)، فتبقى تسميتها ظاهرة كما هي
      if (field.type === 'checkbox' || field.type === 'radio') return;

      if (field.tagName === 'SELECT') {
        const first = field.options[0];
        if (first && first.value === '') {
          first.textContent = text;
        } else {
          const opt = document.createElement('option');
          opt.value = '';
          opt.textContent = text;
          opt.disabled = true;
          if (!field.value) opt.selected = true;
          field.insertBefore(opt, field.firstChild);
        }
      } else if (field.type !== 'hidden' && !field.placeholder) {
        field.placeholder = text;
      }
      textNode.textContent = '';
    });
  }

  // مكوّن بحث نصي عام: يبحث داخل نفس الحقل ويظهر اقتراحات أسفله
  // getItems(query) -> [{ value, label }]   |   onSelect(item)
  function attachAutocomplete(inputEl, listEl, getItems, onSelect) {
    function renderList(items) {
      if (!items || !items.length) {
        listEl.classList.remove('open');
        listEl.innerHTML = '';
        return;
      }
      listEl.innerHTML = items.slice(0, 40).map((it, i) => `<div class="autocomplete-item" data-idx="${i}">${escapeHtml(it.label)}</div>`).join('');
      listEl.classList.add('open');
      listEl.querySelectorAll('.autocomplete-item').forEach((row, i) => {
        row.addEventListener('mousedown', (ev) => {
          ev.preventDefault();
          inputEl.value = (items[i].displayValue !== undefined) ? items[i].displayValue : items[i].label;
          listEl.classList.remove('open');
          onSelect(items[i]);
        });
      });
    }

    inputEl.addEventListener('input', () => renderList(getItems(inputEl.value.trim())));
    inputEl.addEventListener('focus', () => renderList(getItems(inputEl.value.trim())));
    inputEl.addEventListener('blur', () => setTimeout(() => listEl.classList.remove('open'), 150));
  }

  // طباعة موحدة لكل الشاشات: تستخدم خدمة الطباعة الأصلية في Android/Capacitor أولاً، ثم المتصفح عند عدم توفرها.
  async function printHtml(title, html) {
    // 1) جسر Android الأصلي (PrintManager): يفتح نافذة اختيار الطابعة (Wi-Fi / Bluetooth / خدمات الطباعة المثبتة)
    try {
      if (window.AndroidPrint && typeof window.AndroidPrint.printHtml === 'function') {
        window.AndroidPrint.printHtml(String(html), String(title || 'مستند'));
        return true;
      }
    } catch (error) {
      console.warn('AndroidPrint bridge failed; trying other print paths.', error);
    }
    try {
      const nativePrint = window.Capacitor?.Plugins?.Print;
      if (nativePrint && typeof nativePrint.print === 'function') {
        await nativePrint.print({ name: title || 'مستند', content: html });
        return true;
      }
    } catch (error) {
      console.warn('Native Android print unavailable; falling back to browser print.', error);
    }

    const win = window.open('', '_blank');
    if (win) {
      win.document.open();
      win.document.write(html);
      win.document.close();
      win.focus();
      setTimeout(() => { try { win.print(); } catch (error) { console.error(error); } }, 500);
      return true;
    }

    // fallback للـ WebView الذي يمنع النوافذ المنبثقة
    const frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    document.body.appendChild(frame);
    const doc = frame.contentDocument || frame.contentWindow.document;
    doc.open();
    doc.write(html);
    doc.close();
    setTimeout(() => {
      try { frame.contentWindow.focus(); frame.contentWindow.print(); }
      catch (error) { toast('تعذّرت الطباعة. تأكد من تفعيل خدمة الطباعة في الهاتف.', 'error'); }
    }, 500);
    return true;
  }

  // طباعة بسيطة لجدول بيانات (تُستخدم في شاشات العمليات)
  async function printTable(title, headers, rows) {
    const settings = (typeof FarisDB !== 'undefined' && typeof STORES !== 'undefined')
      ? (await FarisDB.get(STORES.SETTINGS, 'main').catch(() => null) || {}) : {};
    const arLines = [settings.arLine1, settings.arLine2, settings.arLine3].filter(Boolean);
    const enLines = [settings.enLine1, settings.enLine2, settings.enLine3].filter(Boolean);
    const logo = settings.logo ? `<img class="print-logo" src="${settings.logo}" alt="شعار المنشأة">` : '';
    const letterhead = `<header class="print-letterhead"><div class="print-head-row"><div>${arLines.map(x => `<div>${escapeHtml(x)}</div>`).join('')}</div><div class="print-logo-wrap">${logo}</div><div dir="ltr">${enLines.map(x => `<div>${escapeHtml(x)}</div>`).join('')}</div></div><h2>${escapeHtml(title)}</h2></header>`;
    const style = `
      @page{margin:12mm}
      body{font-family:Tajawal,Arial,sans-serif;direction:rtl;padding:20px;color:#1F2A24}
      h2{font-family:Cairo,Arial,sans-serif;margin:8px 0;text-align:center}
      .print-letterhead{border:1px solid #333;border-radius:8px;padding:10px;margin-bottom:12px}
      .print-head-row{display:grid;grid-template-columns:1fr 62px 1fr;align-items:center;gap:8px;font-size:11px;font-weight:bold}
      .print-head-row>div:first-child{text-align:right}.print-head-row>div:last-child{text-align:left}
      .print-logo-wrap{display:flex;justify-content:center;align-items:center}
      .print-logo{width:56px;height:56px;border-radius:50%;object-fit:cover;border:1px solid #777}
      table{width:100%;border-collapse:collapse;font-size:13px}
      th,td{border:1px solid #333;padding:6px 8px;text-align:right}
      th{background:#E4F2EE}
      img{border-radius:50%;object-fit:cover}
    `;
    const head = `<thead><tr>${headers.map(h => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead>`;
    const body = `<tbody>${rows.map(r => `<tr>${r.map(c => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('')}</tbody>`;
    const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)}</title><style>${style}</style></head><body>${letterhead}<table>${head}${body}</table></body></html>`;
    await printHtml(title, html);
  }

  // يحوّل تاريخًا مستوردًا من إكسل (dd/mm/yyyy أو yyyy/mm/dd أو dd-mm-yyyy ...) إلى صيغة النظام yyyy-mm-dd
  function normalizeImportDate(raw) {
    if (!raw) return '';
    const s = String(raw).trim();
    if (!s) return '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s; // بالفعل بصيغة النظام

    const parts = s.split(/[\/\-.]/).map(p => p.trim());
    if (parts.length !== 3 || parts.some(p => !/^\d+$/.test(p))) return s; // صيغة غير معروفة، تُترك كما هي

    let year, month, day;
    if (parts[0].length === 4) { [year, month, day] = parts; }       // yyyy-mm-dd / yyyy/mm/dd
    else if (parts[2].length === 4) { [day, month, year] = parts; }  // dd-mm-yyyy / dd/mm/yyyy
    else return s;

    const pad = (n) => String(n).padStart(2, '0');
    const m = Number(month), d = Number(day), y = Number(year);
    if (m < 1 || m > 12 || d < 1 || d > 31) return s; // قيم غير منطقية، تُترك كما هي
    return `${y}-${pad(m)}-${pad(d)}`;
  }

  return { toast, confirmDialog, openSheet, closeSheet, fileToBase64, escapeHtml, el, bindKeyboardAwareScroll, applyInlineLabels, attachAutocomplete, printTable, printHtml, normalizeImportDate };
})();
