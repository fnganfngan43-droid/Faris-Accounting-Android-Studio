package com.faris.accounting;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Tiny read-only ContentProvider that exposes files from the app cache folder ("shared") so that
 * other apps (Google Drive, WhatsApp, e-mail...) can receive them from the Android share sheet.
 * Written without androidx so the project keeps building with no extra dependencies.
 */
public class ShareFileProvider extends ContentProvider {

    public static final String AUTHORITY = "com.faris.accounting.shareprovider";
    private static final String DIR = "shared";

    private static File sharedDir(android.content.Context context) {
        File dir = new File(context.getCacheDir(), DIR);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    /** Writes the bytes into the cache folder and opens the Android share sheet for the file. */
    public static void share(final Activity activity, byte[] data, String fileName, String mime, String title) throws IOException {
        File dir = sharedDir(activity);
        // keep the cache tidy: remove previously shared files
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();

        String safe = fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
        File file = new File(dir, safe);
        FileOutputStream out = new FileOutputStream(file);
        try { out.write(data); } finally { out.close(); }

        Uri uri = new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath(DIR).appendPath(safe).build();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, safe);
        send.setClipData(ClipData.newRawUri(safe, uri));
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        final Intent chooser = Intent.createChooser(send, title == null || title.isEmpty() ? safe : title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        activity.runOnUiThread(new Runnable() {
            @Override public void run() { activity.startActivity(chooser); }
        });
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        String name = uri.getLastPathSegment();
        if (name == null) throw new FileNotFoundException("no file name");
        File dir = sharedDir(getContext());
        File file = new File(dir, name);
        try {
            // block path traversal: the file must live directly inside the shared folder
            if (!file.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) throw new FileNotFoundException("bad path");
        } catch (IOException e) {
            throw new FileNotFoundException("bad path");
        }
        if (!file.exists()) throw new FileNotFoundException("missing");
        return file;
    }

    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            File file = resolve(uri);
            String[] cols = projection != null ? projection : new String[] { OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE };
            MatrixCursor cursor = new MatrixCursor(cols, 1);
            Object[] row = new Object[cols.length];
            for (int i = 0; i < cols.length; i++) {
                if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = file.getName();
                else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = file.length();
            }
            cursor.addRow(row);
            return cursor;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    @Override public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name != null) {
            String lower = name.toLowerCase();
            if (lower.endsWith(".json")) return "application/json";
            if (lower.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            if (lower.endsWith(".pdf")) return "application/pdf";
        }
        return "application/octet-stream";
    }

    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
