package com.faris.accounting;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.content.Context;
import android.view.KeyEvent;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 101;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidPrintBridge(), "AndroidPrint");
        webView.addJavascriptInterface(new AndroidNavigationBridge(), "AndroidNavigation");
        webView.addJavascriptInterface(new AndroidFilesBridge(), "AndroidFiles");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
    }


    /** Bridge called by the app's shared JavaScript print function. */
    private final class AndroidPrintBridge {
        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            startPrint(html, title, false);
        }

        /** Same as printHtml but lets the caller choose the page orientation ("landscape" or "portrait"). */
        @JavascriptInterface
        public void printHtmlWithOrientation(final String html, final String title, final String orientation) {
            startPrint(html, title, "landscape".equalsIgnoreCase(orientation));
        }

        private void startPrint(final String html, final String title, final boolean landscape) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
                        Toast.makeText(MainActivity.this, "الطباعة تتطلب Android 4.4 أو أحدث", Toast.LENGTH_LONG).show();
                        return;
                    }
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null) {
                        Toast.makeText(MainActivity.this, "خدمة الطباعة غير متاحة في الهاتف", Toast.LENGTH_LONG).show();
                        return;
                    }

                    final WebView printWebView = new WebView(MainActivity.this);
                    WebSettings printSettings = printWebView.getSettings();
                    printSettings.setJavaScriptEnabled(true);
                    printSettings.setDomStorageEnabled(true);
                    printSettings.setAllowFileAccess(true);
                    printSettings.setLoadsImagesAutomatically(true);
                    printWebView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            super.onPageFinished(view, url);
                            try {
                                String jobName = (title == null || title.trim().isEmpty()) ? "مستند" : title.trim();
                                PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(jobName);
                                printManager.print(jobName, adapter, new android.print.PrintAttributes.Builder()
                                        .setMediaSize(landscape
                                                ? android.print.PrintAttributes.MediaSize.ISO_A4.asLandscape()
                                                : android.print.PrintAttributes.MediaSize.ISO_A4)
                                        .setColorMode(android.print.PrintAttributes.COLOR_MODE_COLOR)
                                        .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS)
                                        .build());
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "تعذّرت تهيئة الطباعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    String printable = html == null ? "" : html;
                    printWebView.loadDataWithBaseURL("file:///android_asset/www/", printable,
                            "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذّرت الطباعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    /**
     * Saves a file (Excel, backup JSON...) sent from JavaScript as base64 into the public Downloads folder.
     * A WebView cannot download blob: URLs by itself, so this bridge is what makes exports actually save.
     * Returns the saved file name, or an empty string on failure.
     */
    private final class AndroidFilesBridge {
        @JavascriptInterface
        public String saveFile(String base64, String fileName, String mime) {
            try {
                byte[] data = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                String safe = (fileName == null || fileName.trim().isEmpty()) ? "file" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    android.content.ContentValues values = new android.content.ContentValues();
                    values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, safe);
                    values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, type);
                    values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                    android.content.ContentResolver resolver = getContentResolver();
                    Uri uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return "";
                    java.io.OutputStream out = resolver.openOutputStream(uri);
                    if (out == null) return "";
                    try { out.write(data); } finally { out.close(); }
                    return safe;
                }

                // Android 9 وأقدم: مجلد التنزيلات العام، وإن لم تُمنح صلاحية الكتابة نحفظ في مجلد التطبيق
                java.io.File target;
                try {
                    java.io.File dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    target = uniqueFile(dir, safe);
                    writeBytes(target, data);
                } catch (Exception legacyError) {
                    java.io.File appDir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
                    if (appDir == null) return "";
                    target = uniqueFile(appDir, safe);
                    writeBytes(target, data);
                }
                return target.getName();
            } catch (Exception e) {
                return "";
            }
        }

        /** Opens the Android share sheet for a file (e.g. pick Google Drive to store a backup). */
        @JavascriptInterface
        public boolean shareFile(String base64, String fileName, String mime, String title) {
            try {
                byte[] data = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                ShareFileProvider.share(MainActivity.this, data, (fileName == null || fileName.trim().isEmpty()) ? "file" : fileName, mime, title);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    private static java.io.File uniqueFile(java.io.File dir, String name) {
        java.io.File f = new java.io.File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        int n = 1;
        while (f.exists()) { f = new java.io.File(dir, base + " (" + (n++) + ")" + ext); }
        return f;
    }

    private static void writeBytes(java.io.File file, byte[] data) throws java.io.IOException {
        java.io.FileOutputStream out = new java.io.FileOutputStream(file);
        try { out.write(data); } finally { out.close(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    /** Native Android Back delegates to the app's JavaScript navigation stack. */
    @Override public void onBackPressed() {
        if (webView == null) {
            return;
        }
        runOnUiThread(() -> webView.evaluateJavascript(
                "(function(){ if (window.App && typeof App.systemBack === 'function') { App.systemBack(); } })();",
                null
        ));
    }

    /** JavaScript bridge used only after the user confirms exiting from Home. */
    private final class AndroidNavigationBridge {
        @JavascriptInterface
        public void confirmExit() {
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                    .setMessage("هل تريد الخروج من التطبيق؟")
                    .setPositiveButton("نعم", (dialog, which) -> finish())
                    .setNegativeButton("لا", (dialog, which) -> dialog.dismiss())
                    .setCancelable(true)
                    .show());
        }
    }
}
