/* =========================================================
   مستويات التسعير
   عند الضغط على "إضافة" تظهر الحقول: رقم المستوى، اسم المستوى، عملة المستوى، سعر الصرف، وزرا حفظ/إلغاء
   ========================================================= */

const InvPricingLevels = (function () {
  let selectedId = null;
  let currencies = [];

  const $ = (id) => document.getElementById(id);
  const esc = (v) => Utils.escapeHtml(String(v ?? ''));
  const rateOf = (c) => (!c || c.type === 'محلي') ? 1 : (Number(c.rate) || 1);
  const currencyLabel = (c) => c ? `(${c.symbol}) ${c.name}` : '';

  async function render(container) {
    selectedId = null;
    currencies = (await FarisDB.getAll(STORES.CURRENCIES)).sort((a, b) => a.id - b.id);

    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="pl-add">➕ إضافة</button>
        <button class="btn btn-icon" id="pl-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="pl-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم المستوى</th><th>اسم المستوى</th><th>عملة المستوى</th><th>سعر الصرف</th></tr></thead>
          <tbody id="pl-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="pl-sheet">
        <div class="sheet-handle"></div>
        <h3>بيانات مستوى التسعير</h3>
        <form id="pl-form">
          <div class="form-grid">
            <label class="optional" data-no-inline-label="1">رقم المستوى<input type="text" id="pl-no" readonly></label>
            <label class="required" data-no-inline-label="1">اسم المستوى<input type="text" id="pl-name" required autocomplete="off"></label>
            <label class="required" data-no-inline-label="1">عملة المستوى<select id="pl-currency" required></select></label>
            <label class="optional" data-no-inline-label="1">سعر الصرف<input type="text" id="pl-rate" readonly></label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="pl-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#pl-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#pl-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#pl-del').addEventListener('click', onDelete);
    container.querySelector('#pl-cancel').addEventListener('click', () => Utils.closeSheet($('pl-sheet')));
    container.querySelector('#pl-form').addEventListener('submit', onSave);
    container.querySelector('#pl-currency').addEventListener('change', updateRate);

    await loadRows();
  }

  async function loadRows() {
    const items = (await FarisDB.getAll(STORES.INV_PRICING_LEVELS)).sort((a, b) => (a.levelNo || 0) - (b.levelNo || 0));
    $('pl-rows').innerHTML = items.map(l => `
      <tr data-id="${l.id}">
        <td>${esc(l.levelNo)}</td><td>${esc(l.name)}</td>
        <td>${esc(currencyLabel(currencies.find(c => c.id === l.currencyId)))}</td><td>${esc(l.exchangeRate)}</td>
      </tr>`).join('') || '<tr><td colspan="4" class="empty-row">لا توجد مستويات تسعير بعد</td></tr>';

    $('pl-rows').querySelectorAll('tr[data-id]').forEach(tr => tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr)));
    $('pl-edit').disabled = true;
    $('pl-del').disabled = true;
    selectedId = null;
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#pl-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    $('pl-edit').disabled = false;
    $('pl-del').disabled = false;
  }

  // سعر الصرف يتبع عملة المستوى المختارة (للعملة المحلية = 1)
  function updateRate() {
    const c = currencies.find(x => x.id === Number($('pl-currency').value));
    $('pl-rate').value = c ? rateOf(c) : '';
  }

  async function nextLevelNo() {
    const items = await FarisDB.getAll(STORES.INV_PRICING_LEVELS);
    return items.reduce((m, l) => Math.max(m, Number(l.levelNo) || 0), 0) + 1;
  }

  async function openSheet(id) {
    if (!currencies.length) { Utils.toast('أضف عملة من التهيئة أولًا', 'error'); return; }
    const sheet = $('pl-sheet');
    $('pl-form').reset();
    $('pl-currency').innerHTML = currencies.map(c => `<option value="${c.id}">${esc(currencyLabel(c))}</option>`).join('');

    if (id) {
      const l = await FarisDB.get(STORES.INV_PRICING_LEVELS, id);
      $('pl-no').value = l.levelNo;
      $('pl-name').value = l.name;
      if (currencies.some(c => c.id === l.currencyId)) $('pl-currency').value = l.currencyId;
      sheet.dataset.editId = id;
    } else {
      $('pl-no').value = await nextLevelNo();
      const local = currencies.find(c => c.type === 'محلي') || currencies[0];
      $('pl-currency').value = local.id;
      sheet.dataset.editId = '';
    }
    updateRate();
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = $('pl-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;
    const name = $('pl-name').value.trim();
    const currencyId = Number($('pl-currency').value);
    const currency = currencies.find(c => c.id === currencyId);
    if (!name) { Utils.toast('اكتب اسم المستوى', 'error'); return; }
    if (!currency) { Utils.toast('اختر عملة المستوى', 'error'); return; }

    const existing = await FarisDB.getAll(STORES.INV_PRICING_LEVELS);
    if (existing.some(l => l.name === name && l.id !== editId)) { Utils.toast('اسم المستوى مستخدم مسبقًا', 'error'); return; }

    const value = { levelNo: Number($('pl-no').value) || await nextLevelNo(), name, currencyId, exchangeRate: rateOf(currency) };
    if (existing.some(l => Number(l.levelNo) === value.levelNo && l.id !== editId)) value.levelNo = await nextLevelNo();
    if (editId) value.id = editId;

    await FarisDB.put(STORES.INV_PRICING_LEVELS, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف مستوى التسعير هذا؟');
    if (!ok) return;
    await FarisDB.remove(STORES.INV_PRICING_LEVELS, selectedId);
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { render };
})();
