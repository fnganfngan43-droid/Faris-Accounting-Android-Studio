/* =========================================================
   تسعير الأصناف
   الأدوات: ➕ إضافة | 💾 حفظ | 🔍 بحث | 🗑️ حذف | 📥 استيراد إكسل | 🖨️ طباعة | 📤 تصدير إكسل
   ➕ تفتح لوحة: طريقة الإنزال (يدوي / إنزال آلي) + من/إلى رقم + من/إلى مجموعة فرعية +
      من فاتورة مشتريات رقم + من/إلى مخزن + مستوى التسعيرة + النسبة + عدد الكسور + زر "احسب".
   "احسب" تُخفي اللوحة وتُنزل الأصناف في جدول: رقم الصنف | اسم الصنف | الوحدة | الكمية | التكلفة | سعر البيع.
   التسعير بعملة مستوى التسعيرة: التكلفة تُحوَّل من عملة المخزن إلى عملة المستوى، وسعر البيع = التكلفة × (1 + النسبة%)
   مقرَّبًا إلى عدد الكسور.
   ========================================================= */

const InvItemPricing = (function () {
  const EPS = 1e-6;
  const $ = (id) => document.getElementById(id);
  const esc = (v) => Utils.escapeHtml(String(v ?? ''));

  let data = null;   // البيانات المرجعية المحمّلة
  const state = { mode: 'idle', params: null, lines: [], editId: null, stockMap: null };

  /* ---------------- أدوات الحساب ---------------- */
  const rateOf = (c) => (!c || c.type === 'محلي') ? 1 : (Number(c.rate) || 1);
  const roundTo = (n, d) => { const f = Math.pow(10, d); return Math.round((Number(n) + Number.EPSILON) * f) / f; };
  const fmtQty = (n) => String(Number(Number(n || 0).toFixed(4)));
  const fmtCost = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  const fmtPrice = (n, d) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });

  // مبلغ بعملة معيّنة → بعملة مستوى التسعيرة (عبر العملة المحلية)
  function toLevelCurrency(amount, fromCurrencyId, levelCurrencyId) {
    const from = data.curMap.get(fromCurrencyId), lvl = data.curMap.get(levelCurrencyId);
    return (Number(amount) || 0) * rateOf(from) / rateOf(lvl);
  }

  function cmpCode(a, b) {
    const na = Number(a), nb = Number(b);
    if (!isNaN(na) && !isNaN(nb) && String(a).trim() !== '' && String(b).trim() !== '') return na - nb;
    return String(a).localeCompare(String(b), undefined, { numeric: true });
  }

  function baseUnitOf(item) {
    if (!item || !item.units || !item.units.length) return null;
    return item.units.find(u => u.isBase) || item.units[0];
  }

  function makeLine(item, unitId, qty, cost, params) {
    const price = roundTo(cost * (1 + params.percent / 100), params.decimals);
    return {
      itemCode: item.code, itemName: item.name, unitId, unitName: data.unitMap.get(unitId) || '',
      qty: Number(qty) || 0, cost: Number(cost) || 0, price
    };
  }

  /* ---------------- تحميل البيانات المرجعية ---------------- */
  async function loadData() {
    const [items, units, warehouses, subs, mains, levels, currencies] = await Promise.all([
      FarisDB.getAllRawCached(STORES.INV_ITEMS), FarisDB.getAllRawCached(STORES.INV_UNITS),
      FarisDB.getAllRawCached(STORES.INV_WAREHOUSES), FarisDB.getAllRawCached(STORES.INV_GROUPS_SUB),
      FarisDB.getAllRawCached(STORES.INV_GROUPS_MAIN), FarisDB.getAllRawCached(STORES.INV_PRICING_LEVELS),
      FarisDB.getAllRawCached(STORES.CURRENCIES)
    ]);
    data = {
      items: items.sort((a, b) => cmpCode(a.code, b.code)),
      itemMap: new Map(items.map(i => [i.code, i])),
      unitMap: new Map(units.map(u => [u.id, u.name])),
      warehouses: warehouses.sort((a, b) => a.id - b.id),
      whMap: new Map(warehouses.map(w => [w.id, w])),
      subs: subs.sort((a, b) => a.id - b.id),
      mainMap: new Map(mains.map(m => [m.id, m.name])),
      levels: levels.sort((a, b) => (a.levelNo || 0) - (b.levelNo || 0)),
      currencies: currencies.sort((a, b) => a.id - b.id),
      curMap: new Map(currencies.map(c => [c.id, c]))
    };
  }

  /* ---------------- رصيد وتكلفة الأصناف من حركة المخزون ---------------- */
  // يرجع Map(كود الصنف → { balance (بأصغر وحدة), inValue (بعملة المستوى), inBase }) مع تقييد المخازن اختياريًا
  async function buildStockMap(levelCurrencyId, whFilter) {
    const movements = await ItemMovementEngine.gatherAllMovements();
    const map = new Map();
    movements.forEach(m => {
      if (whFilter && !whFilter(m.warehouseId)) return;
      const wh = data.whMap.get(m.warehouseId);
      const whCurrency = wh ? wh.currencyId : levelCurrencyId;
      let g = map.get(m.itemCode);
      if (!g) { g = { balance: 0, inValue: 0, inBase: 0 }; map.set(m.itemCode, g); }
      g.balance += (Number(m.incomingBaseQty) || 0) - (Number(m.outgoingBaseQty) || 0);
      if ((Number(m.incomingQty) || 0) > 0) {
        g.inValue += toLevelCurrency((Number(m.incomingQty) || 0) * (Number(m.unitCost) || 0), whCurrency, levelCurrencyId);
        g.inBase += Number(m.incomingBaseQty) || 0;
      }
    });
    return map;
  }

  function lineFromStock(item, g, params) {
    const unit = baseUnitOf(item);
    if (!unit) return null;
    const factor = Number(unit.linkFactor) || 1;
    const costSmallest = g && g.inBase > 0 ? g.inValue / g.inBase : 0;
    return makeLine(item, unit.unitId, g ? g.balance / factor : 0, costSmallest * factor, params);
  }

  /* ---------------- فلاتر الإنزال الآلي ---------------- */
  // نطاق من/إلى على قائمة مرتّبة (مجموعات فرعية أو مخازن): يرجع Set معرّفات أو null بلا تحديد
  function rangeSet(list, fromId, toId) {
    if (!fromId && !toId) return null;
    const ids = list.map(x => x.id);
    let i1 = fromId ? ids.indexOf(Number(fromId)) : 0;
    let i2 = toId ? ids.indexOf(Number(toId)) : ids.length - 1;
    if (i1 < 0) i1 = 0;
    if (i2 < 0) i2 = ids.length - 1;
    if (i1 > i2) [i1, i2] = [i2, i1];
    return new Set(ids.slice(i1, i2 + 1));
  }

  function makeItemFilter(f) {
    const subSet = rangeSet(data.subs, f.fromSub, f.toSub);
    return (item) => {
      if (f.fromNo && cmpCode(item.code, f.fromNo) < 0) return false;
      if (f.toNo && cmpCode(item.code, f.toNo) > 0) return false;
      if (subSet && !subSet.has(Number(item.subGroupId))) return false;
      return true;
    };
  }

  async function loadAuto(params) {
    const f = params.filters;
    const itemOk = makeItemFilter(f);
    const whSet = rangeSet(data.warehouses, f.fromWh, f.toWh);
    const lines = [];

    if (f.purchaseNo) {
      // من فاتورة مشتريات: أصناف الفاتورة بكمياتها وتكلفتها (بوحدة السطر) مجمّعة لكل صنف ووحدة
      const invoices = await FarisDB.getAllRawCached(STORES.PURCHASE_INVOICES);
      const inv = invoices.find(i => String(i.invoiceNo).trim().toLowerCase() === f.purchaseNo.toLowerCase());
      if (!inv) { Utils.toast('رقم فاتورة المشتريات غير موجود', 'error'); return null; }
      const agg = new Map();
      (inv.lines || []).forEach(l => {
        const item = data.itemMap.get(l.itemCode);
        if (!item || !itemOk(item)) return;
        const whId = l.warehouseId || inv.warehouseId;
        if (whSet && !whSet.has(Number(whId))) return;
        const wh = data.whMap.get(Number(whId));
        const qty = Number(l.qty) || 0;
        if (qty <= EPS) return;
        const totalWh = l.totalCostLocal !== undefined ? Number(l.totalCostLocal) : (Number(l.initialCostLocal) || qty * (Number(l.price) || 0));
        const key = `${l.itemCode}|${l.unitId}`;
        const g = agg.get(key) || { item, unitId: l.unitId, qty: 0, totalLevel: 0 };
        g.qty += qty;
        g.totalLevel += toLevelCurrency(totalWh, wh ? wh.currencyId : params.currencyId, params.currencyId);
        agg.set(key, g);
      });
      agg.forEach(g => lines.push(makeLine(g.item, g.unitId, g.qty, g.qty ? g.totalLevel / g.qty : 0, params)));
      return lines;
    }

    // من المخزون: كل الأصناف التي لها كمية (لا تُنزَّل الأصناف ذات الكمية صفر)
    const stock = await buildStockMap(params.currencyId, whSet ? (id) => whSet.has(Number(id)) : null);
    data.items.forEach(item => {
      if (!itemOk(item)) return;
      const g = stock.get(item.code);
      if (!g || g.balance <= EPS) return;
      const line = lineFromStock(item, g, params);
      if (line) lines.push(line);
    });
    return lines;
  }

  /* ---------------- الواجهة ---------------- */
  async function render(container) {
    await YearEnd.refresh();
    await loadData();
    state.mode = 'idle'; state.params = null; state.lines = []; state.editId = null; state.stockMap = null;

    container.innerHTML = `
      <div class="toolbar icon-only" id="ip-toolbar">
        <button class="btn btn-icon" id="ip-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="ip-save" title="حفظ" disabled>💾</button>
        <button class="btn btn-icon" id="ip-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="ip-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="ip-import" title="استيراد إكسل" disabled>📥</button>
        <button class="btn btn-icon" id="ip-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="ip-export" title="تصدير إكسل" disabled>📤</button>
      </div>
      <input type="file" id="ip-import-file" accept=".xlsx,.xls,.csv" style="display:none;">

      <p class="hint" id="ip-hint">اضغط ➕ لإنشاء تسعيرة جديدة، أو 🔍 لفتح تسعيرة محفوظة.</p>

      <div id="ip-panel" style="display:none;">
        <div class="radio-row">
          <label><input type="radio" name="ip-method" value="manual"> يدوي</label>
          <label><input type="radio" name="ip-method" value="auto" checked> إنزال آلي</label>
        </div>
        <div id="ip-filters" class="form-grid">
          <label class="optional"><input type="text" id="ip-from-no" autocomplete="off">من رقم</label>
          <label class="optional"><input type="text" id="ip-to-no" autocomplete="off">إلى رقم</label>
          <label class="optional"><select id="ip-from-sub"><option value=""></option></select>من مجموعة فرعية</label>
          <label class="optional"><select id="ip-to-sub"><option value=""></option></select>إلى مجموعة فرعية</label>
          <label class="optional field-wide">
            <div class="combo-wrap">
              <input type="text" id="ip-purchase-no" autocomplete="off">
              <div class="autocomplete-list" id="ip-purchase-list"></div>
            </div>من فاتورة مشتريات رقم
          </label>
          <label class="optional"><select id="ip-from-wh"><option value=""></option></select>من مخزن</label>
          <label class="optional"><select id="ip-to-wh"><option value=""></option></select>إلى مخزن</label>
        </div>
        <div class="form-grid">
          <label class="required field-wide"><select id="ip-level"><option value=""></option></select>مستوى التسعيرة</label>
          <label class="required"><input type="number" id="ip-percent" step="0.01" min="0" inputmode="decimal">النسبة %</label>
          <label class="required"><input type="number" id="ip-decimals" step="1" min="0" max="6" inputmode="numeric">عدد الكسور</label>
        </div>
        <button type="button" class="btn btn-primary full" id="ip-calc" style="margin-top:12px;">🧮 احسب</button>
      </div>

      <div class="info-card" id="ip-info" style="display:none;"></div>

      <div class="table-scroll" id="ip-table-wrap" style="display:none;">
        <table class="data-table">
          <thead><tr><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>الكمية</th><th>التكلفة</th><th>سعر البيع</th><th></th></tr></thead>
          <tbody id="ip-rows"></tbody>
        </table>
      </div>

      <div id="ip-search-view" style="display:none;">
        <div class="toolbar search-row"><input type="text" id="ip-search-input" placeholder="🔍 بحث برقم التسعيرة أو المستوى أو التاريخ"></div>
        <div class="table-scroll">
          <table class="data-table">
            <thead><tr><th>رقم التسعيرة</th><th>التاريخ</th><th>مستوى التسعيرة</th><th>العملة</th><th>النسبة %</th><th>عدد الأصناف</th></tr></thead>
            <tbody id="ip-saved-rows"></tbody>
          </table>
        </div>
      </div>
    `;

    Utils.applyInlineLabels($('ip-panel'));
    bind(container);
  }

  function bind(container) {
    container.querySelector('#ip-add').addEventListener('click', onAdd);
    container.querySelector('#ip-save').addEventListener('click', onSave);
    container.querySelector('#ip-search').addEventListener('click', onSearch);
    container.querySelector('#ip-del').addEventListener('click', onDelete);
    container.querySelector('#ip-print').addEventListener('click', onPrint);
    container.querySelector('#ip-export').addEventListener('click', onExport);
    container.querySelector('#ip-import').addEventListener('click', () => $('ip-import-file').click());
    container.querySelector('#ip-import-file').addEventListener('change', onImportFile);
    container.querySelector('#ip-calc').addEventListener('click', onCalc);
    container.querySelectorAll('input[name="ip-method"]').forEach(r => r.addEventListener('change', syncMethod));
    container.querySelector('#ip-search-input').addEventListener('input', drawSaved);

    Utils.attachAutocomplete($('ip-purchase-no'), $('ip-purchase-list'), (q) => {
      const query = q.toLowerCase();
      return (data.purchaseInvoices || [])
        .filter(i => !query || String(i.invoiceNo).toLowerCase().includes(query))
        .map(i => ({ value: i.invoiceNo, label: `${i.invoiceNo} — ${i.date || ''}`, displayValue: String(i.invoiceNo) }));
    }, () => {});
  }

  /* ---------------- تبديل العرض وحالة الأزرار ---------------- */
  function setMode(mode) {
    state.mode = mode;
    $('ip-hint').style.display = mode === 'idle' ? '' : 'none';
    $('ip-panel').style.display = mode === 'panel' ? '' : 'none';
    $('ip-info').style.display = mode === 'table' ? '' : 'none';
    $('ip-table-wrap').style.display = mode === 'table' ? '' : 'none';
    $('ip-search-view').style.display = mode === 'search' ? '' : 'none';
    const hasLines = state.mode === 'table' && state.lines.length > 0;
    $('ip-save').disabled = !hasLines;
    $('ip-print').disabled = !hasLines;
    $('ip-export').disabled = !hasLines;
    $('ip-import').disabled = state.mode !== 'table';
    $('ip-del').disabled = !(state.mode === 'table' && (state.editId || state.lines.length));
  }

  function syncMethod() {
    const manual = document.querySelector('input[name="ip-method"]:checked').value === 'manual';
    $('ip-filters').style.display = manual ? 'none' : '';
  }

  /* ---------------- إضافة (لوحة الخيارات) ---------------- */
  async function onAdd() {
    if (!data.levels.length) { Utils.toast('أضف مستوى تسعير أولًا من شاشة مستويات التسعير', 'error'); return; }
    data.purchaseInvoices = (await FarisDB.getAllRawCached(STORES.PURCHASE_INVOICES)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    state.params = null; state.lines = []; state.editId = null; state.stockMap = null;

    const subLabel = (s) => `${data.mainMap.get(s.mainGroupId) || ''} › ${s.name}`;
    const fillSel = (id, label, rows, text) => { $(id).innerHTML = `<option value="">${esc(label)}</option>` + rows.map(r => `<option value="${r.id}">${esc(text(r))}</option>`).join(''); };
    fillSel('ip-from-sub', 'من مجموعة فرعية', data.subs, subLabel);
    fillSel('ip-to-sub', 'إلى مجموعة فرعية', data.subs, subLabel);
    fillSel('ip-from-wh', 'من مخزن', data.warehouses, w => w.name);
    fillSel('ip-to-wh', 'إلى مخزن', data.warehouses, w => w.name);
    fillSel('ip-level', 'مستوى التسعيرة', data.levels, l => `${l.levelNo} - ${l.name} (${(data.curMap.get(l.currencyId) || {}).symbol || ''})`);
    ['ip-from-no', 'ip-to-no', 'ip-purchase-no', 'ip-percent', 'ip-decimals'].forEach(id => { $(id).value = ''; });
    document.querySelector('input[name="ip-method"][value="auto"]').checked = true;
    syncMethod();
    setMode('panel');
  }

  /* ---------------- احسب ---------------- */
  async function onCalc() {
    const manual = document.querySelector('input[name="ip-method"]:checked').value === 'manual';
    const level = data.levels.find(l => l.id === Number($('ip-level').value));
    const percentText = $('ip-percent').value.trim(), decimalsText = $('ip-decimals').value.trim();
    if (!level) { Utils.toast('اختر مستوى التسعيرة', 'error'); return; }
    if (percentText === '' || isNaN(Number(percentText)) || Number(percentText) < 0) { Utils.toast('أدخل النسبة (رقم صحيح أو عشري)', 'error'); return; }
    if (decimalsText === '' || !Number.isInteger(Number(decimalsText)) || Number(decimalsText) < 0 || Number(decimalsText) > 6) { Utils.toast('أدخل عدد الكسور (من 0 إلى 6)', 'error'); return; }

    const params = {
      method: manual ? 'manual' : 'auto',
      levelId: level.id, levelName: level.name, currencyId: level.currencyId,
      percent: Number(percentText), decimals: Number(decimalsText),
      filters: manual ? {} : {
        fromNo: $('ip-from-no').value.trim(), toNo: $('ip-to-no').value.trim(),
        fromSub: $('ip-from-sub').value, toSub: $('ip-to-sub').value,
        purchaseNo: $('ip-purchase-no').value.trim(),
        fromWh: $('ip-from-wh').value, toWh: $('ip-to-wh').value
      }
    };

    const btn = $('ip-calc');
    btn.disabled = true;
    try {
      let lines = [];
      if (!manual) {
        lines = await loadAuto(params);
        if (lines === null) return;
        if (!lines.length) { Utils.toast('لا توجد أصناف مطابقة بكميات في المخزون', 'info'); return; }
      }
      state.params = params; state.lines = lines; state.editId = null; state.stockMap = null;
      setMode('table');
      drawTable();
    } catch (err) {
      Utils.toast(err.message || 'تعذّر حساب التسعيرة', 'error');
    } finally {
      btn.disabled = false;
    }
  }

  /* ---------------- جدول الأصناف ---------------- */
  function drawInfo() {
    const p = state.params;
    const cur = data.curMap.get(p.currencyId);
    $('ip-info').innerHTML = `
      <div class="info-row"><span>مستوى التسعيرة</span><b>${esc(p.levelName)}</b></div>
      <div class="info-row"><span>عملة التسعير</span><b>${esc(cur ? `(${cur.symbol}) ${cur.name}` : '')}</b></div>
      <div class="info-row"><span>النسبة / عدد الكسور</span><b>${p.percent}% / ${p.decimals}</b></div>
      ${state.editId ? `<div class="info-row"><span>التسعيرة المحفوظة رقم</span><b>${esc(state.savedNo || '')}</b></div>` : ''}`;
  }

  function drawTable() {
    drawInfo();
    const p = state.params;
    const rows = state.lines.map((l, i) => `
      <tr>
        <td>${esc(l.itemCode)}</td><td>${esc(l.itemName)}</td><td>${esc(l.unitName)}</td>
        <td>${fmtQty(l.qty)}</td><td>${fmtCost(l.cost)}</td><td><b>${fmtPrice(l.price, p.decimals)}</b></td>
        <td><button class="btn btn-ghost ip-row-del" data-i="${i}" title="حذف الصف">✖️</button></td>
      </tr>`).join('');
    // صف البحث عن صنف (للطريقة اليدوية) بنفس أسلوب الفاتورة
    const searchRow = p.method === 'manual' ? `
      <tr class="ip-add-row"><td colspan="7">
        <div class="combo-wrap">
          <input type="text" id="ip-item-input" placeholder="🔍 ابحث عن صنف برقمه أو اسمه لإضافته" autocomplete="off">
          <div class="autocomplete-list" id="ip-item-list"></div>
        </div>
      </td></tr>` : '';
    $('ip-rows').innerHTML = rows + searchRow || '<tr><td colspan="7" class="empty-row">لا توجد أصناف</td></tr>';

    $('ip-rows').querySelectorAll('.ip-row-del').forEach(b => b.addEventListener('click', () => {
      state.lines.splice(Number(b.dataset.i), 1);
      drawTable(); setMode('table');
    }));
    const input = $('ip-item-input');
    if (input) {
      Utils.attachAutocomplete(input, $('ip-item-list'), (q) => {
        const query = q.toLowerCase();
        return data.items
          .filter(i => !query || String(i.code).toLowerCase().includes(query) || String(i.name).toLowerCase().includes(query))
          .map(i => ({ value: i.code, label: `${i.code} - ${i.name}`, displayValue: '' }));
      }, (it) => addItem(it.value));
    }
    setMode('table');
  }

  // إضافة صنف يدويًا: يظهر الاسم والوحدة والكمية والتكلفة وسعر البيع تلقائيًا
  async function addItem(code) {
    const p = state.params;
    const item = data.itemMap.get(code);
    if (!item) return;
    if (state.lines.some(l => l.itemCode === code)) { Utils.toast('الصنف مضاف مسبقًا', 'info'); return; }
    if (!baseUnitOf(item)) { Utils.toast('الصنف بلا وحدة قياس', 'error'); return; }
    if (!state.stockMap) state.stockMap = await buildStockMap(p.currencyId, null);
    const line = lineFromStock(item, state.stockMap.get(code), p);
    if (line.cost <= 0) Utils.toast('لا توجد تكلفة لهذا الصنف بعد', 'info');
    state.lines.push(line);
    drawTable();
    const next = $('ip-item-input'); if (next) next.focus();
  }

  /* ---------------- الحفظ والبحث والحذف ---------------- */
  function currentData() {
    const p = state.params;
    const cur = data.curMap.get(p.currencyId);
    return {
      title: `تسعير الأصناف - ${p.levelName} (${cur ? cur.symbol : ''}) نسبة ${p.percent}%`,
      headers: ['رقم الصنف', 'اسم الصنف', 'الوحدة', 'الكمية', 'التكلفة', 'سعر البيع'],
      rows: state.lines.map(l => [l.itemCode, l.itemName, l.unitName, fmtQty(l.qty), roundTo(l.cost, 4).toFixed(4), roundTo(l.price, p.decimals).toFixed(p.decimals)])
    };
  }

  async function onSave() {
    if (!state.lines.length) { Utils.toast('لا توجد أصناف للحفظ', 'error'); return; }
    const p = state.params;
    const existing = await FarisDB.getAllRaw(STORES.INV_ITEM_PRICINGS);
    const rec = {
      no: state.editId ? state.savedNo : existing.reduce((m, r) => Math.max(m, Number(r.no) || 0), 0) + 1,
      date: new Date().toISOString().slice(0, 10),
      levelId: p.levelId, levelName: p.levelName, currencyId: p.currencyId,
      percent: p.percent, decimals: p.decimals, method: p.method, filters: p.filters,
      lines: state.lines.map(l => ({ ...l, price: roundTo(l.cost * (1 + p.percent / 100), p.decimals) })),
      savedAt: new Date().toISOString()
    };
    if (state.editId) rec.id = state.editId;
    const id = await FarisDB.put(STORES.INV_ITEM_PRICINGS, rec);
    state.editId = id; state.savedNo = rec.no;
    state.lines = rec.lines;
    drawTable();
    Utils.toast(`تم حفظ التسعيرة رقم ${rec.no}`, 'success');
  }

  async function onSearch() {
    setMode('search');
    await drawSaved();
  }

  async function drawSaved() {
    const q = ($('ip-search-input').value || '').trim().toLowerCase();
    const list = Utils.newestFirst(await FarisDB.getAllRaw(STORES.INV_ITEM_PRICINGS))
      .filter(r => !q || [r.no, r.levelName, r.date].some(v => String(v ?? '').toLowerCase().includes(q)));
    $('ip-saved-rows').innerHTML = list.map(r => {
      const cur = data.curMap.get(r.currencyId);
      return `<tr data-id="${r.id}"><td>${esc(r.no)}</td><td>${esc(r.date)}</td><td>${esc(r.levelName)}</td>
        <td>${esc(cur ? cur.symbol : '')}</td><td>${esc(r.percent)}</td><td>${(r.lines || []).length}</td></tr>`;
    }).join('') || '<tr><td colspan="6" class="empty-row">لا توجد تسعيرات محفوظة</td></tr>';
    $('ip-saved-rows').querySelectorAll('tr[data-id]').forEach(tr => tr.addEventListener('click', () => openSaved(Number(tr.dataset.id))));
  }

  async function openSaved(id) {
    const r = await FarisDB.get(STORES.INV_ITEM_PRICINGS, id);
    if (!r) return;
    state.params = { method: r.method || 'manual', levelId: r.levelId, levelName: r.levelName, currencyId: r.currencyId,
      percent: r.percent, decimals: r.decimals, filters: r.filters || {} };
    state.lines = (r.lines || []).map(l => ({ ...l }));
    state.editId = r.id; state.savedNo = r.no; state.stockMap = null;
    setMode('table');
    drawTable();
  }

  async function onDelete() {
    if (state.editId) {
      const ok = await Utils.confirmDialog(`هل تريد حذف التسعيرة المحفوظة رقم ${esc(state.savedNo)}؟`);
      if (!ok) return;
      await FarisDB.remove(STORES.INV_ITEM_PRICINGS, state.editId);
      Utils.toast('تم حذف التسعيرة', 'success');
    } else if (state.lines.length) {
      const ok = await Utils.confirmDialog('سيتم مسح الأصناف المعروضة دون حفظ. هل تريد المتابعة؟');
      if (!ok) return;
    }
    state.params = null; state.lines = []; state.editId = null;
    setMode('idle');
  }

  /* ---------------- طباعة وتصدير واستيراد ---------------- */
  async function onPrint() {
    if (!state.lines.length) return;
    await ReportPrint.print(currentData());
  }

  async function onExport() {
    if (!state.lines.length) return;
    await ReportPrint.exportExcel(currentData());
  }

  // استيراد أرقام الأصناف من إكسل (العمود الأول) وإضافتها للجدول بنفس حساب الإضافة اليدوية
  async function onImportFile(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file || state.mode !== 'table' || !state.params) return;
    if (typeof XLSX === 'undefined') { Utils.toast('مكتبة قراءة إكسل غير متاحة (تتطلب اتصالًا بالإنترنت)', 'error'); return; }
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
      let added = 0, skipped = 0;
      for (const row of rows) {
        const code = String(row[0] ?? '').trim();
        if (!code || !data.itemMap.has(code)) { if (code) skipped++; continue; }
        if (state.lines.some(l => l.itemCode === code)) continue;
        const item = data.itemMap.get(code);
        if (!baseUnitOf(item)) { skipped++; continue; }
        if (!state.stockMap) state.stockMap = await buildStockMap(state.params.currencyId, null);
        state.lines.push(lineFromStock(item, state.stockMap.get(code), state.params));
        added++;
      }
      drawTable();
      Utils.toast(`تمت إضافة ${added} صنف${skipped ? `، وتخطي ${skipped} رقم غير موجود` : ''}`, added ? 'success' : 'info');
    } catch (err) {
      Utils.toast('تعذّرت قراءة الملف', 'error');
    }
  }

  return { render };
})();
