/* =========================================================
   FARIS ACCOUNTING - db.js
   طبقة قاعدة البيانات (IndexedDB) - المرحلة الأولى
   ========================================================= */

const DB_NAME = 'FarisAccountingDB';
const DB_VERSION = 11;

const STORES = {
  USERS: 'users',
  COUNTRIES: 'countries',
  GOVERNORATES: 'governorates',
  LOCATIONS: 'locations',
  CURRENCIES: 'currencies',
  SETTINGS: 'settings',
  BACKUP_SETTINGS: 'backupSettings',
  ACCOUNTS: 'accounts',
  CUSTOMERS: 'customers',
  CASHBOXES: 'cashboxes',
  BANKS: 'banks',
  SUPPLIERS: 'suppliers',
  SESSION: 'session',
  OPENING_BALANCES: 'openingBalances',
  JOURNAL: 'journalEntries',
  VOUCHERS: 'vouchers',
  CURRENCY_EXCHANGES: 'currencyExchanges',
  SALES: 'sales',
  SALES_RETURNS: 'salesReturns',
  PURCHASE_INVOICES: 'purchaseInvoices',
  PURCHASE_RETURNS: 'purchaseReturns',
  PURCHASE_DISCOUNTS: 'purchaseDiscounts',
  PURCHASE_SETTINGS: 'purchaseSettings',
  DISCOUNTS: 'discounts',
  INV_UNITS: 'invUnits',
  INV_PRICING_LEVELS: 'invPricingLevels',
  INV_ITEM_PRICINGS: 'invItemPricings',
  INV_GROUPS_MAIN: 'invGroupsMain',
  INV_GROUPS_SUB: 'invGroupsSub',
  INV_GROUPS_DETAIL: 'invGroupsDetail',
  INV_WAREHOUSES: 'invWarehouses',
  INV_WAREHOUSE_GROUPS: 'invWarehouseGroups',
  INV_GL_MAPPING: 'invGlMapping',
  INV_ITEMS: 'invItems',
  INV_OPENING_STOCK: 'invOpeningStock',
  INV_OPENING_STOCK_DOCS: 'invOpeningStockDocs',
  INV_SETTINGS: 'invSettings',
  SALES_SETTINGS: 'salesSettings',
  SALES_INVOICES: 'salesInvoices'
};

const FarisDB = (function () {
  let dbInstance = null;
  let writeGuard = null; // دالة حماية تمنع الكتابة في السنوات المقفلة (تُسجَّل من YearEnd)
  let bypassCount = 0;   // تجاوز الحماية أثناء عمليات النظام (الإقفال/فتح السنة/استعادة النسخة)

  let recordHook = null;   // مراجعة الاتزان والتكرار قبل كل كتابة (تُسجَّل من Posting)
  let restoring = 0;       // أثناء استعادة نسخة احتياطية لا تُطبَّق المراجعات
  const inflight = new Map(); // منع تكرار الحفظ المزدوج (ضغطتان متتاليتان) للحركات المحاسبية
  const DEDUPE_WINDOW_MS = 5000;
  const DEDUPE_STORES = new Set([
    STORES.OPENING_BALANCES, STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES,
    STORES.SALES_INVOICES, STORES.SALES_RETURNS, STORES.PURCHASE_INVOICES, STORES.PURCHASE_RETURNS,
    STORES.INV_OPENING_STOCK_DOCS
  ]);

  // ---- فصل السنوات المالية: كل قراءة للحركات تُرجع حركات سنة الجلسة فقط ----
  let scopeProvider = null; // يرجع { from, to } لسنة الجلسة (من YearEnd) أو null
  let rawDepth = 0;
  const SCOPED_STORES = new Set([
    STORES.OPENING_BALANCES, STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES,
    STORES.SALES, STORES.SALES_INVOICES, STORES.SALES_RETURNS, STORES.PURCHASE_INVOICES, STORES.PURCHASE_RETURNS,
    STORES.PURCHASE_DISCOUNTS, STORES.DISCOUNTS, STORES.INV_OPENING_STOCK, STORES.INV_OPENING_STOCK_DOCS
  ]);
  function setScopeProvider(fn) { scopeProvider = fn; }
  async function withoutScope(fn) {
    rawDepth++;
    try { return await fn(); } finally { rawDepth--; }
  }
  function applyScope(storeName, rows) {
    if (!scopeProvider || rawDepth > 0 || !SCOPED_STORES.has(storeName)) return rows;
    const r = scopeProvider();
    if (!r || (!r.from && !r.to)) return rows;
    return rows.filter(rec => {
      const d = rec && rec.date;
      if (!d) return true; // سجلات بلا تاريخ (مثل بعض سجلات المخزون المسطّحة) لا تُفلتر
      return (!r.from || d >= r.from) && (!r.to || d <= r.to);
    });
  }

  // ---- نافذة المخزون: حركات المخزون تُحسب من آخر ترحيل أرصدة افتتاحية (إقفال المخزون) ----
  let stockWindowProvider = null; // يرجع { from, to } أو null (بلا نافذة: كل الحركات تراكميًا)
  const STOCK_STORES = new Set([
    STORES.INV_OPENING_STOCK, STORES.INV_OPENING_STOCK_DOCS, STORES.SALES_INVOICES,
    STORES.SALES_RETURNS, STORES.PURCHASE_INVOICES, STORES.PURCHASE_RETURNS
  ]);
  function setStockWindowProvider(fn) { stockWindowProvider = fn; }

  async function applyStockWindow(storeName, rows) {
    if (!stockWindowProvider || !STOCK_STORES.has(storeName)) return rows;
    const w = stockWindowProvider();
    if (!w || (!w.from && !w.to)) return rows;
    // السجلات المسطّحة لمستندات المخزون الافتتاحي بلا تاريخ: تاريخها من مستندها
    let docDate = null;
    if (storeName === STORES.INV_OPENING_STOCK) {
      docDate = new Map((await getAllRaw(STORES.INV_OPENING_STOCK_DOCS)).map(d => [d.id, d.date]));
    }
    return rows.filter(rec => {
      let d = rec && rec.date;
      if (!d && docDate && rec.docId !== undefined) d = docDate.get(rec.docId);
      if (!d) return !w.from; // بلا تاريخ = أرصدة قديمة تتبع أول فترة فقط
      return (!w.from || d >= w.from) && (!w.to || d <= w.to);
    });
  }

  // ---- ذاكرة قراءة للتقارير: تمنع إعادة قراءة نفس الجدول عشرات المرات في تقرير واحد ----
  // تُمسح عند أي كتابة (إضافة/تعديل/حذف/استعادة) أو عند تغيّر نطاق السنة/نافذة المخزون (داخل المفتاح)
  const readCache = new Map();
  function clearReadCache() { readCache.clear(); }
  function cacheKey(kind, storeName) {
    let scope = '', win = '';
    try { scope = scopeProvider ? JSON.stringify(scopeProvider()) : ''; } catch (_) { /* تجاهل */ }
    try { win = stockWindowProvider ? JSON.stringify(stockWindowProvider()) : ''; } catch (_) { /* تجاهل */ }
    return `${kind}|${storeName}|${rawDepth > 0 ? 'raw' : scope}|${win}`;
  }
  async function cachedRead(kind, storeName, loader) {
    const key = cacheKey(kind, storeName);
    let p = readCache.get(key);
    if (!p) {
      p = loader();
      readCache.set(key, p);
      p.catch(() => readCache.delete(key));
    }
    return (await p).slice(); // نسخة سطحية حتى لا يعدّل المستدعي الترتيب المشترك
  }

  function setWriteGuard(fn) { writeGuard = fn; }
  function setRecordHook(fn) { recordHook = fn; }
  function isBypassed() { return bypassCount > 0; }

  // توقيع المحتوى (بدون الرقم الداخلي ورقم القيد) لاكتشاف إعادة إرسال نفس السجل
  function contentSignature(storeName, value) {
    const v = { ...value };
    delete v.id; delete v.createdAt;
    if (storeName === STORES.JOURNAL) delete v.entryNo;
    return storeName + '|' + JSON.stringify(v);
  }

  // سجل جديد مطابق تمامًا لسجل حُفظ قبل لحظات (ضغط مزدوج) يعيد نفس السجل دون تكرار
  async function dedupe(storeName, value, isNew, run) {
    if (!isNew || restoring || !DEDUPE_STORES.has(storeName) || !value || typeof value !== 'object') return run();
    const now = Date.now();
    for (const [k, e] of inflight) if (now - e.t > DEDUPE_WINDOW_MS) inflight.delete(k);
    const sig = contentSignature(storeName, value);
    const hit = inflight.get(sig);
    if (hit) return hit.p;
    const entry = { t: now, store: storeName, id: undefined, p: null };
    entry.p = run().then(id => { entry.id = id; return id; });
    entry.p.catch(() => inflight.delete(sig));
    inflight.set(sig, entry);
    return entry.p;
  }
  function forgetDeduped(storeName, key) {
    for (const [k, e] of inflight) if (e.store === storeName && e.id === key) inflight.delete(k);
  }
  async function withBypass(fn) {
    bypassCount++;
    try { return await fn(); } finally { bypassCount--; }
  }
  async function runGuard(storeName, value, key) {
    if (writeGuard && bypassCount === 0) await writeGuard(storeName, value, key);
  }

  function open() {
    return new Promise((resolve, reject) => {
      if (dbInstance) return resolve(dbInstance);

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains(STORES.USERS)) {
          const s = db.createObjectStore(STORES.USERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('userNumber', 'userNumber', { unique: true });
        }

        if (!db.objectStoreNames.contains(STORES.COUNTRIES)) {
          db.createObjectStore(STORES.COUNTRIES, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.GOVERNORATES)) {
          const s = db.createObjectStore(STORES.GOVERNORATES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('countryId', 'countryId', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.LOCATIONS)) {
          const s = db.createObjectStore(STORES.LOCATIONS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('countryId', 'countryId', { unique: false });
          s.createIndex('governorateId', 'governorateId', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.CURRENCIES)) {
          db.createObjectStore(STORES.CURRENCIES, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
          db.createObjectStore(STORES.SETTINGS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORES.BACKUP_SETTINGS)) {
          db.createObjectStore(STORES.BACKUP_SETTINGS, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORES.ACCOUNTS)) {
          const s = db.createObjectStore(STORES.ACCOUNTS, { keyPath: 'code' });
          s.createIndex('parentCode', 'parentCode', { unique: false });
          s.createIndex('rank', 'rank', { unique: false });
          s.createIndex('analyticType', 'analyticType', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.CUSTOMERS)) {
          const s = db.createObjectStore(STORES.CUSTOMERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.CASHBOXES)) {
          const s = db.createObjectStore(STORES.CASHBOXES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.BANKS)) {
          const s = db.createObjectStore(STORES.BANKS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.SUPPLIERS)) {
          const s = db.createObjectStore(STORES.SUPPLIERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('parentAccountCode', 'parentAccountCode', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.SESSION)) {
          db.createObjectStore(STORES.SESSION, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(STORES.OPENING_BALANCES)) {
          const s = db.createObjectStore(STORES.OPENING_BALANCES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('accountCode', 'accountCode', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.JOURNAL)) {
          db.createObjectStore(STORES.JOURNAL, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.VOUCHERS)) {
          const s = db.createObjectStore(STORES.VOUCHERS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('type', 'type', { unique: false });
        }

        if (!db.objectStoreNames.contains(STORES.CURRENCY_EXCHANGES)) {
          db.createObjectStore(STORES.CURRENCY_EXCHANGES, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.SALES)) {
          db.createObjectStore(STORES.SALES, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.SALES_RETURNS)) {
          db.createObjectStore(STORES.SALES_RETURNS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_INVOICES)) {
          db.createObjectStore(STORES.PURCHASE_INVOICES, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_RETURNS)) {
          db.createObjectStore(STORES.PURCHASE_RETURNS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_DISCOUNTS)) {
          db.createObjectStore(STORES.PURCHASE_DISCOUNTS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.PURCHASE_SETTINGS)) {
          db.createObjectStore(STORES.PURCHASE_SETTINGS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.DISCOUNTS)) {
          db.createObjectStore(STORES.DISCOUNTS, { keyPath: 'id', autoIncrement: true });
        }

        if (!db.objectStoreNames.contains(STORES.INV_UNITS)) {
          db.createObjectStore(STORES.INV_UNITS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_PRICING_LEVELS)) {
          db.createObjectStore(STORES.INV_PRICING_LEVELS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_ITEM_PRICINGS)) {
          db.createObjectStore(STORES.INV_ITEM_PRICINGS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GROUPS_MAIN)) {
          db.createObjectStore(STORES.INV_GROUPS_MAIN, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GROUPS_SUB)) {
          const s = db.createObjectStore(STORES.INV_GROUPS_SUB, { keyPath: 'id', autoIncrement: true });
          s.createIndex('mainGroupId', 'mainGroupId', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GROUPS_DETAIL)) {
          const s = db.createObjectStore(STORES.INV_GROUPS_DETAIL, { keyPath: 'id', autoIncrement: true });
          s.createIndex('subGroupId', 'subGroupId', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_WAREHOUSES)) {
          db.createObjectStore(STORES.INV_WAREHOUSES, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_ITEMS)) {
          const s = db.createObjectStore(STORES.INV_ITEMS, { keyPath: 'code' });
          s.createIndex('mainGroupId', 'mainGroupId', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_OPENING_STOCK)) {
          const s = db.createObjectStore(STORES.INV_OPENING_STOCK, { keyPath: 'id', autoIncrement: true });
          s.createIndex('itemCode', 'itemCode', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORES.INV_OPENING_STOCK_DOCS)) {
          db.createObjectStore(STORES.INV_OPENING_STOCK_DOCS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_SETTINGS)) {
          db.createObjectStore(STORES.INV_SETTINGS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.INV_WAREHOUSE_GROUPS)) {
          db.createObjectStore(STORES.INV_WAREHOUSE_GROUPS, { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains(STORES.INV_GL_MAPPING)) {
          db.createObjectStore(STORES.INV_GL_MAPPING, { keyPath: 'warehouseGroupId' });
        }
        if (!db.objectStoreNames.contains(STORES.SALES_SETTINGS)) {
          db.createObjectStore(STORES.SALES_SETTINGS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.SALES_INVOICES)) {
          const s = db.createObjectStore(STORES.SALES_INVOICES, { keyPath: 'id', autoIncrement: true });
          s.createIndex('customerId', 'customerId', { unique: false });
        }
      };

      request.onsuccess = (event) => {
        dbInstance = event.target.result;
        // إذا فُتح إصدار أحدث من قاعدة البيانات في تبويب آخر، نغلق هذا الاتصال القديم
        // فورًا حتى لا تُقرأ بيانات من نسخة قديمة أو تُحجب الترقية بصمت
        dbInstance.onversionchange = () => {
          dbInstance.close();
          dbInstance = null;
        };
        resolve(dbInstance);
      };

      request.onerror = (event) => {
        reject(event.target.error);
      };

      request.onblocked = () => {
        Utils.toast && Utils.toast('يوجد إصدار قديم من التطبيق مفتوح في تبويب آخر، يرجى إغلاقه ثم إعادة تحميل الصفحة', 'error');
      };
    });
  }

  function tx(storeName, mode = 'readonly') {
    return dbInstance.transaction(storeName, mode).objectStore(storeName);
  }

  // يضيف أعمدة المبالغ بالعملة المحلية (المبلغ × سعر صرف العملة) تلقائيًا للحركات المحاسبية
  async function enrichLocalAmounts(storeName, value) {
    const targets = [STORES.OPENING_BALANCES, STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES];
    if (!value || typeof value !== 'object' || !targets.includes(storeName)) return value;
    if (value.keepLocal === true) return value; // مبالغ محلية مرحَّلة كما هي (ترحيل الأرصدة لسنة جديدة)
    const currencies = await getAll(STORES.CURRENCIES);
    const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
    const rateOf = (currencyId, own) => {
      const cur = currencies.find(c => c.id === currencyId);
      if (!cur || cur.type === 'محلي') return 1;
      const r = Number(own) || Number(cur.rate) || 1;
      return r;
    };
    const conv = (amount, currencyId, own) => r2((Number(amount) || 0) * rateOf(currencyId, own));
    if (storeName === STORES.OPENING_BALANCES) {
      value.localDebit = conv(value.debit, value.currencyId);
      value.localCredit = conv(value.credit, value.currencyId);
    } else if (storeName === STORES.JOURNAL) {
      (value.lines || []).forEach(l => {
        const own = l.exchangeRate || l.rate;
        l.localDebit = conv(l.debit, l.currencyId, own);
        l.localCredit = conv(l.credit, l.currencyId, own);
      });
    } else if (storeName === STORES.VOUCHERS) {
      if (value.debitSide) { value.debitSide.localDebit = conv(value.debitSide.amount, value.debitSide.currencyId); value.debitSide.localCredit = 0; }
      if (value.creditSide) { value.creditSide.localCredit = conv(value.creditSide.amount, value.creditSide.currencyId); value.creditSide.localDebit = 0; }
      value.localDebit = value.debitSide ? value.debitSide.localDebit : 0;
      value.localCredit = value.creditSide ? value.creditSide.localCredit : 0;
    } else if (storeName === STORES.CURRENCY_EXCHANGES) {
      value.localCredit = conv(value.fromAmount, value.fromCurrencyId);
      value.localDebit = conv(value.toAmount, value.toCurrencyId);
    }
    return value;
  }

  async function runHook(storeName, value, key) {
    clearReadCache();
    if (recordHook && !restoring) await recordHook(storeName, value, key);
  }

  async function add(storeName, value) {
    await open();
    return dedupe(storeName, value, true, async () => {
      await runGuard(storeName, value, undefined);
      try { await enrichLocalAmounts(storeName, value); } catch (e) { /* تجاهل */ }
      await runHook(storeName, value, undefined);
      return new Promise((resolve, reject) => {
        const req = tx(storeName, 'readwrite').add(value);
        req.onsuccess = () => { clearReadCache(); resolve(req.result); };
        req.onerror = () => reject(req.error);
      });
    });
  }

  async function put(storeName, value) {
    await open();
    const isNew = !!value && typeof value === 'object' && value.id === undefined;
    return dedupe(storeName, value, isNew, async () => {
      await runGuard(storeName, value, value ? value.id : undefined);
      try { await enrichLocalAmounts(storeName, value); } catch (e) { /* تجاهل */ }
      await runHook(storeName, value, value ? value.id : undefined);
      return new Promise((resolve, reject) => {
        const req = tx(storeName, 'readwrite').put(value);
        req.onsuccess = () => { clearReadCache(); resolve(req.result); };
        req.onerror = () => reject(req.error);
      });
    });
  }

  async function get(storeName, key) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  // قراءة كل السجلات بلا فصل سنوات (للعمليات التراكمية: المخزون، النسخ الاحتياطي، فحص الحركة)
  async function getAllRaw(storeName) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAllByIndexRaw(storeName, indexName, value) {
    await open();
    return new Promise((resolve, reject) => {
      const idx = tx(storeName).index(indexName);
      const req = idx.getAll(value);
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  // قراءة حركات المخزون ضمن نافذة المخزون الحالية (لحساب الكميات والتكاليف)
  async function getAllStock(storeName) {
    return applyStockWindow(storeName, await getAllRaw(storeName));
  }
  async function getAllByIndexStock(storeName, indexName, value) {
    return applyStockWindow(storeName, await getAllByIndexRaw(storeName, indexName, value));
  }

  async function getAll(storeName) {
    return applyScope(storeName, await getAllRaw(storeName));
  }

  // نسخ مخزَّنة مؤقتًا للقراءة المتكررة داخل التقارير (للقراءة فقط؛ تُمسح مع أي كتابة)
  const getAllCached = (storeName) => cachedRead('scoped', storeName, () => getAll(storeName));
  const getAllRawCached = (storeName) => cachedRead('raw', storeName, () => getAllRaw(storeName));
  const getAllStockCached = (storeName) => cachedRead('stock', storeName, () => getAllStock(storeName));
  async function getAllByIndexStockCached(storeName, indexName, value) {
    return (await getAllStockCached(storeName)).filter(r => r[indexName] === value);
  }
  async function getAllByIndexCached(storeName, indexName, value) {
    return (await getAllCached(storeName)).filter(r => r[indexName] === value);
  }
  async function getAllByIndexRawCached(storeName, indexName, value) {
    return (await getAllRawCached(storeName)).filter(r => r[indexName] === value);
  }

  async function getAllByIndex(storeName, indexName, value) {
    return applyScope(storeName, await getAllByIndexRaw(storeName, indexName, value));
  }

  async function remove(storeName, key) {
    await open();
    await runGuard(storeName, null, key);
    forgetDeduped(storeName, key);
    clearReadCache();
    return new Promise((resolve, reject) => {
      const req = tx(storeName, 'readwrite').delete(key);
      req.onsuccess = () => { clearReadCache(); resolve(true); };
      req.onerror = () => reject(req.error);
    });
  }

  async function clearStore(storeName) {
    await open();
    return new Promise((resolve, reject) => {
      const req = tx(storeName, 'readwrite').clear();
      req.onsuccess = () => { clearReadCache(); resolve(true); };
      req.onerror = () => reject(req.error);
    });
  }

  /* -------- Seed data: الجذور الأربعة الثابتة للدليل المحاسبي -------- */
  async function seedIfNeeded() {
    const existing = await getAll(STORES.ACCOUNTS);
    if (existing.length > 0) return;

    const roots = [
      { code: '1', name: 'الأصول', rank: 1, type: 'رئيسي', nature: 'مدين', parentCode: null, fixed: true, currencies: [] },
      { code: '2', name: 'الخصوم', rank: 1, type: 'رئيسي', nature: 'دائن', parentCode: null, fixed: true, currencies: [] },
      { code: '3', name: 'المصروفات', rank: 1, type: 'رئيسي', nature: 'مدين', parentCode: null, fixed: true, currencies: [] },
      { code: '4', name: 'الإيرادات', rank: 1, type: 'رئيسي', nature: 'دائن', parentCode: null, fixed: true, currencies: [] }
    ];
    for (const r of roots) {
      await put(STORES.ACCOUNTS, r);
    }
  }

  /* -------- استيراد / تصدير النسخة الاحتياطية الكاملة -------- */
  async function exportAll() {
    await open();
    const dump = {};
    for (const key of Object.keys(STORES)) {
      dump[STORES[key]] = await getAllRaw(STORES[key]);
    }
    dump._meta = { app: 'faris-accounting', version: DB_VERSION, date: new Date().toISOString() };
    return dump;
  }

  async function importAll(dump) {
    await open();
    restoring++;
    try { await withBypass(async () => {
      for (const key of Object.keys(STORES)) {
        const storeName = STORES[key];
        if (!dump[storeName]) continue;
        await clearStore(storeName);
        for (const item of dump[storeName]) {
          await put(storeName, item);
        }
      }
    }); } finally { restoring--; }
  }

  return { open, add, put, get, getAll, getAllByIndex, remove, clearStore, seedIfNeeded, exportAll, importAll, setWriteGuard, withBypass, setRecordHook, isBypassed, setScopeProvider, withoutScope, getAllRaw, getAllByIndexRaw, setStockWindowProvider, getAllStock, getAllByIndexStock, getAllCached, getAllRawCached, getAllStockCached, getAllByIndexCached, getAllByIndexRawCached, getAllByIndexStockCached, clearReadCache };
})();
