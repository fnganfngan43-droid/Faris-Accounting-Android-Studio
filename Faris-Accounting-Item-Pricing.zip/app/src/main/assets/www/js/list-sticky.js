/* =========================================================
   تثبيت أعلى شاشات القوائم أثناء التمرير
   - الشريط العلوي والتبويبات (خارج منطقة التمرير) + شريط الأدوات + البحث تبقى ثابتة.
   - جدول العمليات المحفوظة هو الذي يتمرر (رأسيًا وأفقيًا) داخل ما تبقى من الشاشة،
     وعناوين الأعمدة تبقى ملتصقة بأعلاه (انظر .list-fit في style.css).
   يعمل تلقائيًا على كل شاشة فيها شريط أدوات ثم جدول مباشرة، ويُعاد حسابه عند تغيّر المحتوى أو حجم الشاشة.
   ========================================================= */

const ListSticky = (function () {
  const MIN_HEIGHT = 160;
  let scheduled = false;

  // هل يسبق الجدول (في نفس المستوى) شريط أدوات أو عنصر يحتوي شريط أدوات؟ (قائمة عمليات محفوظة)
  function hasToolbarBefore(table) {
    for (let p = table.previousElementSibling; p; p = p.previousElementSibling) {
      if (p.classList.contains('toolbar') || p.querySelector('.toolbar')) return true;
    }
    return false;
  }

  // مجموع ارتفاع المحتوى المرئي الذي يأتي بعد الجدول (ملاحظة أو إجمالي...) لنحجز له مكانًا فلا يُقص
  function trailingHeight(table, sub) {
    let total = 0;
    for (let node = table; node && node !== sub; node = node.parentElement) {
      for (let s = node.nextElementSibling; s; s = s.nextElementSibling) {
        const cs = getComputedStyle(s);
        if (cs.display === 'none' || cs.position === 'fixed' || cs.position === 'absolute') continue;
        const h = s.getBoundingClientRect().height;
        if (h > 0) total += h + (parseFloat(cs.marginTop) || 0) + (parseFloat(cs.marginBottom) || 0);
      }
    }
    return total;
  }

  // يرجع منطقة المحتوى التي طُبّق عليها التثبيت (أو null). لا يكتب إلا عند تغيّر القيم لتجنب حلقات المراقبة.
  function fitOne(table) {
    const sub = table.closest('.sub-content');
    if (!sub) return null;
    // لا نطبّق على الجداول المخفية أو التي لها ارتفاع خاص أو داخل النوافذ المنبثقة
    if (table.offsetParent === null || table.classList.contains('tall') || table.closest('.bottom-sheet, .popup-sheet')) return null;
    if (!hasToolbarBefore(table)) return null;
    const trailing = trailingHeight(table, sub);
    if (trailing > 150) return null; // بعد الجدول محتوى كبير (نموذج/أزرار): يبقى التمرير العادي
    const subRect = sub.getBoundingClientRect();
    const top = table.getBoundingClientRect().top;
    const padBottom = parseFloat(getComputedStyle(sub).paddingBottom) || 0;
    const available = Math.floor(subRect.bottom - top - padBottom - trailing - 2);
    // إن لم تتسع الشاشة لارتفاع معقول للجدول (مثل الوضع الأفقي أو نموذج مفتوح فوقه) يبقى التمرير العادي للصفحة
    if (available < MIN_HEIGHT) return null;
    const px = available + 'px';
    if (table.style.maxHeight !== px) table.style.maxHeight = px;
    if (!table.classList.contains('list-fit')) table.classList.add('list-fit');
    if (!sub.classList.contains('has-list-fit')) sub.classList.add('has-list-fit'); // التمرير للجدول لا للصفحة
    return sub;
  }

  function fitAll() {
    scheduled = false;
    const withFit = new Set();
    document.querySelectorAll('.sub-content .table-scroll').forEach(t => {
      const sub = fitOne(t);
      if (sub) withFit.add(sub);
      else if (t.classList.contains('list-fit')) { t.classList.remove('list-fit'); t.style.maxHeight = ''; } // لم يعد ينطبق (مثلًا فُتح نموذج)
    });
    // مناطق لم تعد تحتوي قائمة ظاهرة تعود لتمريرها العادي
    document.querySelectorAll('.sub-content.has-list-fit').forEach(sub => { if (!withFit.has(sub)) sub.classList.remove('has-list-fit'); });
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(fitAll);
  }

  function init() {
    const root = document.getElementById('app') || document.body;
    new MutationObserver(schedule).observe(root, {
      childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden']
    });
    window.addEventListener('resize', schedule);
    window.addEventListener('orientationchange', schedule);
    schedule();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  return { fitAll: schedule };
})();
