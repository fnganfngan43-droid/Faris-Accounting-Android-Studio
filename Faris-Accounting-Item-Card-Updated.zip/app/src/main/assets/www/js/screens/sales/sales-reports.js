/* تقارير المبيعات ومرتجعات المبيعات */
const SalesReports = (function () {
  let rows = [];
  let customers = [];
  let warehouses = [];
  let currencies = [];
  let lastReport = [];
  let lastDocuments = [];


  const today = () => new Date().toISOString().slice(0, 10);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num = v => Number(v) || 0;
  const docNo = d => d.invoiceNo ?? d.returnNo ?? d.documentNo ?? d.id ?? '';
  const docType = () => document.getElementById('sales-report-doc-type').value;

  async function render(container) {
    customers = await FarisDB.getAll(STORES.CUSTOMERS).catch(() => []);
    warehouses = await FarisDB.getAll(STORES.INV_WAREHOUSES).catch(() => []);
    currencies = await FarisDB.getAll(STORES.CURRENCIES).catch(() => []);

    container.innerHTML = `
      <section class="card report-card">
        <div class="toolbar" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
          <button type="button" class="btn btn-primary" id="sales-report-show">🔎 عرض التقرير</button>
          <button type="button" class="btn btn-secondary" id="sales-report-print">🖨️ الطباعة</button>
          <button type="button" class="btn btn-secondary" id="sales-report-import">📥 استيراد إكسل</button>
          <input type="file" id="sales-report-file" accept=".xlsx,.xls,.csv" hidden>
        </div>
        <div class="form-grid">
          <label>نوع المستند
            <select id="sales-report-doc-type"><option value="sales">تقارير المبيعات</option><option value="returns">تقارير مرتجع المبيعات</option></select>
          </label>
          <label>نوع التقرير
            <select id="sales-report-kind"><option value="summary">إجمالي</option><option value="detail">تحريري</option></select>
          </label>
          <label>من تاريخ<input type="date" id="sales-report-date-from"></label>
          <label>إلى تاريخ<input type="date" id="sales-report-date-to" value="${today()}"></label>
          <label>من حساب
            <input id="sales-report-account-from" list="sales-report-account-list" placeholder="ابحث برقم الحساب أو الاسم" autocomplete="off">
          </label>
          <label>إلى حساب
            <input id="sales-report-account-to" list="sales-report-account-list" placeholder="ابحث برقم الحساب أو الاسم" autocomplete="off">
          </label>
          <datalist id="sales-report-account-list"></datalist>
          <label>من مخزن
            <select id="sales-report-warehouse-from"><option value="">كل المخازن</option></select>
          </label>
          <label>إلى مخزن
            <select id="sales-report-warehouse-to"><option value="">كل المخازن</option></select>
          </label>
          <label>من رقم
            <input type="text" id="sales-report-no-from" inputmode="numeric" placeholder="من رقم المستند">
          </label>
          <label>إلى رقم
            <input type="text" id="sales-report-no-to" inputmode="numeric" placeholder="إلى رقم المستند">
          </label>
        </div>
        <p class="hint" id="sales-report-status" aria-live="polite"></p>
      </section>
      <section id="sales-report-results" class="card" style="margin-top:12px"><p class="hint">حدد خيارات التقرير ثم اضغط «عرض التقرير».</p></section>`;

    const accountList = document.getElementById('sales-report-account-list');
    accountList.innerHTML = customers.map(c => `<option value="${esc(c.code ?? c.accountNo ?? c.number ?? c.id)} - ${esc(c.name)}"></option>`).join('');
    const whOptions = warehouses.map(w => `<option value="${esc(w.id)}">${esc(w.name || w.warehouseName || w.code || w.id)}</option>`).join('');
    document.getElementById('sales-report-warehouse-from').insertAdjacentHTML('beforeend', whOptions);
    document.getElementById('sales-report-warehouse-to').insertAdjacentHTML('beforeend', whOptions);
    document.getElementById('sales-report-show').addEventListener('click', showReport);
    document.getElementById('sales-report-print').addEventListener('click', printReport);
    document.getElementById('sales-report-import').addEventListener('click', () => document.getElementById('sales-report-file').click());
    document.getElementById('sales-report-file').addEventListener('change', importExcel);
  }

  function accountMatches(value, doc) {
    if (!value.trim()) return true;
    const term = value.trim().toLowerCase();
    const customer = customers.find(c => String(c.id) === String(doc.customerId));
    const fields = [doc.customerName, customer?.name, customer?.code, customer?.accountNo, customer?.number, doc.customerId].map(x => String(x ?? '').toLowerCase());
    return fields.some(x => x.includes(term) || (term.includes(' - ') && x.includes(term.split(' - ')[0].trim())));
  }
  function showReport() {
    const type = docType();
    const source = type === 'returns' ? STORES.SALES_RETURNS : STORES.SALES_INVOICES;
    FarisDB.getAll(source).then(docs => {
      const fromDate = document.getElementById('sales-report-date-from').value;
      const toDate = document.getElementById('sales-report-date-to').value;
      const accountFrom = document.getElementById('sales-report-account-from').value;
      const accountTo = document.getElementById('sales-report-account-to').value;
      const whFrom = document.getElementById('sales-report-warehouse-from').value;
      const whTo = document.getElementById('sales-report-warehouse-to').value;
      const noFrom = document.getElementById('sales-report-no-from').value.trim();
      const noTo = document.getElementById('sales-report-no-to').value.trim();
      const filtered = docs.filter(d => {
        const n = String(docNo(d));
        const warehousesInDoc = [...new Set([d.warehouseId, ...(d.lines || []).map(l => l.warehouseId)].filter(x => x != null).map(String))];
        if (fromDate && String(d.date || '') < fromDate) return false;
        if (toDate && String(d.date || '') > toDate) return false;
        const account = customers.find(c => String(c.id) === String(d.customerId));
        const accountCode = String(account?.code ?? account?.accountNo ?? account?.number ?? account?.id ?? d.customerId ?? '');
        const resolveAccount = value => {
          const term = value.trim().toLowerCase();
          if (!term) return null;
          return customers.find(c => [c.code, c.accountNo, c.number, c.id].some(v => String(v ?? '').toLowerCase() === term.split(' - ')[0].trim()) || String(c.name || '').toLowerCase() === term);
        };
        const fromAccount = resolveAccount(accountFrom);
        const toAccount = resolveAccount(accountTo);
        if (fromAccount || toAccount) {
          const fromCode = fromAccount ? String(fromAccount.code ?? fromAccount.accountNo ?? fromAccount.number ?? fromAccount.id) : '';
          const toCode = toAccount ? String(toAccount.code ?? toAccount.accountNo ?? toAccount.number ?? toAccount.id) : '';
          if (fromCode && accountCode.localeCompare(fromCode, undefined, {numeric:true}) < 0) return false;
          if (toCode && accountCode.localeCompare(toCode, undefined, {numeric:true}) > 0) return false;
        } else if (!accountMatches(accountFrom, d) || !accountMatches(accountTo, d)) return false;
        if (whFrom && !warehousesInDoc.some(x => x === whFrom)) return false;
        if (whTo && !warehousesInDoc.some(x => x === whTo)) return false;
        if (noFrom && n.localeCompare(noFrom, undefined, {numeric:true}) < 0) return false;
        if (noTo && n.localeCompare(noTo, undefined, {numeric:true}) > 0) return false;
        return true;
      }).sort((a,b) => String(a.date || '').localeCompare(String(b.date || '')) || String(docNo(a)).localeCompare(String(docNo(b)), undefined, {numeric:true}));
      const detail = document.getElementById('sales-report-kind').value === 'detail';
      lastDocuments = filtered;
      lastReport = [];
      if (detail) {
        filtered.forEach(d => (d.lines || []).forEach(l => lastReport.push({date:d.date, no:docNo(d), customer:d.customerName || '', warehouse: warehouseName(l.warehouseId || d.warehouseId), itemCode:l.itemCode || l.code || '', itemName:l.itemName || l.name || '', qty:num(l.qty), price:num(l.price), total:num(l.total) || num(l.qty)*num(l.price)})));
      } else {
        // التقرير الإجمالي: التاريخ، رقم الفاتورة، رقم الحساب، اسم الحساب، العملة، المبلغ، رقم المرجع
        lastReport = filtered.map(d => {
          const account = customers.find(c => String(c.id) === String(d.customerId));
          return {
            date: d.date,
            no: docNo(d),
            accountNo: account ? String(account.code ?? account.accountNo ?? account.number ?? account.id ?? '') : '',
            customer: d.customerName || (account ? account.name : ''),
            currency: accountCurrencySymbol(d, account),
            total: num(d.net) || (d.lines || []).reduce((s,l)=>s+(num(l.total)||num(l.qty)*num(l.price)),0),
            reference: d.reference || ''
          };
        });
      }
      renderResults(detail);
      document.getElementById('sales-report-status').textContent = `عدد المستندات: ${filtered.length} — عدد الصفوف: ${lastReport.length}`;
    }).catch(err => { document.getElementById('sales-report-status').textContent = 'تعذر تحميل التقرير: ' + (err.message || err); });
  }
  function currencyOf(id) { const c = currencies.find(x => String(x.id) === String(id)); return c ? (c.symbol || c.name || '') : ''; }
  // عمود العملة: رمز العملة المختارة للحساب (أو عملة المستند إن كانت مسجّلة فيه)
  function accountCurrencySymbol(doc, account) {
    const candidates = [doc && doc.currencyId, account && account.defaultCurrency, account && Array.isArray(account.currencies) ? account.currencies[0] : null];
    for (const id of candidates) {
      if (id === null || id === undefined || id === '') continue;
      const symbol = currencyOf(id);
      if (symbol) return symbol;
    }
    return String((doc && (doc.currencySymbol || doc.currency)) || '');
  }
  function warehouseName(id) { const w = warehouses.find(x => String(x.id) === String(id)); return w ? (w.name || w.warehouseName || w.code || '') : ''; }

  function renderResults(detail) {
    const result = document.getElementById('sales-report-results');
    if (!lastReport.length) { result.innerHTML = '<p class="hint">لا توجد بيانات مطابقة للفلاتر المحددة.</p>'; return; }
    const docNoLabel = docType() === 'returns' ? 'رقم المرتجع' : 'رقم الفاتورة';
    const headers = detail ? ['التاريخ','رقم المستند','اسم الحساب','المخزن','رقم الصنف','اسم الصنف','الكمية','سعر الوحدة','الإجمالي'] : ['التاريخ',docNoLabel,'رقم الحساب','اسم الحساب','العملة','المبلغ','رقم المرجع'];
    result.innerHTML = `<div class="table-scroll"><table class="data-table"><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${lastReport.map(r => detail
      ? `<tr><td>${esc(r.date)}</td><td>${esc(r.no)}</td><td>${esc(r.customer)}</td><td>${esc(r.warehouse)}</td><td>${esc(r.itemCode)}</td><td>${esc(r.itemName)}</td><td>${esc(r.qty)}</td><td>${esc(r.price)}</td><td>${esc(r.total.toFixed ? r.total.toFixed(2) : r.total)}</td></tr>`
      : `<tr><td>${esc(r.date)}</td><td>${esc(r.no)}</td><td>${esc(r.accountNo)}</td><td>${esc(r.customer)}</td><td>${esc(r.currency)}</td><td>${esc(Number(r.total).toFixed(2))}</td><td>${esc(r.reference)}</td></tr>`).join('')}</tbody><tfoot><tr><th colspan="${detail?6:5}">الإجمالي</th>${detail?`<th>${lastReport.reduce((s,r)=>s+num(r.qty),0)}</th><th></th>`:''}<th>${lastReport.reduce((s,r)=>s+num(r.total),0).toFixed(2)}</th>${detail?'':'<th></th>'}</tr></tfoot></table></div>`;
  }
  async function printReport() {
    const detail = document.getElementById('sales-report-kind').value === 'detail';
    if (!lastReport.length) { Utils.toast('اعرض التقرير أولاً قبل الطباعة', 'error'); return; }
    const title = docType() === 'returns' ? 'فاتورة مرتجع مبيعات' : 'فاتورة مبيعات';
    const settings = await FarisDB.get(STORES.SETTINGS, 'main').catch(() => null) || {};
    const arLines = [settings.arLine1, settings.arLine2, settings.arLine3].filter(Boolean);
    const enLines = [settings.enLine1, settings.enLine2, settings.enLine3].filter(Boolean);
    const logo = settings.logo ? `<img class="letterhead-logo" src="${settings.logo}" alt="شعار المنشأة">` : '';
    const letterhead = `<header class="letterhead"><div class="letterhead-row"><div class="letterhead-ar">${arLines.map(x => `<div>${esc(x)}</div>`).join('')}</div><div class="letterhead-logo-wrap">${logo}</div><div class="letterhead-en" dir="ltr">${enLines.map(x => `<div>${esc(x)}</div>`).join('')}</div></div><h2>${esc(title)}</h2></header>`;
    let pages = '';
    if (detail) {
      // التقرير التحريري: صفحة مستقلة لكل فاتورة مع ترويسة المنشأة في كل صفحة.
      pages = lastDocuments.map((d, index) => {
        const lines = d.lines || [];
        const customer = d.customerName || customers.find(c => String(c.id) === String(d.customerId))?.name || '';
        const wh = warehouseName(d.warehouseId);
        const customerRecord = customers.find(c => String(c.id) === String(d.customerId));
        const invoiceDate = String(d.date || '');
        const previousSales = lastDocuments.filter(prev => String(prev.customerId) === String(d.customerId) && (String(prev.date || '') < invoiceDate || (String(prev.date || '') === invoiceDate && String(docNo(prev)).localeCompare(String(docNo(d)), undefined, {numeric:true}) < 0))).reduce((sum, prev) => sum + (num(prev.net) || (prev.lines || []).reduce((a, l) => a + (num(l.total) || num(l.qty) * num(l.price)) - num(l.discount), 0)), 0);
        const openingBalance = num(customerRecord?.openingBalance ?? customerRecord?.balanceBroughtForward ?? customerRecord?.previousBalance);
        const previousBalance = openingBalance + previousSales;
        const lineRows = lines.map((l, i) => {
          const qty = num(l.qty), price = num(l.price), discount = num(l.discount);
          const total = num(l.total) || qty * price - discount;
          return `<tr><td>${i + 1}</td><td>${esc(l.itemCode || l.code || '')}</td><td>${esc(l.itemName || l.name || '')}</td><td>${esc(l.unitName || l.unit || l.unitLabel || '')}</td><td>${esc(qty)}</td><td>${price.toFixed(2)}</td><td>${discount.toFixed(2)}</td><td>${total.toFixed(2)}</td></tr>`;
        }).join('');
        const gross = lines.reduce((sum,l) => sum + (num(l.total) || num(l.qty)*num(l.price)), 0);
        const discountTotal = num(d.discount) || lines.reduce((sum,l) => sum + num(l.discount), 0);
        const net = num(d.net) || (gross - discountTotal);
        const customerBalance = previousBalance + net;
        return `<section class="print-page">${letterhead}<div class="invoice-body">
          <div class="invoice-meta"><strong>رقم الفاتورة: ${esc(docNo(d))}</strong><strong>نوع الفاتورة: ${esc(d.invoiceType || d.type || (docType()==='returns'?'مرتجع مبيعات':'مبيعات'))}</strong><span>التاريخ: ${esc(d.date || '')}</span></div>
          <div class="invoice-meta"><strong>اسم العميل: ${esc(customer)}</strong><span>المخزن: ${esc(wh)}</span><span>العملة: ${esc(accountCurrencySymbol(d, customerRecord))}</span></div>
          <table class="data-table invoice-table"><thead><tr><th>م</th><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>الكمية</th><th>السعر</th><th>الخصم</th><th>الإجمالي</th></tr></thead><tbody>${lineRows || '<tr><td colspan="8">لا توجد أصناف</td></tr>'}</tbody></table>
          <div class="invoice-summary"><div class="balance-side"><p><strong>الرصيد السابق للعميل:</strong> ${previousBalance.toFixed(2)}</p><p><strong>رصيد العميل:</strong> ${customerBalance.toFixed(2)}</p></div><div class="totals-side"><p><strong>إجمالي الفاتورة:</strong> ${gross.toFixed(2)}</p><p><strong>إجمالي الخصم:</strong> ${discountTotal.toFixed(2)}</p><p><strong>صافي الفاتورة:</strong> ${net.toFixed(2)}</p></div></div></div>
          <footer class="invoice-footer"><span>طبع بواسطة: ${esc(settings.printedBy || settings.userName || '')}</span><span>تاريخ الطباعة: ${new Date().toLocaleString('ar')}</span></footer>
        </section>`;
      }).join('');
    } else {
      const content = document.getElementById('sales-report-results').innerHTML;
      pages = `<section class="print-page">${letterhead}${content}</section>`;
    }
    const printHtml = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>
      @page{size:A4 portrait;margin:0}
      *{box-sizing:border-box}html,body{margin:0;padding:0;font-family:Arial,sans-serif;direction:rtl;color:#111}
      .print-page{width:210mm;height:297mm;padding:10mm;border:1.2mm solid #333;margin:0;page-break-after:always;break-after:page;overflow:hidden;position:relative}
      .print-page:last-child{page-break-after:auto;break-after:auto}.letterhead{border:1px solid #444;border-radius:7px;padding:5mm;margin-bottom:5mm;min-height:32mm}
      .letterhead-row{display:grid;grid-template-columns:1fr 25mm 1fr;align-items:center;gap:4mm}.letterhead-ar{text-align:right;font-weight:bold}.letterhead-en{text-align:left;font-weight:bold}.letterhead-logo-wrap{text-align:center}.letterhead-logo{width:24mm;height:24mm;max-width:24mm;max-height:24mm;object-fit:cover;border-radius:50%;border:1px solid #777;overflow:hidden}
      .letterhead h2{text-align:center;margin:4mm 0 0;font-size:16px}.invoice-body{border:1px solid #555;padding:2mm;margin-top:3mm}.invoice-meta{display:flex;justify-content:space-between;gap:5mm;flex-wrap:wrap;margin:0;padding:3mm;border:0;font-size:12px}.data-table{width:100%;border-collapse:collapse;table-layout:auto}.data-table{border:1.2px solid #333}.data-table th,.data-table td{border:1px solid #555;padding:5px;text-align:right;font-size:10px;overflow-wrap:anywhere}.invoice-table{border:1.5px solid #222}.invoice-table th,.invoice-table td{border:1px solid #333}.data-table th{background:#d9eef5}thead{display:table-header-group}tr{break-inside:avoid;page-break-inside:avoid}.invoice-summary{display:grid;grid-template-columns:1fr 1fr;gap:8mm;margin-top:0;padding:3mm;border:0;font-size:12px;min-height:27mm}.invoice-summary p{margin:2mm 0;padding:2mm;border-bottom:1px solid #ddd}.balance-side{grid-column:2;grid-row:1}.totals-side{grid-column:1;grid-row:1}.totals-side p,.balance-side p{border-bottom:1px solid #aaa}.invoice-footer{position:absolute;bottom:8mm;left:10mm;right:10mm;border-top:1px solid #aaa;padding-top:3mm;display:flex;justify-content:space-between;font-size:10px}
      @media screen{body{background:#eee}.print-page{background:white;margin:10px auto;box-shadow:0 1px 5px #aaa}}
    </style></head><body>${pages}</body></html>`;
    await Utils.printHtml(title, printHtml);
  }
  function importExcel(event) {
    const file = event.target.files?.[0]; if (!file) return;
    if (!window.XLSX) { Utils.toast('مكتبة Excel غير متاحة. يمكن عرض التقرير وطباعته بدونها.', 'error'); event.target.value=''; return; }
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const wb = XLSX.read(e.target.result, {type:'array'});
        const data = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], {defval:''});
        document.getElementById('sales-report-status').textContent = `تمت قراءة ${data.length} صفًا من ملف Excel. الاستيراد هنا للمعاينة فقط ولا يغيّر فواتير قاعدة البيانات.`;
        const result = document.getElementById('sales-report-results');
        if (!data.length) { result.innerHTML='<p class="hint">الملف لا يحتوي على صفوف بيانات.</p>'; return; }
        const cols = Object.keys(data[0]);
        result.innerHTML = `<div class="table-scroll"><table class="data-table"><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${data.map(row=>`<tr>${cols.map(c=>`<td>${esc(row[c])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
      } catch (err) { Utils.toast('تعذر قراءة ملف Excel', 'error'); }
      event.target.value='';
    };
    reader.readAsArrayBuffer(file);
  }
  return { render };
})();
