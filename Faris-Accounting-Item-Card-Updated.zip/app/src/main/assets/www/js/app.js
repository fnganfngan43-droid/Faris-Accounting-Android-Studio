/* =========================================================
   FARIS ACCOUNTING - app.js
   المسيّر الرئيسي للشاشات (Router) وبدء تشغيل التطبيق
   ========================================================= */

const App = (function () {
  const stack = []; // مكدس التنقل بين الشاشات الرئيسية (لزر الرجوع للخلف بالجهاز)

  const screens = {}; // screenName -> { onShow, onHide }

  function register(name, handlers) {
    screens[name] = handlers || {};
  }

  function show(name, opts = {}) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
    const target = document.getElementById(`screen-${name}`);
    if (!target) {
      console.error('Screen not found:', name);
      return;
    }
    target.classList.add('active');

    if (!opts.replace) {
      stack.push(name);
    } else if (stack.length) {
      stack[stack.length - 1] = name;
    } else {
      stack.push(name);
    }

    if (screens[name] && typeof screens[name].onShow === 'function') {
      screens[name].onShow(opts.params || {});
    }
  }

  function back() {
    if (stack.length > 1) {
      stack.pop();
      const prev = stack[stack.length - 1];
      show(prev, { replace: true });
    }
  }

  // زر رجوع الجهاز (Android hardware/gesture back)
  window.addEventListener('popstate', () => {
    back();
  });

  async function bootstrap() {
    await FarisDB.open();
    await FarisDB.seedIfNeeded();

    ScreenWelcome.init();
    ScreenHome.init();
    ScreenSetup.init();
    ScreenChart.init();
    ScreenOperations.init();
    ScreenReports.init();
    ScreenInventory.init();
    ScreenSales.init();
    ScreenPurchases.init();

    show('welcome');

    // التحقق من النسخ الاحتياطي التلقائي (كل 12 ساعة) عند فتح التطبيق
    SetupBackup.checkAutoBackup();
  }

  document.addEventListener('DOMContentLoaded', bootstrap);

  return { register, show, back };
})();
