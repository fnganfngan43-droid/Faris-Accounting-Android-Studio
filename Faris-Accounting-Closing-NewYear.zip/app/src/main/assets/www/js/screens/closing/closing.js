/* =========================================================
   شاشة المطابقة والترحيلات - الحاوية وشريط التنقل بين تبويباتها
   (إقفال / فتح سنة جديدة)
   ========================================================= */

const ScreenClosing = (function () {

  const tabs = [
    { key: 'close', label: 'إقفال', icon: '🔒', render: (c) => ClosingTab.render(c) },
    { key: 'newyear', label: 'فتح سنة جديدة', icon: '📅', render: (c) => NewYearTab.render(c) }
  ];

  let activeTab = null;

  function init() {
    App.register('closing', { onShow });

    document.getElementById('closing-back-home').addEventListener('click', () => App.show('home', { replace: true }));

    const nav = document.getElementById('closing-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });
  }

  function onShow() {
    selectTab(activeTab || 'close');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#closing-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('closing-content');
    content.innerHTML = '';
    tab.render(content);
  }

  return { init };
})();
