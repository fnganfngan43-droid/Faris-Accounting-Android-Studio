/* =========================================================
   تبويب فتح سنة جديدة
   ========================================================= */

const NewYearTab = (function () {
  const $ = (id) => document.getElementById(id);

  async function render(container) {
    await YearEnd.refresh();
    const cfg = YearEnd.getCfg();
    if (!cfg || !cfg.periods || !cfg.periods.length) {
      container.innerHTML = '<p class="hint">يجب إعداد فترات النظام من شاشة التهيئة أولًا.</p>';
      return;
    }
    const readOnly = YearEnd.isReadOnlySession() || YearEnd.getSessionYear() !== Number(cfg.year);
    const range = YearEnd.yearRange(cfg);
    const years = YearEnd.getYears().sort((a, b) => b.year - a.year);

    container.innerHTML = `
      ${readOnly ? `<p class="hint year-lock-note">🔒 أنت داخل سنة مقفلة (${YearEnd.getSessionYear()}) — العرض فقط. ادخل إلى السنة المالية الحالية ${cfg.year} من شاشة الترحيب لفتح سنة جديدة.</p>` : ''}
      <div class="info-card">
        <div class="info-row"><span>السنة المالية الحالية</span><b>${cfg.year}</b></div>
        <div class="info-row"><span>فترة السنة</span><b>${YearEnd.fmtDate(range.from)} ← ${YearEnd.fmtDate(range.to)}</b></div>
        <div class="info-row"><span>السنة الجديدة</span><b>${Number(cfg.year) + 1}</b></div>
      </div>
      <p class="hint">عند فتح السنة الجديدة تُنقل الأرصدة النهائية كأرصدة افتتاحية للسنة الجديدة، وتبقى بيانات السنة السابقة كما هي للعرض والتقارير فقط دون إمكانية إجراء أي عملية عليها.</p>
      <div class="toolbar" style="margin-top:12px;">
        <button class="btn btn-ghost" id="ny-preview">👁️ معاينة الأرصدة المرحّلة</button>
        <button class="btn btn-primary" id="ny-open" ${readOnly ? 'disabled' : ''}>📅 فتح سنة جديدة</button>
      </div>
      <div id="ny-box"></div>
      <h4 class="section-title">السنوات المقفلة</h4>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>السنة</th><th>من</th><th>إلى</th><th>أرصدة مرحّلة</th><th>تاريخ الإقفال</th></tr></thead>
          <tbody>
            ${years.map(y => `<tr><td>${y.year}</td><td>${YearEnd.fmtDate(y.from)}</td><td>${YearEnd.fmtDate(y.to)}</td><td>${y.carriedBalances ?? ''}</td><td>${YearEnd.fmtDate((y.closedAt || '').slice(0, 10))}</td></tr>`).join('') || '<tr><td colspan="5" class="empty-row">لا توجد سنوات مقفلة بعد</td></tr>'}
          </tbody>
        </table>
      </div>
    `;

    $('ny-preview').addEventListener('click', () => onPreview(container));
    $('ny-open').addEventListener('click', () => onOpen(container));
  }

  function pendingHtml(pending) {
    return `<div class="result-card warn">⚠️ لا تزال هناك أرصدة في حسابات الأرباح والخسائر لم تُقفل (${pending.length} رصيد). نفّذ الإقفال السنوي من تبويب "إقفال" أولًا.
      <div class="table-scroll" style="margin-top:8px;"><table class="data-table"><thead><tr><th>رقم الحساب</th><th>اسم الحساب</th><th>الرصيد</th></tr></thead><tbody>
      ${pending.slice(0, 50).map(r => `<tr><td>${Utils.escapeHtml(r.accountCode)}</td><td>${Utils.escapeHtml(r.accountName)}</td><td>${Math.abs(r.net).toFixed(2)} ${r.net > 0 ? 'مدين' : 'دائن'}</td></tr>`).join('')}
      </tbody></table></div></div>`;
  }

  async function onPreview() {
    const box = $('ny-box');
    box.innerHTML = '<p class="hint">جاري الحساب...</p>';
    try {
      const pending = await YearEnd.pendingPLBalances();
      const rows = await YearEnd.computeCarryOver();
      const curs = await FarisDB.getAll(STORES.CURRENCIES);
      const sym = (id) => { const c = curs.find(x => x.id === id); return c ? c.symbol : ''; };
      const totalD = rows.reduce((s, r) => s + (r.net > 0 ? Math.abs(r.localNet) : 0), 0);
      const totalC = rows.reduce((s, r) => s + (r.net < 0 ? Math.abs(r.localNet) : 0), 0);
      const diff = Math.round((totalD - totalC) * 100) / 100;

      box.innerHTML = `
        ${pending.length ? pendingHtml(pending) : ''}
        <div class="result-card ${Math.abs(diff) > 0.01 ? 'warn' : 'ok'}">
          عدد الأرصدة المرحّلة: ${rows.length}<br>
          إجمالي المدين (محلي): ${totalD.toFixed(2)} — إجمالي الدائن (محلي): ${totalC.toFixed(2)}
          ${Math.abs(diff) > 0.01 ? `<br>⚠️ يوجد فرق ${diff.toFixed(2)} بين المدين والدائن — راجع ميزان المراجعة قبل فتح السنة.` : ''}
        </div>
        <div class="table-scroll tall"><table class="data-table">
          <thead><tr><th>رقم الحساب</th><th>اسم الحساب</th><th>الحساب التحليلي</th><th>العملة</th><th>مدين</th><th>دائن</th></tr></thead>
          <tbody>${rows.map(r => `<tr><td>${Utils.escapeHtml(r.accountCode)}</td><td>${Utils.escapeHtml(r.accountName)}</td><td>${Utils.escapeHtml(r.analyticName)}</td><td>${Utils.escapeHtml(sym(r.currencyId))}</td><td>${r.net > 0 ? r.net.toFixed(2) : ''}</td><td>${r.net < 0 ? Math.abs(r.net).toFixed(2) : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="empty-row">لا توجد أرصدة للترحيل</td></tr>'}</tbody>
        </table></div>`;
    } catch (err) {
      box.innerHTML = '';
      Utils.toast(err.message || 'تعذّرت المعاينة', 'error');
    }
  }

  async function onOpen(container) {
    const cfg = YearEnd.getCfg();
    const ok = await Utils.confirmDialog(
      `سيتم فتح السنة المالية ${Number(cfg.year) + 1} ونقل الأرصدة النهائية للسنة ${cfg.year} كأرصدة افتتاحية، وستُقفل السنة ${cfg.year} بحيث لا يمكن إجراء أي عملية فيها (العرض والتقارير فقط). هل تريد المتابعة؟`
    );
    if (!ok) return;

    const btn = $('ny-open');
    btn.disabled = true;
    try {
      const res = await YearEnd.openNewYear();
      Utils.toast(`تم فتح السنة ${res.newYear} وترحيل ${res.carried} رصيد`, 'success');
      if (window.ScreenHome && ScreenHome.refreshBanner) ScreenHome.refreshBanner();
      await render(container);
      $('ny-box').innerHTML = `<div class="result-card ok">✅ تم فتح السنة المالية ${res.newYear}، وتم ترحيل ${res.carried} رصيد كأرصدة افتتاحية. السنة ${res.oldYear} أصبحت مقفلة للعرض فقط.</div>`;
    } catch (err) {
      Utils.toast(err.message || 'تعذّر فتح السنة الجديدة', 'error');
      if (err.code === 'PENDING_PL') {
        try { $('ny-box').innerHTML = pendingHtml(await YearEnd.pendingPLBalances()); } catch (_) { /* تجاهل */ }
      }
      btn.disabled = false;
    }
  }

  return { render };
})();
