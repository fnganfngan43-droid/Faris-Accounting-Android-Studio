/* =========================================================
   تبويب الإقفال (شهري / سنوي)
   ========================================================= */

const ClosingTab = (function () {
  let mains = [];
  let subs = [];
  let currencies = [];
  let periods = [];

  const $ = (id) => document.getElementById(id);
  const byCode = (a, b) => String(a.code).localeCompare(String(b.code));

  // حقل بحث بالرقم أو الاسم (مع خيار "الكل" اختياريًا)
  function bindSearch(prefix, getList, withAll) {
    const input = $(`${prefix}-input`);
    const list = $(`${prefix}-list`);
    const hidden = $(`${prefix}-code`);
    if (withAll) { input.value = 'الكل'; hidden.value = ''; input.dataset.valid = '1'; }

    Utils.attachAutocomplete(input, list, (q) => {
      const query = q === 'الكل' ? '' : q;
      let items = getList()
        .filter(a => !query || String(a.code).includes(query) || a.name.includes(query))
        .map(a => ({ value: a.code, label: `${a.code} - ${a.name}`, displayValue: `${a.code} - ${a.name}` }));
      if (withAll && (!query || 'الكل'.includes(query))) items = [{ value: '', label: 'الكل', displayValue: 'الكل' }, ...items];
      return items;
    }, (item) => {
      hidden.value = item.value;
      input.dataset.valid = '1';
    });

    input.addEventListener('input', () => { hidden.value = ''; input.dataset.valid = ''; });
  }

  // يحوّل ما في الحقل إلى رمز حساب: { ok, code }
  function resolveSearch(prefix, getList, withAll) {
    const input = $(`${prefix}-input`);
    const hidden = $(`${prefix}-code`);
    const text = input.value.trim();
    if (withAll && (!text || text === 'الكل')) return { ok: true, code: '' };
    if (input.dataset.valid === '1' && hidden.value) return { ok: true, code: hidden.value };
    const found = getList().find(a => String(a.code) === text || a.name === text || `${a.code} - ${a.name}` === text);
    return found ? { ok: true, code: found.code } : { ok: false, code: '' };
  }

  async function render(container) {
    await YearEnd.refresh();
    const cfg = YearEnd.getCfg();
    if (!cfg || !cfg.periods || !cfg.periods.length) {
      container.innerHTML = '<p class="hint">يجب إعداد فترات النظام من شاشة التهيئة أولًا.</p>';
      return;
    }
    periods = cfg.periods;
    const readOnly = YearEnd.isReadOnlySession();

    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    mains = accounts.filter(a => a.type === 'رئيسي').sort(byCode);
    subs = accounts.filter(a => a.type === 'فرعي' && (!a.analyticType || a.analyticType === 'عام')).sort(byCode);
    currencies = (await FarisDB.getAll(STORES.CURRENCIES)).sort((a, b) => a.id - b.id);

    const curOptions = currencies.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    const nowMonth = new Date().getMonth() + 1;
    const defPeriod = (periods.find(p => p.month === nowMonth) || periods[0]).number;

    container.innerHTML = `
      ${readOnly ? `<p class="hint year-lock-note">🔒 السنة المالية ${YearEnd.getSessionYear()} مقفلة — العرض فقط، ولا يمكن إجراء إقفال فيها.</p>` : ''}
      <div class="form-grid">
        <label class="required">نوع الإقفال
          <select id="cl-type">
            <option value="monthly">شهري</option>
            <option value="yearly">سنوي</option>
          </select>
        </label>
        <label class="required" id="cl-month-wrap">الشهر
          <select id="cl-month">
            ${periods.map(p => `<option value="${p.number}" ${p.number === defPeriod ? 'selected' : ''}>${p.name} ${p.from.slice(0, 4)}</option>`).join('')}
          </select>
        </label>
        <label class="required">من تاريخ<input type="text" id="cl-from" readonly></label>
        <label class="required">إلى تاريخ<input type="text" id="cl-to" readonly></label>

        <label class="required">من حساب
          <div class="combo-wrap">
            <input type="text" id="cl-acc-from-input" autocomplete="off" placeholder="ابحث برقم الحساب أو الاسم">
            <div class="autocomplete-list" id="cl-acc-from-list"></div>
          </div>
          <input type="hidden" id="cl-acc-from-code">
        </label>
        <label class="required">إلى حساب
          <div class="combo-wrap">
            <input type="text" id="cl-acc-to-input" autocomplete="off" placeholder="ابحث برقم الحساب أو الاسم">
            <div class="autocomplete-list" id="cl-acc-to-list"></div>
          </div>
          <input type="hidden" id="cl-acc-to-code">
        </label>

        <label class="required">من عملة
          <select id="cl-cur-from"><option value="">الكل</option>${curOptions}</select>
        </label>
        <label class="required">إلى عملة
          <select id="cl-cur-to"><option value="">الكل</option>${curOptions}</select>
        </label>
      </div>

      <div class="toolbar" style="margin-top:12px;">
        <button class="btn btn-primary full" id="cl-run" ${readOnly ? 'disabled' : ''}>🔒 إقفال</button>
      </div>
      <p class="hint">يُقفل النظام أرصدة حسابات الأرباح والخسائر (الإيرادات والمصروفات) ضمن الفترة والحسابات والعملات المحددة بقيود إقفال في حساب الأرباح والخسائر.</p>
      <div id="cl-result"></div>
      <h4 class="section-title">عمليات الإقفال السابقة</h4>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>النوع</th><th>الفترة</th><th>حساب الأرباح والخسائر</th><th>عدد الأرصدة</th><th>عدد القيود</th><th>الصافي (محلي)</th></tr></thead>
          <tbody id="cl-history"></tbody>
        </table>
      </div>

      <div class="popup-sheet" id="cl-pl-popup">
        <div class="popup-header"><span>حساب الأرباح والخسائر</span><button class="btn-close" id="cl-pl-close" type="button">✖️</button></div>
        <p class="hint" style="margin-bottom:10px;">أدخل حساب الأرباح والخسائر الذي سيتم إقفال حسابات الأرباح والخسائر به</p>
        <label class="required">ابحث برقم الحساب أو الاسم
          <div class="combo-wrap">
            <input type="text" id="cl-pl-input" autocomplete="off">
            <div class="autocomplete-list" id="cl-pl-list"></div>
          </div>
          <input type="hidden" id="cl-pl-code">
        </label>
        <div class="sheet-actions">
          <button type="button" class="btn btn-ghost" id="cl-pl-cancel">إلغاء</button>
          <button type="button" class="btn btn-primary" id="cl-pl-confirm">تأكيد الإقفال</button>
        </div>
      </div>
    `;

    bindSearch('cl-acc-from', () => mains, true);
    bindSearch('cl-acc-to', () => mains, true);
    bindSearch('cl-pl', () => subs, false);
    Utils.bindKeyboardAwareScroll(container);

    $('cl-type').addEventListener('change', updateDates);
    $('cl-month').addEventListener('change', updateDates);
    $('cl-run').addEventListener('click', onRunClick);
    $('cl-pl-close').addEventListener('click', closePopup);
    $('cl-pl-cancel').addEventListener('click', closePopup);
    $('cl-pl-confirm').addEventListener('click', onConfirm);

    updateDates();
    await drawHistory();
  }

  function currentRange() {
    const cfg = YearEnd.getCfg();
    const type = $('cl-type').value;
    if (type === 'yearly') {
      const r = YearEnd.yearRange(cfg);
      return { type, label: `سنة ${cfg.year}`, from: r.from, to: r.to };
    }
    const p = periods.find(x => String(x.number) === $('cl-month').value) || periods[0];
    return { type, label: `${p.name} ${p.from.slice(0, 4)}`, from: p.from, to: p.to };
  }

  function updateDates() {
    const yearly = $('cl-type').value === 'yearly';
    $('cl-month-wrap').style.display = yearly ? 'none' : '';
    const r = currentRange();
    $('cl-from').value = YearEnd.fmtDate(r.from);
    $('cl-to').value = YearEnd.fmtDate(r.to);
  }

  let pending = null;

  function onRunClick() {
    if (YearEnd.isReadOnlySession()) { Utils.toast('هذه السنة المالية مقفلة، لا يمكن إجراء الإقفال فيها', 'error'); return; }

    const fromAcc = resolveSearch('cl-acc-from', () => mains, true);
    const toAcc = resolveSearch('cl-acc-to', () => mains, true);
    if (!fromAcc.ok || !toAcc.ok) { Utils.toast('اختر الحساب من القائمة أو اختر "الكل"', 'error'); return; }
    if (fromAcc.code && toAcc.code && fromAcc.code > toAcc.code && !fromAcc.code.startsWith(toAcc.code)) {
      Utils.toast('"من حساب" يجب أن يسبق "إلى حساب"', 'error'); return;
    }

    const fromCur = $('cl-cur-from').value;
    const toCur = $('cl-cur-to').value;
    if (fromCur && toCur && currencies.findIndex(c => c.id === Number(fromCur)) > currencies.findIndex(c => c.id === Number(toCur))) {
      Utils.toast('"من عملة" يجب أن تسبق "إلى عملة"', 'error'); return;
    }

    pending = { ...currentRange(), fromAccount: fromAcc.code, toAccount: toAcc.code, fromCurrencyId: fromCur, toCurrencyId: toCur };

    $('cl-pl-input').value = '';
    $('cl-pl-code').value = '';
    $('cl-pl-input').dataset.valid = '';
    Utils.openSheet($('cl-pl-popup'));
  }

  function closePopup() { Utils.closeSheet($('cl-pl-popup')); }

  async function onConfirm() {
    const pl = resolveSearch('cl-pl', () => subs, false);
    if (!pl.ok) { Utils.toast('اختر حساب الأرباح والخسائر من القائمة', 'error'); return; }
    const plAcc = subs.find(a => a.code === pl.code);

    const ok = await Utils.confirmDialog(
      `سيتم إقفال حسابات الأرباح والخسائر عن ${Utils.escapeHtml(pending.label)} (من ${YearEnd.fmtDate(pending.from)} إلى ${YearEnd.fmtDate(pending.to)}) في حساب «${Utils.escapeHtml(plAcc.name)}». هل تريد المتابعة؟`
    );
    if (!ok) return;

    const btn = $('cl-pl-confirm');
    btn.disabled = true;
    try {
      const res = await YearEnd.performClosing({ ...pending, plAccountCode: pl.code });
      closePopup();
      if (res.empty) {
        $('cl-result').innerHTML = '<div class="result-card warn">لا توجد أرصدة في حسابات الأرباح والخسائر ضمن المحددات لإقفالها.</div>';
        Utils.toast('لا توجد أرصدة لإقفالها', 'info');
      } else {
        const net = res.netLocal;
        const outcome = net < 0 ? `صافي الربح: ${Math.abs(net).toFixed(2)}` : net > 0 ? `صافي الخسارة: ${net.toFixed(2)}` : 'الصافي: صفر';
        $('cl-result').innerHTML = `<div class="result-card ok">✅ تم الإقفال بنجاح<br>عدد الأرصدة المقفلة: ${res.accountsClosed} — عدد قيود الإقفال: ${res.entries}<br>${outcome} (بالعملة المحلية)</div>`;
        Utils.toast('تم الإقفال بنجاح', 'success');
        await drawHistory();
      }
    } catch (err) {
      Utils.toast(err.message || 'تعذّر تنفيذ الإقفال', 'error');
    } finally {
      btn.disabled = false;
    }
  }

  async function drawHistory() {
    const list = (await YearEnd.getClosings()).slice().reverse();
    $('cl-history').innerHTML = list.map(c => `
      <tr>
        <td>${c.type === 'yearly' ? 'سنوي' : 'شهري'}</td>
        <td>${Utils.escapeHtml(c.label || '')}</td>
        <td>${Utils.escapeHtml(c.plAccountName || '')}</td>
        <td>${c.accountsClosed}</td>
        <td>${(c.entryIds || []).length}</td>
        <td>${Number(c.netLocal || 0).toFixed(2)}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="empty-row">لا توجد عمليات إقفال بعد</td></tr>';
  }

  return { render };
})();
