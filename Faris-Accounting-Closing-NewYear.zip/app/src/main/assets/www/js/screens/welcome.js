/* =========================================================
   شاشة الترحيب
   ========================================================= */

const ScreenWelcome = (function () {

  function init() {
    App.register('welcome', { onShow });

    document.getElementById('welcome-year').value = new Date().getFullYear();

    document.getElementById('btn-enter').addEventListener('click', onEnterClick);
    document.getElementById('btn-exit').addEventListener('click', onExitClick);

    document.getElementById('login-form').addEventListener('submit', onLoginSubmit);
    document.getElementById('login-cancel').addEventListener('click', () => {
      Utils.closeSheet(document.getElementById('login-sheet'));
    });

    document.getElementById('login-user-number').addEventListener('input', autoFillUserName);
  }

  async function onShow() {
    const cfg = await FarisDB.get(STORES.SETTINGS, 'systemPeriods');
    const yearInput = document.getElementById('welcome-year');
    if (cfg && cfg.year) { yearInput.value = cfg.year; yearInput.max = cfg.year; yearInput.readOnly = false; }
    else { yearInput.value = new Date().getFullYear(); yearInput.readOnly = false; yearInput.removeAttribute('max'); }
  }

  async function validateFinancialYear() {
    const cfg = await FarisDB.get(STORES.SETTINGS, 'systemPeriods');
    const enteredYear = Number(document.getElementById('welcome-year').value);
    if (!cfg || !cfg.periods || !cfg.periods.length) { Utils.toast('لم يتم إعداد فترات النظام. افتح التهيئة ثم تهيئة فترات النظام قبل الدخول', 'error'); App.show('setup', { params: { tab: 'periods' } }); return false; }
    if (enteredYear > Number(cfg.year)) { Utils.toast('تاريخ السنة المالية أكبر من تاريخ الفترة المعدة للنظام', 'error'); return false; }
    return true;
  }

  async function autoFillUserName(e) {
    const number = e.target.value.trim();
    const nameField = document.getElementById('login-user-name');
    if (!number) { nameField.value = ''; return; }
    const users = await FarisDB.getAll(STORES.USERS);
    const found = users.find(u => String(u.userNumber) === number);
    nameField.value = found ? found.userName : '';
  }

  async function onEnterClick() {
    if (!(await validateFinancialYear())) return;
    const users = await FarisDB.getAll(STORES.USERS);
    const requiresPassword = users.some(u => u.requirePassword);

    if (requiresPassword) {
      const sheet = document.getElementById('login-sheet');
      document.getElementById('login-user-number').value = '';
      document.getElementById('login-user-name').value = '';
      document.getElementById('login-password').value = '';
      Utils.openSheet(sheet);
      return;
    }
    await FarisDB.put(STORES.SESSION, { id: 'current', year: document.getElementById('welcome-year').value, userId: null });
    await YearEnd.refresh();
    notifyReadOnly();
    App.show('home');
  }

  async function onLoginSubmit(e) {
    e.preventDefault();
    if (!(await validateFinancialYear())) return;
    const number = document.getElementById('login-user-number').value.trim();
    const password = document.getElementById('login-password').value;

    const users = await FarisDB.getAll(STORES.USERS);
    const found = users.find(u => String(u.userNumber) === number);

    if (!found || (found.requirePassword && found.password !== password)) {
      Utils.toast('رقم المستخدم أو كلمة المرور غير صحيحة', 'error');
      return;
    }

    await FarisDB.put(STORES.SESSION, { id: 'current', year: document.getElementById('welcome-year').value, userId: found.id });
    await YearEnd.refresh();
    Utils.closeSheet(document.getElementById('login-sheet'));
    notifyReadOnly();
    App.show('home');
  }

  function notifyReadOnly() {
    if (YearEnd.isReadOnlySession()) Utils.toast(`السنة ${YearEnd.getSessionYear()} مقفلة — ستتمكن من عرض التقارير فقط`, 'info');
  }

  function onExitClick() {
    // إغلاق التطبيق بالكامل (يعمل داخل WebView / Android بدعم من الغلاف الأصلي)
    if (window.AndroidBridge && typeof window.AndroidBridge.exitApp === 'function') {
      window.AndroidBridge.exitApp();
    } else if (window.close) {
      window.close();
    } else {
      Utils.toast('لإغلاق التطبيق أغلق النافذة من نظام التشغيل', 'info');
    }
  }

  return { init };
})();
