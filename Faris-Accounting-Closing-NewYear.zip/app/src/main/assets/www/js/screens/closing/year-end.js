/* =========================================================
   محرك الإقفال وفتح سنة جديدة (المطابقة والترحيلات)
   - تجميع الأرصدة من كل مصادر الحركة (أرصدة افتتاحية، قيود، سندات، صرف عملة)
   - إقفال حسابات الأرباح والخسائر في حساب الأرباح والخسائر (قيود إقفال حقيقية)
   - فتح سنة مالية جديدة وترحيل الأرصدة النهائية كأرصدة افتتاحية
   - منع أي عملية في السنوات المقفلة (حماية على مستوى قاعدة البيانات)
   ========================================================= */

const YearEnd = (function () {
  const FY_KEY = 'fiscalYears';   // السنوات المقفلة
  const CL_KEY = 'closings';      // سجل عمليات الإقفال
  const LS_KEY = 'faris_systemPeriods_config';
  const MONTH_NAMES = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

  // المخازن التي تُمنع الكتابة فيها داخل السنوات المقفلة (الحركات فقط، لا البيانات الأساسية)
  const GUARDED = new Set([
    STORES.OPENING_BALANCES, STORES.JOURNAL, STORES.VOUCHERS, STORES.CURRENCY_EXCHANGES,
    STORES.SALES, STORES.SALES_RETURNS, STORES.PURCHASE_INVOICES, STORES.PURCHASE_RETURNS,
    STORES.PURCHASE_DISCOUNTS, STORES.DISCOUNTS, STORES.INV_OPENING_STOCK,
    STORES.INV_OPENING_STOCK_DOCS, STORES.SALES_INVOICES
  ]);

  const state = { loaded: false, cfg: null, years: [], sessionYear: null };

  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const norm = (s) => String(s || '').replace(/[أإآ]/g, 'ا').trim();
  const isPL = (acc) => norm(acc.reportType || 'ميزانية عمومية') === norm('أرباح وخسائر');

  /* ---------------- التواريخ ---------------- */
  function addDays(dateStr, n) {
    const [y, m, d] = String(dateStr).split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d + n));
    return dt.toISOString().slice(0, 10);
  }
  function fmtDate(d) {
    if (!d) return '';
    const [y, m, day] = String(d).split('-');
    return `${day}/${m}/${y}`;
  }
  const todayStr = () => new Date().toISOString().slice(0, 10);

  /* ---------------- الحالة ---------------- */
  async function refresh() {
    let cfg = null;
    try { cfg = await SetupPeriods.getConfig(); } catch (_) { /* تجاهل */ }
    let fy = null, sess = null;
    try { fy = await FarisDB.get(STORES.SETTINGS, FY_KEY); } catch (_) { /* تجاهل */ }
    try { sess = await FarisDB.get(STORES.SESSION, 'current'); } catch (_) { /* تجاهل */ }
    state.cfg = cfg;
    state.years = fy && Array.isArray(fy.list) ? fy.list : [];
    state.sessionYear = Number(sess && sess.year) || (cfg ? Number(cfg.year) : null);
    state.loaded = true;
  }

  const getCfg = () => state.cfg;
  const getYears = () => state.years.slice();
  const maxClosedYear = () => state.years.reduce((m, y) => Math.max(m, Number(y.year)), 0);
  const lastClosedTo = () => state.years.reduce((m, y) => (y.to > m ? y.to : m), '');
  const isReadOnlySession = () => !!(state.loaded && state.sessionYear && state.years.length && state.sessionYear <= maxClosedYear());
  const getSessionYear = () => state.sessionYear;

  // بداية السنة الحالية المفتوحة (آخر تاريخ مقفل + يوم) أو فارغ لأول سنة
  const currentLowerBound = () => lastClosedTo();

  // مدى التواريخ الافتراضي للتقارير بحسب سنة الجلسة
  function sessionRange() {
    if (!state.loaded || !state.cfg) return { from: '2000-01-01', to: todayStr() };
    const y = state.sessionYear;
    const rec = state.years.find(r => Number(r.year) === y);
    if (rec) return { from: rec.lowerBound ? addDays(rec.lowerBound, 1) : '2000-01-01', to: rec.to };
    if (state.years.length && y < Math.min(...state.years.map(r => Number(r.year)))) return { from: '2000-01-01', to: `${y}-12-31` };
    const lt = lastClosedTo();
    return { from: lt ? addDays(lt, 1) : '2000-01-01', to: todayStr() };
  }
  const defaultFrom = () => sessionRange().from;
  const defaultTo = () => sessionRange().to;

  /* ---------------- حماية السنوات المقفلة ---------------- */
  function fail(msg) {
    try { Utils.toast(msg, 'error'); } catch (_) { /* تجاهل */ }
    throw new Error(msg);
  }
  const dateOf = (v) => (v && (v.date || v.invoiceDate || v.docDate)) || '';

  async function guard(storeName, newValue, key) {
    if (!state.loaded || !GUARDED.has(storeName) || !state.years.length) return;
    if (isReadOnlySession()) {
      fail(`السنة المالية ${state.sessionYear} مقفلة — يمكنك عرض التقارير فقط، ولا يمكن إجراء أي عملية فيها`);
    }
    const lock = lastClosedTo();
    if (!lock) return;
    const dates = [dateOf(newValue)];
    if (key !== undefined && key !== null) {
      try { dates.push(dateOf(await FarisDB.get(storeName, key))); } catch (_) { /* تجاهل */ }
    }
    for (const d of dates) {
      if (d && d <= lock) fail(`لا يمكن إجراء عملية بتاريخ ${fmtDate(d)} لأنه ضمن سنة مالية مقفلة (حتى ${fmtDate(lock)})`);
    }
  }
  FarisDB.setWriteGuard(guard);

  /* ---------------- تجميع الأرصدة ---------------- */
  // يعيد صفًا لكل (حساب فرعي + حساب تحليلي + عملة) مع المدين والدائن بالعملة الأصلية وبالمحلية
  async function collectBalances({ from, to }) {
    const [currencies, accounts] = await Promise.all([FarisDB.getAll(STORES.CURRENCIES), FarisDB.getAll(STORES.ACCOUNTS)]);
    const accMap = new Map(accounts.map(a => [a.code, a]));
    const curMap = new Map(currencies.map(c => [c.id, c]));
    const inRange = (d) => !!d && (!from || d >= from) && (!to || d <= to);
    const toLocal = (amount, cid) => {
      const c = curMap.get(cid);
      if (!amount) return 0;
      if (!c || c.type === 'محلي') return amount;
      return amount * (Number(c.rate) || 1);
    };
    const pick = (stored, amount, cid) => (typeof stored === 'number' && !isNaN(stored)) ? stored : toLocal(amount, cid);

    const map = new Map();
    const add = (accountCode, analyticCode, analyticName, currencyId, debit, credit, ld, lc) => {
      if (!accountCode) return;
      const ac = analyticCode || accountCode;
      const key = `${accountCode}|${ac}|${currencyId}`;
      let row = map.get(key);
      if (!row) {
        row = { accountCode, analyticCode: ac, analyticName: '', currencyId, debit: 0, credit: 0, localDebit: 0, localCredit: 0 };
        map.set(key, row);
      }
      if (!row.analyticName && analyticName) row.analyticName = analyticName;
      row.debit += Number(debit) || 0;
      row.credit += Number(credit) || 0;
      row.localDebit += pick(ld, debit, currencyId);
      row.localCredit += pick(lc, credit, currencyId);
    };

    (await FarisDB.getAll(STORES.OPENING_BALANCES)).forEach(it => {
      if (!inRange(it.date)) return;
      add(it.accountCode, it.analyticCode, it.analyticName, it.currencyId, it.debit, it.credit, it.localDebit, it.localCredit);
    });
    (await FarisDB.getAll(STORES.JOURNAL)).forEach(entry => {
      if (!inRange(entry.date)) return;
      (entry.lines || []).forEach(l => add(l.accountCode, l.analyticCode, l.analyticName, l.currencyId, l.debit, l.credit, l.localDebit, l.localCredit));
    });
    (await FarisDB.getAll(STORES.VOUCHERS)).forEach(v => {
      if (!inRange(v.date)) return;
      const d = v.debitSide, c = v.creditSide;
      if (d) add(d.accountCode, d.analyticCode, d.analyticName, d.currencyId, d.amount, 0, d.localDebit, 0);
      if (c) add(c.accountCode, c.analyticCode, c.analyticName, c.currencyId, 0, c.amount, 0, c.localCredit);
    });
    (await FarisDB.getAll(STORES.CURRENCY_EXCHANGES)).forEach(ex => {
      if (!inRange(ex.date)) return;
      add(ex.accountCode, ex.analyticCode, ex.analyticName, ex.fromCurrencyId, 0, ex.fromAmount, 0, ex.localCredit);
      add(ex.accountCode, ex.analyticCode, ex.analyticName, ex.toCurrencyId, ex.toAmount, 0, ex.localDebit, 0);
    });

    const rows = [];
    map.forEach(row => {
      const acc = accMap.get(row.accountCode);
      row.accountName = acc ? acc.name : '';
      if (!row.analyticName && row.analyticCode === row.accountCode) row.analyticName = row.accountName;
      row.debit = r2(row.debit); row.credit = r2(row.credit);
      row.localDebit = r2(row.localDebit); row.localCredit = r2(row.localCredit);
      row.net = r2(row.debit - row.credit);
      row.localNet = r2(row.localDebit - row.localCredit);
      row.account = acc || null;
      rows.push(row);
    });
    rows.sort((a, b) => a.accountCode.localeCompare(b.accountCode) || String(a.analyticCode).localeCompare(String(b.analyticCode)));
    return rows;
  }

  /* ---------------- نطاق الحسابات والعملات ---------------- */
  // الحسابات الفرعية التي تقع تحت الحسابات الرئيسية من fromCode إلى toCode (فارغ = بلا حدّ)
  async function resolveScopeCodes(fromCode, toCode) {
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const mains = accounts.filter(a => a.type === 'رئيسي');
    const eligible = mains.filter(m =>
      (!fromCode || m.code >= fromCode) && (!toCode || m.code <= toCode || m.code.startsWith(toCode)));
    const subs = accounts.filter(a => a.type === 'فرعي' && (!fromCode && !toCode ? true : eligible.some(m => a.code.startsWith(m.code))));
    return new Set(subs.map(a => a.code));
  }

  async function resolveCurrencyIds(fromId, toId) {
    const list = (await FarisDB.getAll(STORES.CURRENCIES)).sort((a, b) => a.id - b.id);
    const i1 = fromId ? list.findIndex(c => c.id === Number(fromId)) : 0;
    const i2 = toId ? list.findIndex(c => c.id === Number(toId)) : list.length - 1;
    if (i1 < 0 || i2 < 0 || i1 > i2) return null;
    return new Set(list.slice(i1, i2 + 1).map(c => c.id));
  }

  /* ---------------- سجل الإقفال ---------------- */
  async function getClosings() {
    const rec = await FarisDB.get(STORES.SETTINGS, CL_KEY);
    return rec && Array.isArray(rec.list) ? rec.list : [];
  }
  async function saveClosings(list) {
    await FarisDB.withBypass(() => FarisDB.put(STORES.SETTINGS, { id: CL_KEY, list }));
  }

  async function nextEntryNo() {
    const entries = await FarisDB.getAll(STORES.JOURNAL);
    const nums = entries.map(e => Number(e.entryNo)).filter(n => !isNaN(n));
    return nums.length ? Math.max(...nums) : 0;
  }

  /* ---------------- الإقفال ---------------- */
  async function performClosing({ type, label, from, to, fromAccount, toAccount, fromCurrencyId, toCurrencyId, plAccountCode }) {
    if (!state.cfg) throw new Error('لم يتم إعداد فترات النظام');
    if (isReadOnlySession()) throw new Error(`السنة المالية ${state.sessionYear} مقفلة، لا يمكن إجراء الإقفال فيها`);

    const pl = await FarisDB.get(STORES.ACCOUNTS, plAccountCode);
    if (!pl || pl.type !== 'فرعي') throw new Error('حساب الأرباح والخسائر يجب أن يكون حسابًا فرعيًا');
    if (pl.analyticType && pl.analyticType !== 'عام') throw new Error('حساب الأرباح والخسائر يجب أن يكون حسابًا عامًا (غير مرتبط بعملاء/موردين/صناديق/بنوك)');

    const scope = await resolveScopeCodes(fromAccount, toAccount);
    const curIds = await resolveCurrencyIds(fromCurrencyId, toCurrencyId);
    if (!curIds) throw new Error('نطاق العملات غير صحيح');

    // الإقفال السنوي يشمل أي حركة سابقة داخل السنة المالية المفتوحة
    const effFrom = type === 'yearly' ? (currentLowerBound() ? addDays(currentLowerBound(), 1) : '') : from;
    const all = await collectBalances({ from: effFrom, to });
    const targets = all.filter(r =>
      r.account && isPL(r.account) && r.accountCode !== plAccountCode &&
      scope.has(r.accountCode) && curIds.has(r.currencyId) && Math.abs(r.net) >= 0.005);
    if (!targets.length) return { empty: true };

    const byCurrency = new Map();
    targets.forEach(r => {
      if (!byCurrency.has(r.currencyId)) byCurrency.set(r.currencyId, []);
      byCurrency.get(r.currencyId).push(r);
    });

    const closingId = Date.now();
    const statement = `قيد إقفال ${label} إلى حساب ${pl.name}`;
    let entryNo = await nextEntryNo();
    const created = [];
    let netLocal = 0;

    try {
      await FarisDB.withBypass(async () => {
        for (const [currencyId, rows] of byCurrency) {
          const lines = [];
          let plNet = 0, plLocal = 0;
          rows.forEach(r => {
            const amount = Math.abs(r.net);
            const rate = amount ? Math.abs(r.localNet) / amount : 1;
            lines.push({
              accountCode: r.accountCode, accountName: r.accountName,
              analyticCode: r.analyticCode, analyticName: r.analyticName || r.accountName,
              currencyId: Number(currencyId), statement,
              debit: r.net < 0 ? amount : 0, credit: r.net > 0 ? amount : 0,
              refNo: '', exchangeRate: rate || 1
            });
            plNet += r.net;
            plLocal += r.localNet;
          });
          plNet = r2(plNet); plLocal = r2(plLocal);
          if (Math.abs(plNet) >= 0.005) {
            const amount = Math.abs(plNet);
            lines.push({
              accountCode: pl.code, accountName: pl.name, analyticCode: pl.code, analyticName: pl.name,
              currencyId: Number(currencyId), statement,
              debit: plNet > 0 ? amount : 0, credit: plNet < 0 ? amount : 0,
              refNo: '', exchangeRate: Math.abs(plLocal) / amount || 1
            });
          }
          netLocal += plLocal;
          entryNo += 1;
          const id = await FarisDB.put(STORES.JOURNAL, { entryNo: String(entryNo), date: to, lines, entryType: 'closing', closingId });
          created.push(id);
        }
      });
    } catch (err) {
      // تراجع عن القيود التي أُنشئت قبل حدوث الخطأ
      await FarisDB.withBypass(async () => { for (const id of created) { try { await FarisDB.remove(STORES.JOURNAL, id); } catch (_) { /* تجاهل */ } } });
      throw err;
    }

    const list = await getClosings();
    list.push({ id: closingId, type, label, from: effFrom || from, to, plAccountCode: pl.code, plAccountName: pl.name, entryIds: created, accountsClosed: targets.length, netLocal: r2(netLocal), at: new Date().toISOString() });
    await saveClosings(list);
    return { empty: false, entries: created.length, accountsClosed: targets.length, netLocal: r2(netLocal) };
  }

  /* ---------------- فتح سنة جديدة ---------------- */
  function yearRange(cfg) {
    const ps = cfg.periods || [];
    return { from: ps.length ? ps[0].from : `${cfg.year}-01-01`, to: ps.length ? ps[ps.length - 1].to : `${cfg.year}-12-31` };
  }

  // أرصدة حسابات الأرباح والخسائر التي لم تُقفل بعد في السنة الحالية
  async function pendingPLBalances() {
    const cfg = state.cfg;
    const { to } = yearRange(cfg);
    const lb = currentLowerBound();
    const closings = await getClosings();
    const plTargets = new Set(closings.map(c => c.plAccountCode));
    const rows = await collectBalances({ from: lb ? addDays(lb, 1) : '', to });
    return rows.filter(r => r.account && isPL(r.account) && !plTargets.has(r.accountCode) && Math.abs(r.net) >= 0.005);
  }

  // الأرصدة النهائية التي ستُرحَّل كأرصدة افتتاحية للسنة الجديدة
  async function computeCarryOver() {
    const cfg = state.cfg;
    const { to } = yearRange(cfg);
    const lb = currentLowerBound();
    const rows = await collectBalances({ from: lb ? addDays(lb, 1) : '', to });
    return rows.filter(r => r.account && r.account.type === 'فرعي' && (Math.abs(r.net) >= 0.005));
  }

  function buildPeriods(year, startMonth, endMonth) {
    const periods = [];
    for (let m = startMonth; m <= endMonth; m++) {
      const lastDay = new Date(year, m, 0).getDate();
      periods.push({ number: periods.length + 1, month: m, name: MONTH_NAMES[m - 1], from: `${year}-${String(m).padStart(2, '0')}-01`, to: `${year}-${String(m).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}` });
    }
    return periods;
  }

  async function openNewYear() {
    const cfg = state.cfg;
    if (!cfg) throw new Error('لم يتم إعداد فترات النظام');
    if (isReadOnlySession() || state.sessionYear !== Number(cfg.year)) {
      throw new Error('يجب الدخول إلى السنة المالية الحالية المفتوحة لفتح سنة جديدة');
    }
    const pending = await pendingPLBalances();
    if (pending.length) {
      const err = new Error(`لا تزال هناك أرصدة في حسابات الأرباح والخسائر (${pending.length} رصيد). نفّذ الإقفال السنوي أولًا ثم افتح السنة الجديدة`);
      err.code = 'PENDING_PL';
      throw err;
    }

    const carry = await computeCarryOver();
    const oldYear = Number(cfg.year);
    const newYear = oldYear + 1;
    const range = yearRange(cfg);
    const newPeriods = buildPeriods(newYear, Number(cfg.startMonth), Number(cfg.endMonth));
    const openDate = newPeriods[0].from;

    const existing = await FarisDB.getAll(STORES.OPENING_BALANCES);
    const nums = existing.map(i => Number(i.voucherNo)).filter(n => !isNaN(n));
    let voucherNo = nums.length ? Math.max(...nums) : 0;
    const createdIds = [];
    const prevCfg = JSON.parse(JSON.stringify(cfg));

    try {
      await FarisDB.withBypass(async () => {
        for (const r of carry) {
          voucherNo += 1;
          const debitSide = r.net > 0;
          const amount = Math.abs(r.net);
          const local = Math.abs(r.localNet);
          const id = await FarisDB.put(STORES.OPENING_BALANCES, {
            voucherNo: String(voucherNo), date: openDate,
            accountCode: r.accountCode, accountName: r.accountName,
            analyticCode: r.analyticCode, analyticName: r.analyticName || r.accountName,
            currencyId: r.currencyId,
            debit: debitSide ? amount : 0, credit: debitSide ? 0 : amount,
            localDebit: debitSide ? local : 0, localCredit: debitSide ? 0 : local,
            keepLocal: true,
            statement: `رصيد افتتاحي - مرحّل من سنة ${oldYear}`,
            carriedFromYear: oldYear
          });
          createdIds.push(id);
        }

        const newCfg = { ...cfg, year: newYear, periods: newPeriods, configuredAt: new Date().toISOString() };
        await FarisDB.put(STORES.SETTINGS, newCfg);
        try { localStorage.setItem(LS_KEY, JSON.stringify(newCfg)); } catch (_) { /* تجاهل */ }

        const years = state.years.slice();
        years.push({ year: oldYear, from: range.from, to: range.to, lowerBound: currentLowerBound(), closedAt: new Date().toISOString(), carriedBalances: carry.length, openedYear: newYear });
        await FarisDB.put(STORES.SETTINGS, { id: FY_KEY, list: years });

        // الجلسة الحالية تنتقل إلى السنة الجديدة
        const sess = (await FarisDB.get(STORES.SESSION, 'current')) || { id: 'current', userId: null };
        await FarisDB.put(STORES.SESSION, { ...sess, id: 'current', year: String(newYear) });
      });
    } catch (err) {
      // تراجع كامل: حذف الأرصدة المرحّلة واستعادة تهيئة الفترات
      await FarisDB.withBypass(async () => {
        for (const id of createdIds) { try { await FarisDB.remove(STORES.OPENING_BALANCES, id); } catch (_) { /* تجاهل */ } }
        try { await FarisDB.put(STORES.SETTINGS, prevCfg); localStorage.setItem(LS_KEY, JSON.stringify(prevCfg)); } catch (_) { /* تجاهل */ }
        try { await FarisDB.put(STORES.SETTINGS, { id: FY_KEY, list: state.years }); } catch (_) { /* تجاهل */ }
      });
      throw err;
    }

    await refresh();
    window.__periodsConfigured = true;
    return { oldYear, newYear, carried: carry.length };
  }

  return {
    refresh, getCfg, getYears, getSessionYear, isReadOnlySession, maxClosedYear,
    defaultFrom, defaultTo, fmtDate, yearRange, addDays,
    collectBalances, resolveScopeCodes, resolveCurrencyIds,
    getClosings, performClosing, pendingPLBalances, computeCarryOver, openNewYear, MONTH_NAMES
  };
})();
