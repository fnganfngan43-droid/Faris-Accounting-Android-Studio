/* =========================================================
   الشاشة الرئيسية
   ========================================================= */

const ScreenHome = (function () {

  function init() {
    App.register('home', { onShow: refreshBanner });

    document.getElementById('home-back-welcome').addEventListener('click', () => {
      App.show('welcome', { replace: true });
    });

    document.querySelectorAll('#home-grid .grid-icon').forEach((btn) => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.target;
        if (!target) {
          Utils.toast('هذه الشاشة ستُضاف في مرحلة قادمة', 'info');
          return;
        }
        App.show(target);
      });
    });
  }

  // شريط تنبيه يظهر عند الدخول إلى سنة مقفلة (عرض فقط)
  async function refreshBanner() {
    const banner = document.getElementById('home-year-banner');
    if (!banner) return;
    try { await YearEnd.refresh(); } catch (_) { /* تجاهل */ }
    if (YearEnd.isReadOnlySession()) {
      banner.textContent = `🔒 السنة المالية ${YearEnd.getSessionYear()} مقفلة — عرض التقارير فقط، ولا يمكن إجراء أي عملية`;
      banner.style.display = '';
    } else {
      banner.style.display = 'none';
    }
  }

  return { init, refreshBanner };
})();
